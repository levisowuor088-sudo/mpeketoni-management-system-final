import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { actions, useStore, kes, feeForStudent, type Student } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import {
  TrendingUp, TrendingDown, Wallet, Receipt, FileMinus, AlertTriangle,
  Sparkles, Plus, Trash2, Printer, Percent, FileText,
} from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/finance")({
  head: () => ({
    meta: [
      { title: "Finance Hub — Levis Developers" },
      { name: "description", content: "Comprehensive finance dashboard: income, expenses, invoices, P&L, AI defaulter prediction." },
    ],
  }),
  component: FinanceHub,
});

const EXPENSE_COLORS = ["var(--color-chart-1)", "var(--color-chart-2)", "var(--color-chart-3)", "var(--color-chart-4)", "var(--color-chart-5)"];

function FinanceHub() {
  const s = useStore((x) => x);

  const revenue = s.payments.reduce((a, p) => a + p.amount, 0);
  const expenseTotal = s.expenses.reduce((a, e) => a + e.amount, 0);
  const payrollTotal = s.payroll.reduce((a, p) => a + p.net, 0);
  const outstanding = s.students.reduce((a, st) => a + st.feeBalance, 0);
  const expected = s.students.reduce((a, st) => a + feeForStudent(s, st), 0);
  const collectionRate = expected ? Math.round((revenue / (revenue + outstanding)) * 100) : 0;
  const netProfit = revenue - expenseTotal - payrollTotal;

  // Monthly trend (last 6 months)
  const monthly = useMemo(() => {
    const map: Record<string, { month: string; income: number; expenses: number }> = {};
    for (let i = 5; i >= 0; i--) {
      const d = new Date(); d.setMonth(d.getMonth() - i);
      const key = d.toISOString().slice(0, 7);
      map[key] = { month: d.toLocaleDateString("en", { month: "short" }), income: 0, expenses: 0 };
    }
    s.payments.forEach((p) => {
      const k = p.date.slice(0, 7);
      if (map[k]) map[k].income += p.amount;
    });
    s.expenses.forEach((e) => {
      const k = e.date.slice(0, 7);
      if (map[k]) map[k].expenses += e.amount;
    });
    return Object.values(map);
  }, [s.payments, s.expenses]);

  const expenseByCategory = useMemo(() => {
    const map: Record<string, number> = {};
    s.expenses.forEach((e) => { map[e.category] = (map[e.category] ?? 0) + e.amount; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [s.expenses]);

  const paymentMethods = useMemo(() => {
    const map: Record<string, number> = {};
    s.payments.forEach((p) => { map[p.method] = (map[p.method] ?? 0) + p.amount; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [s.payments]);

  return (
    <div>
      <PageHeader title="Finance Hub" description="Live view of school income, expenses, invoicing and defaulter intelligence." />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KPI label="Revenue collected" value={kes(revenue)} hint="Term to date" tone="success" icon={Receipt} delta="+12.4%" />
        <KPI label="Operating expenses" value={kes(expenseTotal)} hint="Excl. payroll" tone="warning" icon={FileMinus} delta="-3.1%" down />
        <KPI label="Payroll commitment" value={kes(payrollTotal)} hint="Current month" tone="info" icon={Wallet} />
        <KPI label="Net position" value={kes(netProfit)} hint={netProfit >= 0 ? "Surplus" : "Deficit"} tone={netProfit >= 0 ? "success" : "destructive"} icon={netProfit >= 0 ? TrendingUp : TrendingDown} />
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="invoices">Invoices</TabsTrigger>
          <TabsTrigger value="expenses">Expenses</TabsTrigger>
          <TabsTrigger value="defaulters">AI Defaulters</TabsTrigger>
          <TabsTrigger value="pl">P&amp;L Statement</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid lg:grid-cols-3 gap-4">
            <Card className="lg:col-span-2 p-5">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="font-display font-semibold">Income vs Expenses</h3>
                  <p className="text-xs text-muted-foreground">Last 6 months</p>
                </div>
                <Badge variant="secondary" className="gap-1"><TrendingUp className="h-3 w-3" /> Trending up</Badge>
              </div>
              <ResponsiveContainer width="100%" height={280}>
                <AreaChart data={monthly}>
                  <defs>
                    <linearGradient id="inc" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--color-chart-2)" stopOpacity={0.5} />
                      <stop offset="100%" stopColor="var(--color-chart-2)" stopOpacity={0.02} />
                    </linearGradient>
                    <linearGradient id="exp" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--color-chart-5)" stopOpacity={0.5} />
                      <stop offset="100%" stopColor="var(--color-chart-5)" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="month" stroke="var(--color-muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--color-muted-foreground)" fontSize={12} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                  <Tooltip
                    contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8 }}
                    formatter={(v: number) => kes(v)}
                  />
                  <Legend />
                  <Area type="monotone" dataKey="income" stroke="var(--color-chart-2)" strokeWidth={2} fill="url(#inc)" />
                  <Area type="monotone" dataKey="expenses" stroke="var(--color-chart-5)" strokeWidth={2} fill="url(#exp)" />
                </AreaChart>
              </ResponsiveContainer>
            </Card>

            <Card className="p-5">
              <h3 className="font-display font-semibold mb-1">Collection rate</h3>
              <p className="text-xs text-muted-foreground mb-4">Paid vs outstanding</p>
              <div className="text-4xl font-bold font-display">{collectionRate}%</div>
              <div className="mt-3 h-3 rounded-full bg-muted overflow-hidden">
                <div className="h-full bg-success transition-all" style={{ width: `${collectionRate}%` }} />
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-center">
                <div className="rounded-lg bg-success/10 p-3">
                  <div className="text-xs text-muted-foreground">Collected</div>
                  <div className="font-semibold text-success">{kes(revenue)}</div>
                </div>
                <div className="rounded-lg bg-destructive/10 p-3">
                  <div className="text-xs text-muted-foreground">Outstanding</div>
                  <div className="font-semibold text-destructive">{kes(outstanding)}</div>
                </div>
              </div>
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-4">
            <Card className="p-5">
              <h3 className="font-display font-semibold mb-1">Expenses by category</h3>
              <p className="text-xs text-muted-foreground mb-3">Where the money goes</p>
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie data={expenseByCategory} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={3}>
                    {expenseByCategory.map((_, i) => <Cell key={i} fill={EXPENSE_COLORS[i % EXPENSE_COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v: number) => kes(v)} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            </Card>

            <Card className="p-5">
              <h3 className="font-display font-semibold mb-1">Payment channels</h3>
              <p className="text-xs text-muted-foreground mb-3">How parents pay</p>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={paymentMethods} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis type="number" stroke="var(--color-muted-foreground)" fontSize={12} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                  <YAxis type="category" dataKey="name" stroke="var(--color-muted-foreground)" fontSize={12} width={70} />
                  <Tooltip formatter={(v: number) => kes(v)} contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8 }} />
                  <Bar dataKey="value" fill="var(--color-primary)" radius={[0, 6, 6, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="invoices"><InvoicesPanel /></TabsContent>
        <TabsContent value="expenses"><ExpensesPanel /></TabsContent>
        <TabsContent value="defaulters"><DefaultersPanel /></TabsContent>
        <TabsContent value="pl">
          <PLStatement revenue={revenue} expenses={expenseTotal} payroll={payrollTotal} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function KPI({ label, value, hint, tone, icon: Icon, delta, down }: { label: string; value: string; hint: string; tone: "success" | "warning" | "info" | "destructive"; icon: typeof Wallet; delta?: string; down?: boolean }) {
  const toneMap: Record<string, string> = {
    success: "text-success bg-success/10",
    warning: "text-warning bg-warning/10",
    info: "text-chart-1 bg-chart-1/10",
    destructive: "text-destructive bg-destructive/10",
  };
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between mb-3">
        <div className={`h-10 w-10 rounded-lg grid place-items-center ${toneMap[tone]}`}>
          <Icon className="h-5 w-5" />
        </div>
        {delta && (
          <Badge variant="secondary" className="gap-1 text-[10px]">
            {down ? <TrendingDown className="h-3 w-3" /> : <TrendingUp className="h-3 w-3" />}
            {delta}
          </Badge>
        )}
      </div>
      <div className="text-2xl font-bold font-display">{value}</div>
      <div className="text-xs text-muted-foreground mt-1">{label}</div>
      <div className="text-[10px] text-muted-foreground/70 mt-0.5">{hint}</div>
    </Card>
  );
}

function InvoicesPanel() {
  const invoices = useStore((s) => s.invoices);
  const students = useStore((s) => s.students);
  const school = useStore((s) => s.school);
  const [open, setOpen] = useState(false);
  const [studentId, setStudentId] = useState(students[0]?.id ?? "");
  const [viewId, setViewId] = useState<string | null>(null);

  const submit = () => {
    if (!studentId) return;
    actions.issueInvoice(studentId, "Term 2", 2026);
    toast.success("Invoice issued and sent to parent (mocked SMS/email)");
    setOpen(false);
  };

  const inv = viewId ? invoices.find((i) => i.id === viewId) : null;
  const invStudent = inv ? students.find((s) => s.id === inv.studentId) : null;

  return (
    <Card className="overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex items-center justify-between">
        <div>
          <div className="font-display font-semibold">Invoices</div>
          <div className="text-xs text-muted-foreground">{invoices.length} invoices issued</div>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button size="sm"><Plus className="h-4 w-4 mr-1" /> Issue invoice</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Issue new invoice</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div>
                <Label>Student</Label>
                <Select value={studentId} onValueChange={setStudentId}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{students.map((s) => <SelectItem key={s.id} value={s.id}>{s.admissionNo} — {s.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <p className="text-xs text-muted-foreground">Items pulled from the active fee structure for the student's grade.</p>
            </div>
            <DialogFooter><Button onClick={submit}>Issue invoice</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/30 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-4 py-2 text-left">Invoice #</th>
              <th className="px-4 py-2 text-left">Student</th>
              <th className="px-4 py-2 text-left">Term</th>
              <th className="px-4 py-2 text-right">Total</th>
              <th className="px-4 py-2 text-left">Due</th>
              <th className="px-4 py-2 text-left">Status</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {invoices.slice(0, 40).map((i) => {
              const st = students.find((s) => s.id === i.studentId);
              const tone = i.status === "paid" ? "secondary" : i.status === "partial" ? "outline" : "destructive";
              return (
                <tr key={i.id} className="border-t border-border hover:bg-muted/30">
                  <td className="px-4 py-2 font-mono text-xs">{i.invoiceNo}</td>
                  <td className="px-4 py-2">{st?.name}</td>
                  <td className="px-4 py-2">{i.term} · {i.year}</td>
                  <td className="px-4 py-2 text-right font-semibold">{kes(i.total)}</td>
                  <td className="px-4 py-2">{i.dueOn}</td>
                  <td className="px-4 py-2"><Badge variant={tone}>{i.status}</Badge></td>
                  <td className="px-4 py-2"><Button size="sm" variant="ghost" onClick={() => setViewId(i.id)}>View</Button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <Dialog open={!!inv} onOpenChange={(o) => !o && setViewId(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle className="no-print">Invoice</DialogTitle></DialogHeader>
          {inv && invStudent && (
            <div className="print-area">
              <div className="flex items-start justify-between border-b-2 border-primary pb-3 mb-3">
                <div className="flex gap-3 items-center">
                  {school.logo ? (
                    <img src={school.logo} alt="" className="h-14 w-14 rounded-xl object-cover" />
                  ) : (
                    <div className="h-14 w-14 rounded-xl bg-primary text-primary-foreground grid place-items-center font-bold text-xl">{school.name.charAt(0)}</div>
                  )}
                  <div>
                    <div className="font-display font-bold">{school.name}</div>
                    <div className="text-[10px] text-muted-foreground">{school.poBox}</div>
                    <div className="text-[10px] text-muted-foreground">{school.phone} · {school.email}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-sm">INVOICE</div>
                  <div className="text-xs font-mono">{inv.invoiceNo}</div>
                  <div className="text-[10px] text-muted-foreground">Issued {inv.issuedOn}</div>
                  <div className="text-[10px] text-muted-foreground">Due {inv.dueOn}</div>
                </div>
              </div>
              <div className="text-xs mb-3">
                <div className="text-muted-foreground">Billed to</div>
                <div className="font-semibold">{invStudent.parentName}</div>
                <div>{invStudent.name} · {invStudent.admissionNo} · {invStudent.grade} {invStudent.stream}</div>
              </div>
              <table className="w-full text-sm">
                <thead className="text-xs uppercase text-muted-foreground border-b border-border">
                  <tr><th className="text-left py-1">Item</th><th className="text-right py-1">Amount</th></tr>
                </thead>
                <tbody>
                  {inv.items.map((it, idx) => (
                    <tr key={idx} className="border-b border-border/50"><td className="py-1.5">{it.label}</td><td className="py-1.5 text-right">{kes(it.amount)}</td></tr>
                  ))}
                  {inv.discount > 0 && (
                    <tr className="text-success"><td className="py-1.5">Discount</td><td className="py-1.5 text-right">- {kes(inv.discount)}</td></tr>
                  )}
                </tbody>
              </table>
              <div className="mt-3 py-2 border-y-2 border-border flex justify-between font-bold">
                <span>TOTAL DUE</span><span>{kes(inv.total - inv.discount)}</span>
              </div>
              <div className="mt-3 text-[10px] text-muted-foreground space-y-0.5">
                <div>Pay via M-Pesa Paybill <strong>{school.paybill}</strong>, account: <strong>{invStudent.admissionNo}</strong></div>
                <div>Bank: {school.bankName} · A/C {school.bankAccount}</div>
              </div>
            </div>
          )}
          <DialogFooter className="no-print">
            <Button onClick={() => window.print()}><Printer className="h-4 w-4 mr-1" /> Print / PDF</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function ExpensesPanel() {
  const expenses = useStore((s) => s.expenses);
  const [form, setForm] = useState({ category: "Utilities", amount: 0, description: "" });

  const submit = () => {
    if (!form.amount || !form.description) { toast.error("Enter amount & description"); return; }
    actions.addExpense(form);
    toast.success("Expense logged");
    setForm({ category: "Utilities", amount: 0, description: "" });
  };

  return (
    <div className="grid lg:grid-cols-3 gap-4">
      <Card className="p-5">
        <h3 className="font-display font-semibold mb-3">Log expense</h3>
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Category</Label>
            <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {["Utilities", "Maintenance", "Supplies", "Transport", "Food", "Salaries", "Marketing", "Other"].map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Amount (KES)</Label>
            <Input type="number" value={form.amount || ""} onChange={(e) => setForm({ ...form, amount: +e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Description</Label>
            <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
          <Button onClick={submit} className="w-full"><Plus className="h-4 w-4 mr-1" /> Add expense</Button>
        </div>
      </Card>

      <Card className="p-0 overflow-hidden lg:col-span-2">
        <div className="px-4 py-3 border-b border-border font-display font-semibold">Recent expenses</div>
        <table className="w-full text-sm">
          <thead className="bg-muted/30 text-xs uppercase text-muted-foreground">
            <tr><th className="px-4 py-2 text-left">Date</th><th className="px-4 py-2 text-left">Category</th><th className="px-4 py-2 text-left">Description</th><th className="px-4 py-2 text-right">Amount</th><th /></tr>
          </thead>
          <tbody>
            {expenses.map((e) => (
              <tr key={e.id} className="border-t border-border">
                <td className="px-4 py-2 text-xs">{e.date}</td>
                <td className="px-4 py-2"><Badge variant="outline">{e.category}</Badge></td>
                <td className="px-4 py-2">{e.description}</td>
                <td className="px-4 py-2 text-right font-semibold">{kes(e.amount)}</td>
                <td className="px-4 py-2">
                  <Button variant="ghost" size="icon" onClick={() => { actions.deleteExpense(e.id); toast.success("Expense removed"); }}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </td>
              </tr>
            ))}
            {expenses.length === 0 && (
              <tr><td colSpan={5} className="p-8 text-center text-muted-foreground text-sm">No expenses logged yet</td></tr>
            )}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

function DefaultersPanel() {
  const s = useStore((x) => x);
  const [discountFor, setDiscountFor] = useState<Student | null>(null);
  const [discount, setDiscount] = useState({ amount: 0, reason: "" });

  // Naive AI risk score: balance + days since last payment + attendance
  const riskList = useMemo(() => {
    return s.students
      .filter((st) => st.feeBalance > 0)
      .map((st) => {
        const expectedAmt = feeForStudent(s, st) || 1;
        const ratio = Math.min(1, st.feeBalance / expectedAmt);
        const lastPay = s.payments.filter((p) => p.studentId === st.id).sort((a, b) => b.date.localeCompare(a.date))[0];
        const daysSince = lastPay
          ? Math.floor((Date.now() - new Date(lastPay.date).getTime()) / 86400000)
          : 90;
        const absences = s.attendance.filter((a) => a.studentId === st.id && a.status === "absent").length;
        const score = Math.min(100, Math.round(ratio * 60 + Math.min(30, daysSince / 3) + absences * 2));
        const band = score >= 75 ? "high" : score >= 45 ? "medium" : "low";
        return { student: st, score, band, daysSince };
      })
      .sort((a, b) => b.score - a.score);
  }, [s.students, s.payments, s.attendance]);

  const bandTone: Record<string, "destructive" | "outline" | "secondary"> = {
    high: "destructive", medium: "outline", low: "secondary",
  };

  const applyDiscount = () => {
    if (!discountFor || !discount.amount) return;
    actions.applyDiscount(discountFor.id, discount.amount, discount.reason || "Hardship bursary");
    toast.success(`Applied ${kes(discount.amount)} discount`);
    setDiscountFor(null);
    setDiscount({ amount: 0, reason: "" });
  };

  return (
    <Card className="overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <div>
            <div className="font-display font-semibold">AI defaulter prediction</div>
            <div className="text-xs text-muted-foreground">Ranked by balance ratio, payment recency and attendance</div>
          </div>
        </div>
        <Badge variant="destructive" className="gap-1"><AlertTriangle className="h-3 w-3" /> {riskList.filter(r => r.band === "high").length} high risk</Badge>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/30 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-4 py-2 text-left">Student</th>
              <th className="px-4 py-2 text-left">Class</th>
              <th className="px-4 py-2 text-right">Balance</th>
              <th className="px-4 py-2 text-right">Days since payment</th>
              <th className="px-4 py-2 text-left">Risk score</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {riskList.map((r) => (
              <tr key={r.student.id} className="border-t border-border">
                <td className="px-4 py-2">
                  <div className="font-medium">{r.student.name}</div>
                  <div className="text-[10px] text-muted-foreground">{r.student.parentPhone}</div>
                </td>
                <td className="px-4 py-2">{r.student.grade} {r.student.stream}</td>
                <td className="px-4 py-2 text-right font-semibold">{kes(r.student.feeBalance)}</td>
                <td className="px-4 py-2 text-right">{r.daysSince}d</td>
                <td className="px-4 py-2">
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-1.5 rounded-full bg-muted overflow-hidden">
                      <div className={`h-full ${r.band === "high" ? "bg-destructive" : r.band === "medium" ? "bg-warning" : "bg-success"}`} style={{ width: `${r.score}%` }} />
                    </div>
                    <Badge variant={bandTone[r.band]} className="text-[10px]">{r.score} · {r.band}</Badge>
                  </div>
                </td>
                <td className="px-4 py-2 text-right space-x-1">
                  <Button size="sm" variant="ghost" onClick={() => toast.success(`SMS reminder sent to ${r.student.parentName} (mocked)`)}>
                    Remind
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setDiscountFor(r.student)}>
                    <Percent className="h-3 w-3 mr-1" /> Discount
                  </Button>
                </td>
              </tr>
            ))}
            {riskList.length === 0 && (
              <tr><td colSpan={6} className="p-8 text-center text-muted-foreground text-sm">No defaulters detected 🎉</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={!!discountFor} onOpenChange={(o) => !o && setDiscountFor(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Apply discount / bursary</DialogTitle></DialogHeader>
          {discountFor && (
            <div className="space-y-3">
              <div className="text-sm">
                For <strong>{discountFor.name}</strong> · current balance {kes(discountFor.feeBalance)}
              </div>
              <div><Label>Amount (KES)</Label><Input type="number" value={discount.amount || ""} onChange={(e) => setDiscount({ ...discount, amount: +e.target.value })} /></div>
              <div><Label>Reason</Label><Input value={discount.reason} onChange={(e) => setDiscount({ ...discount, reason: e.target.value })} placeholder="Hardship bursary, scholarship, sibling discount..." /></div>
            </div>
          )}
          <DialogFooter><Button onClick={applyDiscount}>Apply</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function PLStatement({ revenue, expenses, payroll }: { revenue: number; expenses: number; payroll: number }) {
  const net = revenue - expenses - payroll;
  return (
    <Card className="p-6 max-w-2xl">
      <div className="flex items-center gap-2 mb-4">
        <FileText className="h-5 w-5 text-primary" />
        <h3 className="font-display font-semibold">Profit &amp; Loss — Current term</h3>
      </div>
      <table className="w-full text-sm">
        <tbody>
          <tr className="border-b border-border"><td className="py-2 font-semibold">Revenue</td><td className="py-2 text-right" /></tr>
          <tr><td className="py-1.5 pl-4 text-muted-foreground">Fee payments collected</td><td className="py-1.5 text-right">{kes(revenue)}</td></tr>
          <tr className="border-b-2 border-border"><td className="py-2 pl-4 font-medium">Total income</td><td className="py-2 text-right font-semibold">{kes(revenue)}</td></tr>
          <tr className="border-b border-border"><td className="py-2 pt-4 font-semibold">Expenses</td><td /></tr>
          <tr><td className="py-1.5 pl-4 text-muted-foreground">Operating expenses</td><td className="py-1.5 text-right">({kes(expenses)})</td></tr>
          <tr><td className="py-1.5 pl-4 text-muted-foreground">Payroll (net)</td><td className="py-1.5 text-right">({kes(payroll)})</td></tr>
          <tr className="border-b-2 border-border"><td className="py-2 pl-4 font-medium">Total expenses</td><td className="py-2 text-right font-semibold">({kes(expenses + payroll)})</td></tr>
          <tr className={net >= 0 ? "text-success" : "text-destructive"}>
            <td className="py-3 font-bold text-base">{net >= 0 ? "Net surplus" : "Net deficit"}</td>
            <td className="py-3 text-right font-bold text-base">{kes(net)}</td>
          </tr>
        </tbody>
      </table>
      <div className="mt-4 flex gap-2">
        <Button variant="outline" onClick={() => window.print()}><Printer className="h-4 w-4 mr-1" /> Print / Export PDF</Button>
      </div>
    </Card>
  );
}
