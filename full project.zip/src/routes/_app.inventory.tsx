import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { actions, useStore, kes } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/inventory")({
  component: InventoryPage,
});

function InventoryPage() {
  const items = useStore((s) => s.inventory);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", category: "Stationery", qty: 0, reorderLevel: 10, unitCost: 100 });

  return (
    <div>
      <PageHeader
        title="Inventory & School Store"
        description={`${items.length} items tracked`}
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> Add Item</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Add inventory item</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div><Label>Category</Label><Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} /></div>
                <div><Label>Qty</Label><Input type="number" value={form.qty} onChange={(e) => setForm({ ...form, qty: +e.target.value })} /></div>
                <div><Label>Reorder level</Label><Input type="number" value={form.reorderLevel} onChange={(e) => setForm({ ...form, reorderLevel: +e.target.value })} /></div>
                <div><Label>Unit cost</Label><Input type="number" value={form.unitCost} onChange={(e) => setForm({ ...form, unitCost: +e.target.value })} /></div>
              </div>
              <DialogFooter><Button onClick={() => { actions.addInventory(form); toast.success("Item added"); setOpen(false); }}>Save</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />
      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr><th className="px-4 py-3 text-left">Item</th><th className="px-4 py-3 text-left">Category</th><th className="px-4 py-3 text-right">In stock</th><th className="px-4 py-3 text-right">Unit cost</th><th className="px-4 py-3 text-right">Value</th><th className="px-4 py-3">Status</th></tr>
          </thead>
          <tbody>
            {items.map((i) => {
              const low = i.qty <= i.reorderLevel;
              return (
                <tr key={i.id} className="border-t border-border">
                  <td className="px-4 py-2 font-medium">{i.name}</td>
                  <td className="px-4 py-2"><Badge variant="outline">{i.category}</Badge></td>
                  <td className="px-4 py-2 text-right">{i.qty}</td>
                  <td className="px-4 py-2 text-right">{kes(i.unitCost)}</td>
                  <td className="px-4 py-2 text-right font-semibold">{kes(i.qty * i.unitCost)}</td>
                  <td className="px-4 py-2 text-center">{low ? <Badge variant="destructive">Reorder</Badge> : <Badge variant="secondary" className="bg-success/15 text-success border-0">OK</Badge>}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
