import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { useStore, grade } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Printer, Download } from "lucide-react";

export const Route = createFileRoute("/_app/reports")({
  component: ReportsPage,
});

const SUBJECTS = ["Mathematics", "English", "Kiswahili", "Science", "Social Studies"];

function ReportsPage() {
  const students = useStore((s) => s.students);
  const exams = useStore((s) => s.exams);
  const marks = useStore((s) => s.marks);
  const schoolName = useStore((s) => s.schoolName);
  const motto = useStore((s) => s.schoolMotto);
  const user = useStore((s) => s.currentUser);

  // Parents/students auto-select their own record
  const defaultId = (user?.role === "parent" || user?.role === "student") && user.studentId ? user.studentId : students[0]?.id;
  const [studentId, setStudentId] = useState(defaultId ?? "");
  const [examId, setExamId] = useState(exams[0]?.id ?? "");

  const student = students.find((s) => s.id === studentId);
  const exam = exams.find((e) => e.id === examId);

  const rows = useMemo(() => SUBJECTS.map((sub) => {
    const score = marks.find((m) => m.examId === examId && m.studentId === studentId && m.subject === sub)?.score ?? 0;
    return { subject: sub, score, ...grade(score) };
  }), [marks, examId, studentId]);

  const total = rows.reduce((a, r) => a + r.score, 0);
  const mean = Math.round(total / rows.length);
  const overall = grade(mean);

  return (
    <div>
      <PageHeader
        title="Report Cards"
        description="Auto-generated termly report"
        action={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => window.print()}><Download className="h-4 w-4 mr-1" /> Save PDF</Button>
            <Button onClick={() => window.print()}><Printer className="h-4 w-4 mr-1" /> Print</Button>
          </div>
        }
      />

      <Card className="p-4 mb-4 no-print grid sm:grid-cols-2 gap-3">
        {(user?.role !== "parent" && user?.role !== "student") && (
          <Select value={studentId} onValueChange={setStudentId}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{students.map((s) => <SelectItem key={s.id} value={s.id}>{s.admissionNo} — {s.name}</SelectItem>)}</SelectContent>
          </Select>
        )}
        <Select value={examId} onValueChange={setExamId}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>{exams.map((e) => <SelectItem key={e.id} value={e.id}>{e.name} — {e.term} {e.year}</SelectItem>)}</SelectContent>
        </Select>
      </Card>

      {student && exam && (
        <Card className="p-8 print-area max-w-3xl mx-auto">
          <div className="flex items-start justify-between border-b-2 border-primary pb-4 mb-6">
            <div className="flex gap-3">
              <div className="h-14 w-14 rounded-xl bg-primary text-primary-foreground grid place-items-center font-bold font-display text-2xl">M</div>
              <div>
                <div className="font-display font-bold text-xl">{schoolName}</div>
                <div className="text-xs text-muted-foreground italic">{motto}</div>
                <div className="text-xs mt-1">P.O. Box 1234 · Nairobi · Tel: +254 700 000 000</div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs uppercase text-muted-foreground">Academic Report</div>
              <div className="font-bold">{exam.name}</div>
              <div className="text-xs">{exam.term} · {exam.year}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
            <div><div className="text-xs uppercase text-muted-foreground">Student Name</div><div className="font-semibold">{student.name}</div></div>
            <div><div className="text-xs uppercase text-muted-foreground">Admission No</div><div className="font-mono">{student.admissionNo}</div></div>
            <div><div className="text-xs uppercase text-muted-foreground">Class</div><div>{student.grade} {student.stream}</div></div>
            <div><div className="text-xs uppercase text-muted-foreground">Gender</div><div>{student.gender === "M" ? "Male" : "Female"}</div></div>
          </div>

          <table className="w-full text-sm mb-6">
            <thead className="bg-muted">
              <tr>
                <th className="px-3 py-2 text-left">Subject</th>
                <th className="px-3 py-2 text-center">Score</th>
                <th className="px-3 py-2 text-center">Grade</th>
                <th className="px-3 py-2 text-left">Remark</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.subject} className="border-b border-border">
                  <td className="px-3 py-2 font-medium">{r.subject}</td>
                  <td className="px-3 py-2 text-center">{r.score}</td>
                  <td className="px-3 py-2 text-center font-semibold">{r.letter}</td>
                  <td className="px-3 py-2">{r.remark}</td>
                </tr>
              ))}
              <tr className="bg-muted font-semibold">
                <td className="px-3 py-2">TOTAL / MEAN</td>
                <td className="px-3 py-2 text-center">{total}</td>
                <td className="px-3 py-2 text-center">{overall.letter}</td>
                <td className="px-3 py-2">Mean: {mean}</td>
              </tr>
            </tbody>
          </table>

          <div className="space-y-3 text-sm">
            <div className="border border-border rounded-lg p-3">
              <div className="text-xs uppercase text-muted-foreground mb-1">Class Teacher's Comment</div>
              <p>A {overall.remark.toLowerCase()} performance this term. Keep working hard and aim higher.</p>
            </div>
            <div className="border border-border rounded-lg p-3">
              <div className="text-xs uppercase text-muted-foreground mb-1">Principal's Comment</div>
              <p>Well done. We look forward to seeing continued progress next term.</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mt-8 pt-4 border-t border-border text-xs">
            <div><div className="font-semibold border-b border-foreground/30 pb-3">_______________</div><div className="mt-1 text-muted-foreground">Class Teacher</div></div>
            <div><div className="font-semibold border-b border-foreground/30 pb-3">_______________</div><div className="mt-1 text-muted-foreground">Principal</div></div>
            <div><div className="font-semibold border-b border-foreground/30 pb-3">_______________</div><div className="mt-1 text-muted-foreground">Parent</div></div>
          </div>
        </Card>
      )}
    </div>
  );
}
