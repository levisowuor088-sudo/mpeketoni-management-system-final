import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { actions, useStore, kes, feeForStudent } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { FileText, Receipt, CalendarCheck, Megaphone, CreditCard, Building2, Smartphone, Printer, CheckCircle2, Loader2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/parent")({
  component: ParentPortal,
});

type PayMethod = "Bank" | "Till" | "M-Pesa";

function ParentPortal() {
  const user = useStore((s) => s.currentUser);
  const students = useStore((s) => s.students);
  const payments = useStore((s) => s.payments);
  const attendance = useStore((s) => s.attendance);
  const announcements = useStore((s) => s.announcements);
  const school = useStore((s) => s.school);
  const state = useStore((x) => x);

  const child = students.find((s) => s.id === user?.studentId) ?? students[0];

  const [payOpen, setPayOpen] = useState(false);
  const [method, setMethod] = useState<PayMethod>("Bank");
  const [amount, setAmount] = useState<number>(0);
  const [phone, setPhone] = useState<string>(child?.parentPhone ?? "");
  const [processing, setProcessing] = useState(false);
  const [confirmed, setConfirmed] = useState<string | null>(null);

  if (!child) return null;

  const myPayments = payments.filter((p) => p.studentId === child.id);
  const myAttendance = attendance.filter((a) => a.studentId === child.id).slice(0, 14);
  const presentCount = myAttendance.filter((a) => a.status === "present").length;
  const billed = feeForStudent(state, child);
  const paid = myPayments.reduce((a, p) => a + p.amount, 0);

  const openPay = () => {
    setMethod("Bank");
    setAmount(child.feeBalance || 5000);
    setPhone(child.parentPhone);
    setConfirmed(null);
    setPayOpen(true);
  };

  const submitPayment = () => {
    if (amount <= 0) { toast.error("Enter a valid amount"); return; }
    setProcessing(true);
    const prefix = method === "Bank" ? "BNK" : method === "Till" ? "TIL" : "MPS";
    const txn = `${prefix}${Math.random().toString(36).slice(2, 9).toUpperCase()}`;

    const msg =
      method === "Bank"
        ? `Bank transfer initiated to ${school.bankName} A/C ${school.bankAccount}. Awaiting confirmation...`
        : method === "Till"
        ? `STK push sent to ${phone} for Till ${school.paybill}. Enter M-Pesa PIN on your phone.`
        : `M-Pesa STK push sent to ${phone}. Confirm on your phone.`;
    toast.info(msg);

    // Simulate gateway callback
    setTimeout(() => {
      actions.recordPayment({
        studentId: child.id,
        amount,
        method: method === "Till" ? "M-Pesa" : (method as "Bank" | "M-Pesa"),
        txnCode: txn,
      });
      setProcessing(false);
      const receipt = `RCP${10000 + payments.length + 1}`;
      setConfirmed(receipt);
      toast.success(`Payment confirmed · Receipt ${receipt} generated · SMS sent`);
    }, 1500);
  };

  const latestReceipt = useStore((s) => s.payments[0]);

  return (
    <div>
      <PageHeader
        title={`Hello, ${user?.name}`}
        description={`Following up on ${child.name}`}
        action={<Button onClick={openPay}><CreditCard className="h-4 w-4 mr-1" /> Pay fees</Button>}
      />

      <div className="grid sm:grid-cols-3 gap-3 mb-6">
        <Card className="p-4"><div className="text-xs text-muted-foreground">Termly fee</div><div className="text-2xl font-bold">{kes(billed)}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Paid so far</div><div className="text-2xl font-bold text-success">{kes(paid)}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Outstanding</div><div className="text-2xl font-bold text-destructive">{kes(child.feeBalance)}</div></Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-5">
          <h3 className="font-display font-semibold mb-3 flex items-center gap-2"><CalendarCheck className="h-4 w-4" /> Recent attendance</h3>
          <div className="text-3xl font-bold mb-3">{myAttendance.length ? Math.round((presentCount / myAttendance.length) * 100) : 0}%</div>
          <div className="flex flex-wrap gap-1.5">
            {myAttendance.map((a) => (
              <div key={a.id} className={`h-7 w-7 rounded-md text-[10px] grid place-items-center font-semibold ${
                a.status === "present" ? "bg-success/15 text-success"
                : a.status === "absent" ? "bg-destructive/15 text-destructive"
                : "bg-warning/15 text-warning"
              }`} title={`${a.date} — ${a.status}`}>
                {a.date.slice(-2)}
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-semibold mb-3 flex items-center gap-2"><Receipt className="h-4 w-4" /> Payment history</h3>
          <div className="space-y-2 text-sm">
            {myPayments.map((p) => (
              <div key={p.id} className="flex justify-between py-1.5 border-b border-border last:border-0">
                <div><div className="font-medium">{p.receiptNo}</div><div className="text-[11px] text-muted-foreground">{p.date} · {p.method} · {p.txnCode}</div></div>
                <div className="font-semibold">{kes(p.amount)}</div>
              </div>
            ))}
            {myPayments.length === 0 && <div className="text-center text-muted-foreground py-4">No payments yet</div>}
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-semibold mb-3 flex items-center gap-2"><FileText className="h-4 w-4" /> Latest report</h3>
          <p className="text-sm text-muted-foreground mb-3">Download your child's latest exam report card.</p>
          <Button asChild><Link to="/reports">Open report</Link></Button>
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-semibold mb-3 flex items-center gap-2"><Megaphone className="h-4 w-4" /> Announcements</h3>
          <div className="space-y-2">
            {announcements.filter((a) => a.audience === "all" || a.audience === "parents").slice(0, 4).map((a) => (
              <div key={a.id} className="text-sm">
                <div className="flex items-center gap-2"><Badge variant="outline" className="text-[10px]">{a.date}</Badge><span className="font-medium">{a.title}</span></div>
                <p className="text-xs text-muted-foreground mt-1">{a.body}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Pay fees dialog */}
      <Dialog open={payOpen} onOpenChange={(o) => { setPayOpen(o); if (!o) { setConfirmed(null); setProcessing(false); } }}>
        <DialogContent className="max-w-md">
          {!confirmed ? (
            <>
              <DialogHeader>
                <DialogTitle>Pay school fees</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="rounded-lg bg-muted/40 p-3 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Student</span><span className="font-medium">{child.name}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Adm No</span><span className="font-mono">{child.admissionNo}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Outstanding</span><span className="font-semibold text-destructive">{kes(child.feeBalance)}</span></div>
                </div>

                <div>
                  <Label className="text-xs">Payment method</Label>
                  <div className="grid grid-cols-3 gap-2 mt-2">
                    {([
                      { id: "Bank", label: "Bank Transfer", Icon: Building2 },
                      { id: "Till", label: "Till / Paybill", Icon: CreditCard },
                      { id: "M-Pesa", label: "M-Pesa STK", Icon: Smartphone },
                    ] as { id: PayMethod; label: string; Icon: typeof Building2 }[]).map(({ id, label, Icon }) => {
                      const active = method === id;
                      return (
                        <button
                          key={id}
                          type="button"
                          onClick={() => setMethod(id)}
                          className={`rounded-lg border p-3 text-xs font-medium flex flex-col items-center gap-1 transition-all ${
                            active ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-primary/50"
                          }`}
                        >
                          <Icon className="h-4 w-4" />
                          {label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {method === "Bank" && (
                  <div className="rounded-lg border border-border p-3 text-xs space-y-1">
                    <div className="font-semibold text-sm mb-1">Bank details</div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Bank</span><span>{school.bankName}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Account</span><span className="font-mono">{school.bankAccount}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Reference</span><span className="font-mono">{child.admissionNo}</span></div>
                  </div>
                )}
                {method === "Till" && (
                  <div className="rounded-lg border border-border p-3 text-xs space-y-1">
                    <div className="font-semibold text-sm mb-1">Till / Paybill</div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Paybill</span><span className="font-mono">{school.paybill}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Account No</span><span className="font-mono">{child.admissionNo}</span></div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="amt" className="text-xs">Amount (KES)</Label>
                    <Input id="amt" type="number" value={amount} onChange={(e) => setAmount(+e.target.value)} />
                  </div>
                  {method !== "Bank" && (
                    <div>
                      <Label htmlFor="ph" className="text-xs">Phone (M-Pesa)</Label>
                      <Input id="ph" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+254..." />
                    </div>
                  )}
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setPayOpen(false)} disabled={processing}>Cancel</Button>
                <Button onClick={submitPayment} disabled={processing}>
                  {processing ? <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Processing...</> : <>Pay {kes(amount)}</>}
                </Button>
              </DialogFooter>
            </>
          ) : (
            <>
              <DialogHeader>
                <DialogTitle className="no-print flex items-center gap-2 text-success">
                  <CheckCircle2 className="h-5 w-5" /> Payment successful
                </DialogTitle>
              </DialogHeader>
              {latestReceipt && (
                <div className="print-area p-2">
                  <div className="text-center border-b-2 border-primary pb-3 mb-3">
                    {school.logo ? (
                      <img src={school.logo} alt="Logo" className="h-14 w-14 mx-auto mb-2 rounded-xl object-cover" />
                    ) : (
                      <div className="h-12 w-12 rounded-xl bg-primary text-primary-foreground grid place-items-center font-bold mx-auto mb-2">{school.name.charAt(0)}</div>
                    )}
                    <div className="font-display font-bold">{school.name}</div>
                    <div className="text-[10px] text-muted-foreground">{school.poBox} · Tel {school.phone}</div>
                    <div className="text-[10px] text-muted-foreground">{school.email} · Paybill {school.paybill}</div>
                    <div className="mt-2 font-semibold text-sm">OFFICIAL RECEIPT</div>
                  </div>
                  <div className="text-sm space-y-1.5">
                    <div className="flex justify-between"><span className="text-muted-foreground">Receipt No</span><span className="font-mono">{latestReceipt.receiptNo}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Date</span><span>{latestReceipt.date}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Student</span><span>{child.name}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Adm No</span><span className="font-mono">{child.admissionNo}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Class</span><span>{child.grade} {child.stream}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Channel</span><span>{method}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Txn Code</span><span className="font-mono">{latestReceipt.txnCode}</span></div>
                  </div>
                  <div className="mt-4 py-3 border-y-2 border-border flex justify-between font-bold text-lg">
                    <span>AMOUNT PAID</span><span>{kes(latestReceipt.amount)}</span>
                  </div>
                  <div className="text-xs text-muted-foreground mt-2">Outstanding balance: <strong className="text-foreground">{kes(child.feeBalance)}</strong></div>
                  <div className="mt-4 text-[10px] text-center text-muted-foreground">Paid by parent portal · {user?.name} · Thank you</div>
                </div>
              )}
              <DialogFooter className="no-print">
                <Button variant="outline" onClick={() => setPayOpen(false)}>Close</Button>
                <Button onClick={() => window.print()}><Printer className="h-4 w-4 mr-1" /> Print receipt</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
