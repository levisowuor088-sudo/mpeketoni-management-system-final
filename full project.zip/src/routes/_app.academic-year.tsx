import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { actions, useStore } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, CalendarRange, Lock, Archive, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/academic-year")({ component: AcademicYearPage });

function AcademicYearPage() {
  const years = useStore((s) => s.academicYears);
  const [open, setOpen] = useState(false);
  const next = (years[0]?.year ?? new Date().getFullYear()) + 1;
  const [form, setForm] = useState({ year: next, startDate: `${next}-01-06`, endDate: `${next}-11-30` });

  return (
    <div>
      <PageHeader
        title="Academic Years"
        description="Open, close and archive academic years"
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> Open new year</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Open academic year</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Year</Label><Input type="number" value={form.year} onChange={(e) => setForm({ ...form, year: +e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-2">
                  <div><Label>Start</Label><Input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} /></div>
                  <div><Label>End</Label><Input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} /></div>
                </div>
                <p className="text-xs text-muted-foreground">Opening a new year automatically closes the previous active year.</p>
              </div>
              <DialogFooter><Button onClick={() => {
                actions.addAcademicYear(form.year, form.startDate, form.endDate);
                actions.logAudit("academic-year.open", `Year ${form.year}`);
                toast.success(`Academic year ${form.year} opened`);
                setOpen(false);
              }}>Open year</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {years.map((y) => (
          <Card key={y.id} className="p-5">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-lg bg-primary/10 text-primary grid place-items-center"><CalendarRange className="h-5 w-5" /></div>
                <div>
                  <div className="font-display font-bold text-xl">{y.year}</div>
                  <div className="text-xs text-muted-foreground">{y.startDate} → {y.endDate}</div>
                </div>
              </div>
              <Badge variant={y.status === "active" ? "default" : y.status === "closed" ? "secondary" : "outline"}>
                {y.status === "active" && <CheckCircle2 className="h-3 w-3 mr-1" />}
                {y.status === "closed" && <Lock className="h-3 w-3 mr-1" />}
                {y.status === "archived" && <Archive className="h-3 w-3 mr-1" />}
                {y.status}
              </Badge>
            </div>
            <div className="mt-4 flex gap-2 flex-wrap">
              {y.status !== "active" && <Button size="sm" variant="outline" onClick={() => { actions.setYearStatus(y.id, "active"); toast.success("Reopened"); }}>Reopen</Button>}
              {y.status === "active" && <Button size="sm" variant="outline" onClick={() => { actions.setYearStatus(y.id, "closed"); toast.success("Closed"); }}>Close</Button>}
              {y.status !== "archived" && <Button size="sm" variant="ghost" onClick={() => { actions.setYearStatus(y.id, "archived"); toast.success("Archived"); }}>Archive</Button>}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
