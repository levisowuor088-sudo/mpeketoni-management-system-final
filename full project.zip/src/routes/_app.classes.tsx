import { createFileRoute } from "@tanstack/react-router";
import { useStore } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users } from "lucide-react";

export const Route = createFileRoute("/_app/classes")({
  component: ClassesPage,
});

function ClassesPage() {
  const classes = useStore((s) => s.classes);
  const students = useStore((s) => s.students);
  const teachers = useStore((s) => s.teachers);

  return (
    <div>
      <PageHeader title="Classes & Streams" description={`${classes.length} active classes`} />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {classes.map((c) => {
          const enrolled = students.filter((s) => s.grade === c.grade && s.stream === c.stream).length;
          const teacher = teachers.find((t) => t.id === c.classTeacherId);
          const fill = (enrolled / c.capacity) * 100;
          return (
            <Card key={c.id} className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="font-display font-bold text-lg">{c.name}</div>
                  <div className="text-xs text-muted-foreground">Class teacher: {teacher?.name ?? "—"}</div>
                </div>
                <Badge variant="outline">{c.stream}</Badge>
              </div>
              <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                <span className="flex items-center gap-1"><Users className="h-3 w-3" /> {enrolled} / {c.capacity}</span>
                <span>{Math.round(fill)}% full</span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div className="h-full bg-primary" style={{ width: `${Math.min(100, fill)}%` }} />
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
