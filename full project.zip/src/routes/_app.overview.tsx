import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { useStore, kes, feeForStudent, grade } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Printer, Download, TrendingUp, Users, GraduationCap, Banknote, AlertTriangle } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export const Route = createFileRoute("/_app/overview")({
  component: OverviewReport,
});

const SUBJECTS = ["Mathematics", "English", "Kiswahili", "Science", "Social Studies"];

function OverviewReport() {
  const s = useStore((x) => x);
  const school = s.school;

  const today = new Date().toISOString().slice(0, 10);
  const stats = useMemo(() => {
    const totalBilled = s.students.reduce((a, st) => a + feeForStudent(s, st), 0);
    const collected = s.payments.reduce((a, p) => a + p.amount, 0);
    const outstanding = s.students.reduce((a, st) => a + st.feeBalance, 0);
    const totalExpenses = s.expenses.reduce((a, e) => a + e.amount, 0);
    const payrollTotal = s.payroll.reduce((a, p) => a + p.net, 0);
    const present = s.attendance.filter((a) => a.date === today && a.status === "present").length;
    const absent = s.attendance.filter((a) => a.date === today && a.status === "absent").length;
    const late = s.attendance.filter((a) => a.date === today && a.status === "late").length;
    const attendanceRate = s.students.length ? Math.round((present / s.students.length) * 100) : 0;
    return { totalBilled, collected, outstanding, totalExpenses, payrollTotal, present, absent, late, attendanceRate };
  }, [s, today]);

  // Grade enrollment
  const byGrade = useMemo(() => {
    const map: Record<string, { grade: string; boys: number; girls: number; total: number }> = {};
    s.students.forEach((st) => {
      const k = st.grade;
      map[k] = map[k] || { grade: k, boys: 0, girls: 0, total: 0 };
      map[k].total++;
      if (st.gender === "M") map[k].boys++; else map[k].girls++;
    });
    return Object.values(map).sort((a, b) => a.grade.localeCompare(b.grade));
  }, [s.students]);

  // Subject performance
  const subjectPerf = useMemo(() => SUBJECTS.map((sub) => {
    const items = s.marks.filter((m) => m.subject === sub);
    const avg = items.length ? Math.round(items.reduce((a, m) => a + m.score, 0) / items.length) : 0;
    return { subject: sub, avg, ...grade(avg) };
  }), [s.marks]);

  // Department staffing
  const departments = useMemo(() => {
    const map: Record<string, { dept: string; staff: number; payroll: number }> = {};
    s.teachers.forEach((t) => {
      map[t.department] = map[t.department] || { dept: t.department, staff: 0, payroll: 0 };
      map[t.department].staff++;
      map[t.department].payroll += t.salary;
    });
    return Object.values(map);
  }, [s.teachers]);

  // Expense breakdown
  const expCategories = useMemo(() => {
    const map: Record<string, number> = {};
    s.expenses.forEach((e) => { map[e.category] = (map[e.category] || 0) + e.amount; });
    return Object.entries(map).map(([category, amount]) => ({ category, amount }));
  }, [s.expenses]);

  const colors = ["var(--color-chart-1)", "var(--color-chart-2)", "var(--color-chart-3)", "var(--color-chart-4)", "var(--color-chart-5)"];

  const netPosition = stats.collected - stats.totalExpenses - stats.payrollTotal;
  const overdueLoans = s.loans.filter((l) => !l.returnedOn && l.dueOn < today).length;
  const lowStock = s.inventory.filter((i) => i.qty <= i.reorderLevel).length;

  return (
    <div>
      <PageHeader
        title="Departmental General Report"
        description="Consolidated snapshot across academics, finance, HR, library, transport & operations"
        action={
          <div className="flex gap-2 no-print">
            <Button variant="outline" onClick={() => window.print()}><Download className="h-4 w-4 mr-1" /> Export PDF</Button>
            <Button onClick={() => window.print()}><Printer className="h-4 w-4 mr-1" /> Print</Button>
          </div>
        }
      />

      <Card className="p-6 print-area">
        {/* Letterhead */}
        <div className="flex items-start justify-between border-b-2 border-primary pb-4 mb-6">
          <div className="flex gap-3">
            {school.logo ? (
              <img src={school.logo} alt="logo" className="h-14 w-14 rounded-xl object-cover" />
            ) : (
              <div className="h-14 w-14 rounded-xl bg-primary text-primary-foreground grid place-items-center font-bold font-display text-2xl">
                {school.name.charAt(0)}
              </div>
            )}
            <div>
              <div className="font-display font-bold text-xl">{school.name}</div>
              <div className="text-xs text-muted-foreground italic">{school.motto}</div>
              <div className="text-xs mt-1">{school.poBox} · {school.phone} · {school.email}</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs uppercase text-muted-foreground">General Report</div>
            <div className="font-bold">Whole-Department Summary</div>
            <div className="text-xs">Generated: {new Date().toLocaleString()}</div>
          </div>
        </div>

        {/* Executive KPIs */}
        <h2 className="font-display font-semibold mb-3">1. Executive Summary</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <KPI icon={Users} tone="chart-1" label="Total Learners" value={s.students.length} sub={`${byGrade.length} grades`} />
          <KPI icon={GraduationCap} tone="chart-3" label="Teaching Staff" value={s.teachers.length} sub={`${departments.length} departments`} />
          <KPI icon={Banknote} tone="chart-2" label="Revenue Collected" value={kes(stats.collected)} sub={`of ${kes(stats.totalBilled)} billed`} />
          <KPI icon={TrendingUp} tone={netPosition >= 0 ? "success" : "destructive"} label="Net Position" value={kes(netPosition)} sub="Income − Expenses − Payroll" />
        </div>

        {/* Section: Academic */}
        <h2 className="font-display font-semibold mb-3">2. Academic Performance</h2>
        <div className="grid lg:grid-cols-2 gap-4 mb-6">
          <div className="border border-border rounded-lg p-4">
            <div className="text-sm font-semibold mb-2">Mean score by subject</div>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={subjectPerf}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="subject" stroke="var(--color-muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8 }} />
                <Bar dataKey="avg" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="border border-border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-xs uppercase"><tr><th className="px-3 py-2 text-left">Subject</th><th className="px-3 py-2 text-center">Mean</th><th className="px-3 py-2 text-center">Grade</th><th className="px-3 py-2 text-left">Remark</th></tr></thead>
              <tbody>
                {subjectPerf.map((r) => (
                  <tr key={r.subject} className="border-t border-border">
                    <td className="px-3 py-2 font-medium">{r.subject}</td>
                    <td className="px-3 py-2 text-center">{r.avg}</td>
                    <td className="px-3 py-2 text-center font-semibold">{r.letter}</td>
                    <td className="px-3 py-2 text-xs">{r.remark}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section: Enrollment */}
        <h2 className="font-display font-semibold mb-3">3. Enrollment by Grade</h2>
        <div className="border border-border rounded-lg overflow-hidden mb-6">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs uppercase"><tr><th className="px-3 py-2 text-left">Grade</th><th className="px-3 py-2 text-right">Boys</th><th className="px-3 py-2 text-right">Girls</th><th className="px-3 py-2 text-right">Total</th></tr></thead>
            <tbody>
              {byGrade.map((g) => (
                <tr key={g.grade} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">{g.grade}</td>
                  <td className="px-3 py-2 text-right">{g.boys}</td>
                  <td className="px-3 py-2 text-right">{g.girls}</td>
                  <td className="px-3 py-2 text-right font-semibold">{g.total}</td>
                </tr>
              ))}
              <tr className="bg-muted font-semibold">
                <td className="px-3 py-2">TOTAL</td>
                <td className="px-3 py-2 text-right">{byGrade.reduce((a, g) => a + g.boys, 0)}</td>
                <td className="px-3 py-2 text-right">{byGrade.reduce((a, g) => a + g.girls, 0)}</td>
                <td className="px-3 py-2 text-right">{s.students.length}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Section: Attendance */}
        <h2 className="font-display font-semibold mb-3">4. Attendance — Today ({today})</h2>
        <div className="grid grid-cols-4 gap-3 mb-6">
          <Mini label="Rate" value={`${stats.attendanceRate}%`} tone="primary" />
          <Mini label="Present" value={stats.present} tone="success" />
          <Mini label="Absent" value={stats.absent} tone="destructive" />
          <Mini label="Late" value={stats.late} tone="warning" />
        </div>

        {/* Section: Finance */}
        <h2 className="font-display font-semibold mb-3">5. Financial Position</h2>
        <div className="grid lg:grid-cols-2 gap-4 mb-6">
          <div className="border border-border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <tbody>
                <tr className="border-b border-border"><td className="px-3 py-2">Total billed (term)</td><td className="px-3 py-2 text-right font-semibold">{kes(stats.totalBilled)}</td></tr>
                <tr className="border-b border-border"><td className="px-3 py-2">Collected</td><td className="px-3 py-2 text-right text-success font-semibold">{kes(stats.collected)}</td></tr>
                <tr className="border-b border-border"><td className="px-3 py-2">Outstanding</td><td className="px-3 py-2 text-right text-destructive font-semibold">{kes(stats.outstanding)}</td></tr>
                <tr className="border-b border-border"><td className="px-3 py-2">Operating expenses</td><td className="px-3 py-2 text-right">({kes(stats.totalExpenses)})</td></tr>
                <tr className="border-b border-border"><td className="px-3 py-2">Payroll (net)</td><td className="px-3 py-2 text-right">({kes(stats.payrollTotal)})</td></tr>
                <tr className="bg-muted"><td className="px-3 py-2 font-semibold">Net position</td><td className={`px-3 py-2 text-right font-bold ${netPosition >= 0 ? "text-success" : "text-destructive"}`}>{kes(netPosition)}</td></tr>
              </tbody>
            </table>
          </div>
          <div className="border border-border rounded-lg p-4">
            <div className="text-sm font-semibold mb-2">Expense breakdown</div>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={expCategories} dataKey="amount" nameKey="category" innerRadius={45} outerRadius={75} paddingAngle={3}>
                  {expCategories.map((_, i) => <Cell key={i} fill={colors[i % colors.length]} />)}
                </Pie>
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Tooltip formatter={(v: number) => kes(v)} contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Section: HR / Departments */}
        <h2 className="font-display font-semibold mb-3">6. Departments & Staffing</h2>
        <div className="border border-border rounded-lg overflow-hidden mb-6">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs uppercase"><tr><th className="px-3 py-2 text-left">Department</th><th className="px-3 py-2 text-right">Staff</th><th className="px-3 py-2 text-right">Monthly Payroll</th></tr></thead>
            <tbody>
              {departments.map((d) => (
                <tr key={d.dept} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">{d.dept}</td>
                  <td className="px-3 py-2 text-right">{d.staff}</td>
                  <td className="px-3 py-2 text-right">{kes(d.payroll)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Section: Operations */}
        <h2 className="font-display font-semibold mb-3">7. Operations Snapshot</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <Mini label="Library books" value={s.books.reduce((a, b) => a + b.copies, 0)} tone="chart-1" />
          <Mini label="Active loans" value={s.loans.filter((l) => !l.returnedOn).length} tone="chart-2" />
          <Mini label="Overdue loans" value={overdueLoans} tone="destructive" />
          <Mini label="Transport routes" value={s.routes.length} tone="chart-3" />
          <Mini label="Inventory items" value={s.inventory.length} tone="chart-4" />
          <Mini label="Low-stock alerts" value={lowStock} tone="warning" />
          <Mini label="Defaulters" value={s.students.filter((x) => x.feeBalance > 0).length} tone="destructive" />
          <Mini label="Announcements" value={s.announcements.length} tone="chart-5" />
        </div>

        {/* Risks & recommendations */}
        <h2 className="font-display font-semibold mb-3">8. Risks & Recommendations</h2>
        <div className="space-y-2 mb-6">
          {stats.outstanding > stats.collected * 0.3 && (
            <Alert tone="destructive">Outstanding fees ({kes(stats.outstanding)}) exceed 30% of collection. Activate defaulter follow-up.</Alert>
          )}
          {stats.attendanceRate < 90 && (
            <Alert tone="warning">Attendance below 90% today — investigate absenteeism in affected classes.</Alert>
          )}
          {lowStock > 0 && (
            <Alert tone="warning">{lowStock} inventory item(s) at or below reorder level — schedule procurement.</Alert>
          )}
          {overdueLoans > 0 && (
            <Alert tone="warning">{overdueLoans} library book(s) overdue — issue return reminders.</Alert>
          )}
          {netPosition < 0 && (
            <Alert tone="destructive">School is running at a deficit this period. Review expense lines and accelerate collections.</Alert>
          )}
          {stats.outstanding === 0 && netPosition >= 0 && stats.attendanceRate >= 90 && (
            <Alert tone="success">All key indicators are healthy. Maintain current operational standards.</Alert>
          )}
        </div>

        {/* Sign-off */}
        <div className="grid grid-cols-3 gap-6 mt-10 pt-4 border-t border-border text-xs">
          <div><div className="font-semibold border-b border-foreground/30 pb-4">_______________</div><div className="mt-1 text-muted-foreground">Prepared by · Administrator</div></div>
          <div><div className="font-semibold border-b border-foreground/30 pb-4">_______________</div><div className="mt-1 text-muted-foreground">Reviewed by · Principal</div></div>
          <div><div className="font-semibold border-b border-foreground/30 pb-4">_______________</div><div className="mt-1 text-muted-foreground">Board of Management</div></div>
        </div>
      </Card>
    </div>
  );
}

function KPI({ icon: Icon, tone, label, value, sub }: { icon: any; tone: string; label: string; value: any; sub?: string }) {
  return (
    <div className="border border-border rounded-lg p-4">
      <div className={`h-9 w-9 rounded-lg bg-${tone}/10 text-${tone} grid place-items-center mb-2`}><Icon className="h-4 w-4" /></div>
      <div className="text-xl font-bold font-display">{value}</div>
      <div className="text-[11px] text-muted-foreground">{label}</div>
      {sub && <div className="text-[10px] text-muted-foreground mt-0.5">{sub}</div>}
    </div>
  );
}
function Mini({ label, value, tone }: { label: string; value: any; tone: string }) {
  return (
    <div className={`rounded-lg border border-border p-3 bg-${tone}/5`}>
      <div className={`text-xl font-bold text-${tone}`}>{value}</div>
      <div className="text-[10px] uppercase text-muted-foreground tracking-wide">{label}</div>
    </div>
  );
}
function Alert({ tone, children }: { tone: string; children: React.ReactNode }) {
  return (
    <div className={`rounded-lg border border-${tone}/30 bg-${tone}/5 text-${tone} px-3 py-2 text-sm flex items-start gap-2`}>
      <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" /> <span className="text-foreground/90">{children}</span>
      <Badge variant="outline" className={`ml-auto text-[10px] border-${tone}/40 text-${tone}`}>{tone}</Badge>
    </div>
  );
}
