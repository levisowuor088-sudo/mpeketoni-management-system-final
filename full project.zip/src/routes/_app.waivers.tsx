import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/useAuth";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/waivers")({
  head: () => ({ meta: [{ title: "Waivers Audit Log — Levis Developers" }] }),
  component: WaiversAuditPage,
});

const KES = (n: number) => `KES ${Number(n).toLocaleString()}`;

interface WaiverRow {
  id: string;
  amount: number;
  reason: string;
  created_at: string;
  admin_id: string;
  student_id: string;
  students?: { full_name: string; admission_no: string } | null;
}

interface AdminProfile { id: string; full_name: string }

function WaiversAuditPage() {
  const auth = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!auth.loading && auth.role && auth.role !== "admin" && auth.role !== "accountant") {
      toast.error("Waivers audit is restricted.");
      navigate({ to: "/dashboard" });
    }
  }, [auth.loading, auth.role, navigate]);

  const q = useQuery({
    queryKey: ["waivers"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("waivers_log")
        .select("id, amount, reason, created_at, admin_id, student_id, students(full_name, admission_no)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as WaiverRow[];
    },
    enabled: auth.role === "admin" || auth.role === "accountant",
  });

  return (
    <div>
      <PageHeader title="Waivers Audit Log" description="Every fee waiver — admin, student, amount, reason, timestamp." />
      <Card className="overflow-x-auto">
        {q.isLoading ? (
          <div className="p-6 flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading…</div>
        ) : q.error ? (
          <div className="p-6 text-sm text-destructive">Failed to load: {(q.error as Error).message}</div>
        ) : q.data?.length === 0 ? (
          <div className="p-10 text-center text-sm text-muted-foreground">No waivers recorded yet.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="text-left px-3 py-2">Timestamp</th>
                <th className="text-left px-3 py-2">Student</th>
                <th className="text-right px-3 py-2">Amount</th>
                <th className="text-left px-3 py-2">Reason</th>
                <th className="text-left px-3 py-2">Admin</th>
              </tr>
            </thead>
            <tbody>
              {q.data?.map((w) => (
                <tr key={w.id} className="border-b">
                  <td className="px-3 py-2 text-xs text-muted-foreground whitespace-nowrap">{new Date(w.created_at).toLocaleString()}</td>
                  <td className="px-3 py-2">{w.students?.full_name} <span className="text-xs text-muted-foreground">({w.students?.admission_no})</span></td>
                  <td className="px-3 py-2 text-right font-semibold">{KES(Number(w.amount))}</td>
                  <td className="px-3 py-2 text-xs max-w-md">{w.reason}</td>
                  <td className="px-3 py-2"><Badge variant="secondary"><ShieldCheck className="h-3 w-3 mr-1" />{w.admin_id.slice(0, 8)}…</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}
