import { createFileRoute } from "@tanstack/react-router";
import { useStore, kes, feeForStudent } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_app/fees")({
  component: FeesPage,
});

function FeesPage() {
  const s = useStore((x) => x);
  const totalBilled = s.students.reduce((a, st) => a + feeForStudent(s, st), 0);
  const collected = s.payments.reduce((a, p) => a + p.amount, 0);
  const outstanding = s.students.reduce((a, st) => a + st.feeBalance, 0);
  const defaulters = s.students.filter((x) => x.feeBalance > 0);

  return (
    <div>
      <PageHeader title="Fee Management" description="Fee structures, billing and defaulters" />

      <div className="grid sm:grid-cols-3 gap-3 mb-6">
        <Card className="p-4"><div className="text-xs text-muted-foreground">Total billed (term)</div><div className="text-2xl font-bold">{kes(totalBilled)}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Collected</div><div className="text-2xl font-bold text-success">{kes(collected)}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Outstanding</div><div className="text-2xl font-bold text-destructive">{kes(outstanding)}</div></Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="overflow-hidden">
          <div className="px-4 py-3 border-b border-border font-display font-semibold">Fee structures</div>
          <table className="w-full text-sm">
            <thead className="bg-muted/30 text-xs uppercase text-muted-foreground">
              <tr><th className="px-4 py-2 text-left">Grade</th><th className="px-4 py-2 text-right">Tuition</th><th className="px-4 py-2 text-right">Transport</th><th className="px-4 py-2 text-right">Meals</th><th className="px-4 py-2 text-right">Total</th></tr>
            </thead>
            <tbody>
              {s.feeStructures.map((f) => (
                <tr key={f.id} className="border-t border-border">
                  <td className="px-4 py-2 font-medium">{f.grade}</td>
                  <td className="px-4 py-2 text-right">{kes(f.tuition)}</td>
                  <td className="px-4 py-2 text-right">{kes(f.transport)}</td>
                  <td className="px-4 py-2 text-right">{kes(f.meals)}</td>
                  <td className="px-4 py-2 text-right font-semibold">{kes(f.tuition + f.transport + f.meals + f.activities)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <Card className="overflow-hidden">
          <div className="px-4 py-3 border-b border-border font-display font-semibold flex items-center justify-between">
            <span>Defaulters</span>
            <Badge variant="destructive">{defaulters.length}</Badge>
          </div>
          <table className="w-full text-sm">
            <thead className="bg-muted/30 text-xs uppercase text-muted-foreground">
              <tr><th className="px-4 py-2 text-left">Student</th><th className="px-4 py-2 text-left">Class</th><th className="px-4 py-2 text-right">Balance</th></tr>
            </thead>
            <tbody>
              {defaulters.map((d) => (
                <tr key={d.id} className="border-t border-border">
                  <td className="px-4 py-2">{d.name}</td>
                  <td className="px-4 py-2">{d.grade}</td>
                  <td className="px-4 py-2 text-right"><Badge variant="destructive">{kes(d.feeBalance)}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
          {defaulters.length === 0 && <div className="p-8 text-center text-muted-foreground text-sm">All fees cleared 🎉</div>}
        </Card>
      </div>
    </div>
  );
}
