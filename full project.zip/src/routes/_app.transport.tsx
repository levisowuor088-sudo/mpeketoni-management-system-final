import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { actions, useStore, kes } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Bus, User } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/transport")({
  component: TransportPage,
});

function TransportPage() {
  const routes = useStore((s) => s.routes);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", vehicleReg: "", driver: "", capacity: 30, fee: 4500 });

  return (
    <div>
      <PageHeader
        title="Transport"
        description={`${routes.length} routes operating`}
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> Add Route</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New route</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><Label>Route name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div><Label>Vehicle reg</Label><Input value={form.vehicleReg} onChange={(e) => setForm({ ...form, vehicleReg: e.target.value })} /></div>
                <div><Label>Driver</Label><Input value={form.driver} onChange={(e) => setForm({ ...form, driver: e.target.value })} /></div>
                <div><Label>Capacity</Label><Input type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: +e.target.value })} /></div>
                <div><Label>Termly fee</Label><Input type="number" value={form.fee} onChange={(e) => setForm({ ...form, fee: +e.target.value })} /></div>
              </div>
              <DialogFooter><Button onClick={() => { actions.addRoute(form); toast.success("Route added"); setOpen(false); }}>Save</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {routes.map((r) => (
          <Card key={r.id} className="p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="h-12 w-12 rounded-xl bg-accent/20 text-accent-foreground grid place-items-center"><Bus className="h-6 w-6" /></div>
              <div>
                <div className="font-display font-semibold">{r.name}</div>
                <div className="text-xs text-muted-foreground font-mono">{r.vehicleReg}</div>
              </div>
            </div>
            <div className="text-sm space-y-1.5">
              <div className="flex items-center gap-2 text-muted-foreground"><User className="h-3 w-3" /> {r.driver}</div>
              <div className="flex justify-between"><span className="text-muted-foreground">Capacity</span><span>{r.capacity} seats</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Termly fee</span><span className="font-semibold">{kes(r.fee)}</span></div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
