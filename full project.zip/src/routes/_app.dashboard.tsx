import { createFileRoute } from "@tanstack/react-router";
import { useStore, kes } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Users,
  GraduationCap,
  Banknote,
  AlertCircle,
  TrendingUp,
  CalendarCheck,
  Megaphone,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export const Route = createFileRoute("/_app/dashboard")({
  component: Dashboard,
});

function Dashboard() {
  const s = useStore((x) => x);
  const totalStudents = s.students.length;
  const totalTeachers = s.teachers.length;
  const revenue = s.payments.reduce((a, p) => a + p.amount, 0);
  const pending = s.students.reduce((a, st) => a + st.feeBalance, 0);
  const defaulters = s.students.filter((x) => x.feeBalance > 0).length;

  const today = new Date().toISOString().slice(0, 10);
  const presentToday = s.attendance.filter((a) => a.date === today && a.status === "present").length;
  const absentToday = s.attendance.filter((a) => a.date === today && a.status === "absent").length;
  const attendanceRate = totalStudents ? Math.round((presentToday / totalStudents) * 100) : 0;

  // Weekly revenue
  const last7 = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const ds = d.toISOString().slice(0, 10);
    const total = s.payments.filter((p) => p.date === ds).reduce((a, p) => a + p.amount, 0);
    return { day: d.toLocaleDateString("en", { weekday: "short" }), revenue: total };
  });

  // Subject averages
  const subjectAvg = ["Mathematics", "English", "Kiswahili", "Science", "Social Studies"].map((sub) => {
    const items = s.marks.filter((m) => m.subject === sub);
    const avg = items.length ? Math.round(items.reduce((a, m) => a + m.score, 0) / items.length) : 0;
    return { subject: sub.slice(0, 4), avg };
  });

  // Gender split
  const gender = [
    { name: "Boys", value: s.students.filter((x) => x.gender === "M").length },
    { name: "Girls", value: s.students.filter((x) => x.gender === "F").length },
  ];
  const colors = ["var(--color-chart-1)", "var(--color-chart-2)"];

  const stats = [
    { label: "Total Students", value: totalStudents, icon: Users, tone: "text-chart-1", bg: "bg-chart-1/10" },
    { label: "Total Teachers", value: totalTeachers, icon: GraduationCap, tone: "text-chart-3", bg: "bg-chart-3/10" },
    { label: "Revenue Collected", value: kes(revenue), icon: Banknote, tone: "text-chart-2", bg: "bg-chart-2/10" },
    { label: "Pending Fees", value: kes(pending), icon: AlertCircle, tone: "text-chart-5", bg: "bg-chart-5/10" },
  ];

  return (
    <div>
      <PageHeader
        title={`Welcome, ${s.currentUser?.name.split(" ")[0]}`}
        description="Here's a snapshot of school operations today."
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="p-5">
              <div className={`h-10 w-10 rounded-lg ${stat.bg} ${stat.tone} grid place-items-center mb-3`}>
                <Icon className="h-5 w-5" />
              </div>
              <div className="text-2xl font-bold font-display">{stat.value}</div>
              <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
            </Card>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-3 gap-4 mb-6">
        <Card className="lg:col-span-2 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-display font-semibold">Fee collection — last 7 days</h3>
              <p className="text-xs text-muted-foreground">Daily payments processed</p>
            </div>
            <Badge variant="secondary" className="gap-1"><TrendingUp className="h-3 w-3" /> +12.4%</Badge>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={last7}>
              <defs>
                <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="day" stroke="var(--color-muted-foreground)" fontSize={12} />
              <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
              <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8 }} />
              <Area type="monotone" dataKey="revenue" stroke="var(--color-primary)" strokeWidth={2} fill="url(#rev)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-semibold mb-1">Student composition</h3>
          <p className="text-xs text-muted-foreground mb-4">Gender distribution</p>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={gender} dataKey="value" innerRadius={55} outerRadius={85} paddingAngle={4}>
                {gender.map((_, i) => <Cell key={i} fill={colors[i]} />)}
              </Pie>
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-4 mb-6">
        <Card className="lg:col-span-2 p-5">
          <h3 className="font-display font-semibold mb-1">Subject performance</h3>
          <p className="text-xs text-muted-foreground mb-4">Mean score by subject</p>
          <ResponsiveContainer width="100%" height={230}>
            <BarChart data={subjectAvg}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="subject" stroke="var(--color-muted-foreground)" fontSize={12} />
              <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
              <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8 }} />
              <Bar dataKey="avg" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5">
          <div className="flex items-center justify-between mb-1">
            <h3 className="font-display font-semibold">Today's attendance</h3>
            <CalendarCheck className="h-4 w-4 text-muted-foreground" />
          </div>
          <p className="text-xs text-muted-foreground mb-4">{new Date().toLocaleDateString("en", { dateStyle: "full" })}</p>
          <div className="text-4xl font-bold font-display">{attendanceRate}%</div>
          <div className="mt-2 h-2 rounded-full bg-muted overflow-hidden">
            <div className="h-full bg-success" style={{ width: `${attendanceRate}%` }} />
          </div>
          <div className="grid grid-cols-3 gap-2 mt-4 text-center">
            <div className="rounded-lg bg-success/10 text-success py-2">
              <div className="font-bold">{presentToday}</div>
              <div className="text-[10px]">Present</div>
            </div>
            <div className="rounded-lg bg-destructive/10 text-destructive py-2">
              <div className="font-bold">{absentToday}</div>
              <div className="text-[10px]">Absent</div>
            </div>
            <div className="rounded-lg bg-warning/10 text-warning py-2">
              <div className="font-bold">{defaulters}</div>
              <div className="text-[10px]">Defaulters</div>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-5">
          <h3 className="font-display font-semibold mb-3">Recent payments</h3>
          <div className="space-y-2">
            {s.payments.slice(0, 6).map((p) => {
              const st = s.students.find((x) => x.id === p.studentId);
              return (
                <div key={p.id} className="flex items-center justify-between text-sm py-1.5 border-b border-border last:border-0">
                  <div>
                    <div className="font-medium">{st?.name}</div>
                    <div className="text-[11px] text-muted-foreground">{p.receiptNo} · {p.method}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{kes(p.amount)}</div>
                    <div className="text-[11px] text-muted-foreground">{p.date}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-semibold mb-3 flex items-center gap-2"><Megaphone className="h-4 w-4" /> Announcements</h3>
          <div className="space-y-3">
            {s.announcements.slice(0, 4).map((a) => (
              <div key={a.id} className="rounded-lg border border-border p-3">
                <div className="flex items-center justify-between">
                  <div className="font-medium text-sm">{a.title}</div>
                  <Badge variant="outline" className="text-[10px]">{a.audience}</Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{a.body}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
