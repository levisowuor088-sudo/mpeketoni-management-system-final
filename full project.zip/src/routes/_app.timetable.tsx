import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { actions, useStore } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Plus, Printer, X } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/timetable")({ component: TimetablePage });

const DAYS: Array<"Mon" | "Tue" | "Wed" | "Thu" | "Fri"> = ["Mon", "Tue", "Wed", "Thu", "Fri"];
const PERIODS = [1, 2, 3, 4, 5, 6, 7, 8];

function TimetablePage() {
  const classes = useStore((s) => s.classes);
  const teachers = useStore((s) => s.teachers);
  const subjects = useStore((s) => s.subjects);
  const slots = useStore((s) => s.timetable);
  const user = useStore((s) => s.currentUser);

  const [view, setView] = useState<"class" | "teacher">("class");
  const [classId, setClassId] = useState(classes[0]?.id ?? "");
  const [teacherId, setTeacherId] = useState(teachers[0]?.id ?? "");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ day: "Mon" as typeof DAYS[number], period: 1, classId: classes[0]?.id ?? "", subject: subjects[0]?.name ?? "", teacherId: teachers[0]?.id ?? "" });

  const filtered = useMemo(() => slots.filter((s) => view === "class" ? s.classId === classId : s.teacherId === teacherId), [slots, view, classId, teacherId]);
  const cell = (d: string, p: number) => filtered.find((s) => s.day === d && s.period === p);

  const submit = () => {
    const res = actions.addTimetableSlot(form);
    if (!res.ok) { toast.error(res.reason ?? "Conflict"); return; }
    actions.logAudit("timetable.add", `${form.day} P${form.period} · ${form.subject}`);
    toast.success("Slot added");
    setOpen(false);
  };

  const canEdit = user?.role === "super_admin" || user?.role === "principal" || user?.role === "deputy_principal" || user?.role === "registrar";

  return (
    <div>
      <PageHeader
        title="Timetable"
        description="Weekly schedule with automatic conflict checks"
        action={
          <div className="flex gap-2 no-print">
            <Button variant="outline" onClick={() => window.print()}><Printer className="h-4 w-4 mr-1" /> Print</Button>
            {canEdit && (
              <Dialog open={open} onOpenChange={setOpen}>
                <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> Add slot</Button></DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>Schedule lesson</DialogTitle></DialogHeader>
                  <div className="grid grid-cols-2 gap-3">
                    <div><Label>Day</Label>
                      <Select value={form.day} onValueChange={(v) => setForm({ ...form, day: v as typeof DAYS[number] })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>{DAYS.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div><Label>Period</Label>
                      <Select value={String(form.period)} onValueChange={(v) => setForm({ ...form, period: Number(v) })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>{PERIODS.map((p) => <SelectItem key={p} value={String(p)}>Period {p}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div className="col-span-2"><Label>Class</Label>
                      <Select value={form.classId} onValueChange={(v) => setForm({ ...form, classId: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>{classes.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div><Label>Subject</Label>
                      <Select value={form.subject} onValueChange={(v) => setForm({ ...form, subject: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>{subjects.map((s) => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div><Label>Teacher</Label>
                      <Select value={form.teacherId} onValueChange={(v) => setForm({ ...form, teacherId: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>{teachers.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter><Button onClick={submit}>Save slot</Button></DialogFooter>
                </DialogContent>
              </Dialog>
            )}
          </div>
        }
      />

      <Card className="p-4 mb-4 no-print flex flex-wrap items-end gap-3">
        <div>
          <Label className="text-xs">View by</Label>
          <Select value={view} onValueChange={(v) => setView(v as "class" | "teacher")}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="class">Class</SelectItem><SelectItem value="teacher">Teacher</SelectItem></SelectContent>
          </Select>
        </div>
        {view === "class" ? (
          <div className="flex-1 min-w-[200px]"><Label className="text-xs">Class</Label>
            <Select value={classId} onValueChange={setClassId}><SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{classes.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        ) : (
          <div className="flex-1 min-w-[200px]"><Label className="text-xs">Teacher</Label>
            <Select value={teacherId} onValueChange={setTeacherId}><SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{teachers.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        )}
      </Card>

      <Card className="p-3 print-area overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr>
              <th className="border border-border bg-muted px-2 py-2 text-left w-20">Period</th>
              {DAYS.map((d) => <th key={d} className="border border-border bg-muted px-2 py-2 text-left">{d}</th>)}
            </tr>
          </thead>
          <tbody>
            {PERIODS.map((p) => (
              <tr key={p}>
                <td className="border border-border px-2 py-3 font-semibold bg-muted/40">Period {p}</td>
                {DAYS.map((d) => {
                  const c = cell(d, p);
                  return (
                    <td key={d} className="border border-border p-2 align-top h-16">
                      {c ? (
                        <div className="rounded-md bg-primary/10 text-primary p-2 relative group">
                          <div className="font-semibold text-[11px]">{c.subject}</div>
                          <div className="text-[10px] opacity-80">{view === "class" ? teachers.find((t) => t.id === c.teacherId)?.name : classes.find((cl) => cl.id === c.classId)?.name}</div>
                          {canEdit && (
                            <button onClick={() => actions.deleteTimetableSlot(c.id)} className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 no-print">
                              <X className="h-3 w-3" />
                            </button>
                          )}
                        </div>
                      ) : (
                        <div className="text-muted-foreground/30 text-center">—</div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
