import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { actions, useStore } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { GraduationCap, ArrowRight, RotateCcw, Award } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/promotions")({ component: PromotionsPage });

const GRADES = ["Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8"];

function PromotionsPage() {
  const students = useStore((s) => s.students);
  const auditLog = useStore((s) => s.auditLog);
  const [fromGrade, setFromGrade] = useState("Grade 4");
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const inClass = useMemo(() => students.filter((s) => s.grade === fromGrade), [students, fromGrade]);
  const nextGrade = useMemo(() => {
    const i = GRADES.indexOf(fromGrade);
    return i >= 0 && i < GRADES.length - 1 ? GRADES[i + 1] : null;
  }, [fromGrade]);
  const isFinal = fromGrade === "Grade 8";

  const toggle = (id: string) => {
    const n = new Set(selected);
    n.has(id) ? n.delete(id) : n.add(id);
    setSelected(n);
  };
  const all = () => setSelected(new Set(inClass.map((s) => s.id)));

  const run = (toGrade: string | "graduate") => {
    if (selected.size === 0) { toast.error("Select at least one student"); return; }
    const label = toGrade === "graduate" ? `graduate ${selected.size} students from ${fromGrade}` : `promote ${selected.size} students to ${toGrade}`;
    if (!confirm(`Confirm: ${label}? This action is logged.`)) return;
    actions.promoteClass(fromGrade, toGrade, Array.from(selected));
    toast.success(`Done — ${label}`);
    setSelected(new Set());
  };

  const recentPromotions = auditLog.filter((a) => a.action === "promotion").slice(0, 5);

  return (
    <div>
      <PageHeader title="Student Promotion" description="Promote, repeat or graduate students at year-end" />

      <Card className="p-4 mb-4 flex flex-wrap items-end gap-3">
        <div className="min-w-[200px]">
          <Label className="text-xs">Source class</Label>
          <Select value={fromGrade} onValueChange={(v) => { setFromGrade(v); setSelected(new Set()); }}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{GRADES.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="text-sm text-muted-foreground flex-1">
          {inClass.length} students · {selected.size} selected
        </div>
        <Button variant="outline" size="sm" onClick={all}>Select all</Button>
        <Button variant="outline" size="sm" onClick={() => setSelected(new Set())}>Clear</Button>
      </Card>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2 max-h-[500px] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted sticky top-0">
              <tr><th className="w-10"></th><th className="text-left px-2 py-2">Adm. No</th><th className="text-left px-2 py-2">Name</th><th className="text-left px-2 py-2">Stream</th></tr>
            </thead>
            <tbody>
              {inClass.map((s) => (
                <tr key={s.id} className="border-b border-border">
                  <td className="px-2"><Checkbox checked={selected.has(s.id)} onCheckedChange={() => toggle(s.id)} /></td>
                  <td className="px-2 py-2 font-mono text-xs">{s.admissionNo}</td>
                  <td className="px-2 py-2">{s.name}</td>
                  <td className="px-2 py-2"><Badge variant="secondary" className="text-[10px]">{s.stream}</Badge></td>
                </tr>
              ))}
              {inClass.length === 0 && <tr><td colSpan={4} className="text-center py-8 text-muted-foreground">No students in this class</td></tr>}
            </tbody>
          </table>
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-semibold mb-3">Actions</h3>
          <div className="space-y-2">
            {!isFinal && nextGrade && (
              <Button className="w-full justify-start" onClick={() => run(nextGrade)}>
                <ArrowRight className="h-4 w-4 mr-2" /> Promote to {nextGrade}
              </Button>
            )}
            {isFinal && (
              <Button className="w-full justify-start" onClick={() => run("graduate")}>
                <Award className="h-4 w-4 mr-2" /> Graduate to Alumni
              </Button>
            )}
            <Button variant="outline" className="w-full justify-start" onClick={() => run(fromGrade)}>
              <RotateCcw className="h-4 w-4 mr-2" /> Repeat current class
            </Button>
          </div>
          <div className="mt-6 pt-4 border-t border-border">
            <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-2 flex items-center gap-1"><GraduationCap className="h-3 w-3" /> Recent promotion logs</h4>
            <div className="space-y-2 text-xs">
              {recentPromotions.map((p) => (
                <div key={p.id} className="border border-border rounded-md p-2">
                  <div className="font-medium">{p.detail}</div>
                  <div className="text-[10px] text-muted-foreground">{p.userName} · {new Date(p.timestamp).toLocaleString()}</div>
                </div>
              ))}
              {recentPromotions.length === 0 && <div className="text-muted-foreground italic">No promotions yet</div>}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
