import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { actions, useStore, type AttendanceRecord } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/attendance")({
  component: AttendancePage,
});

function AttendancePage() {
  const students = useStore((s) => s.students);
  const classes = useStore((s) => s.classes);
  const attendance = useStore((s) => s.attendance);
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [cls, setCls] = useState(classes[0]?.id ?? "");
  const selected = classes.find((c) => c.id === cls);
  const classStudents = useMemo(
    () => students.filter((s) => selected && s.grade === selected.grade && s.stream === selected.stream),
    [students, selected],
  );

  const existing = useMemo(() => {
    const m: Record<string, AttendanceRecord["status"]> = {};
    attendance.filter((a) => a.date === date).forEach((a) => { m[a.studentId] = a.status; });
    return m;
  }, [attendance, date]);

  const [draft, setDraft] = useState<Record<string, AttendanceRecord["status"]>>({});
  const get = (id: string) => draft[id] ?? existing[id] ?? "present";

  const save = () => {
    const all: Record<string, AttendanceRecord["status"]> = {};
    classStudents.forEach((s) => { all[s.id] = get(s.id); });
    actions.markAttendance(date, all);
    toast.success(`Saved attendance for ${classStudents.length} students`);
    setDraft({});
  };

  const stats = {
    present: classStudents.filter((s) => get(s.id) === "present").length,
    absent: classStudents.filter((s) => get(s.id) === "absent").length,
    late: classStudents.filter((s) => get(s.id) === "late").length,
  };

  return (
    <div>
      <PageHeader title="Attendance" description="Daily class attendance register" action={<Button onClick={save}>Save Register</Button>} />

      <Card className="p-4 mb-4 flex flex-col sm:flex-row gap-3">
        <div className="flex-1">
          <Select value={cls} onValueChange={setCls}>
            <SelectTrigger><SelectValue placeholder="Choose class" /></SelectTrigger>
            <SelectContent>
              {classes.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="sm:w-48" />
      </Card>

      <div className="grid grid-cols-3 gap-3 mb-4">
        <Card className="p-4"><div className="text-xs text-muted-foreground">Present</div><div className="text-2xl font-bold text-success">{stats.present}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Absent</div><div className="text-2xl font-bold text-destructive">{stats.absent}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Late</div><div className="text-2xl font-bold text-warning">{stats.late}</div></Card>
      </div>

      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr><th className="px-4 py-3 text-left">Adm</th><th className="px-4 py-3 text-left">Student</th><th className="px-4 py-3">Status</th></tr>
          </thead>
          <tbody>
            {classStudents.map((s) => {
              const status = get(s.id);
              return (
                <tr key={s.id} className="border-t border-border">
                  <td className="px-4 py-2 font-mono text-xs">{s.admissionNo}</td>
                  <td className="px-4 py-2">{s.name}</td>
                  <td className="px-4 py-2">
                    <div className="flex gap-1 justify-center">
                      {(["present", "absent", "late"] as const).map((opt) => (
                        <button
                          key={opt}
                          onClick={() => setDraft({ ...draft, [s.id]: opt })}
                          className={`px-3 py-1 rounded-md text-[11px] font-medium capitalize transition-colors ${
                            status === opt
                              ? opt === "present" ? "bg-success text-success-foreground"
                              : opt === "absent" ? "bg-destructive text-destructive-foreground"
                              : "bg-warning text-warning-foreground"
                              : "bg-muted text-muted-foreground hover:bg-muted/70"
                          }`}
                        >{opt}</button>
                      ))}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {classStudents.length === 0 && <div className="p-12 text-center text-muted-foreground text-sm">Pick a class to start the register</div>}
      </Card>
    </div>
  );
}
