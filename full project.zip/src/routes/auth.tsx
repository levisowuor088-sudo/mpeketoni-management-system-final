import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Loader2, School } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — Levis Developers School Suite" },
      { name: "description", content: "Secure email & password sign in for school staff, students, parents and donors." },
    ],
  }),
  component: AuthPage,
});

const DEMO_SCHOOL_ID = "11111111-1111-1111-1111-111111111111";

const emailSchema = z.string().trim().toLowerCase().email("Enter a valid email").max(255);
const passwordSchema = z.string().min(8, "At least 8 characters").max(128);
const signupSchema = z.object({
  fullName: z.string().trim().min(2, "Your name is required").max(100),
  email: emailSchema,
  password: passwordSchema,
  role: z.enum(["admin", "accountant", "teacher", "student", "parent"]),
});

function AuthPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<"signin" | "signup" | "forgot">("signin");
  const [busy, setBusy] = useState(false);

  // Sign-in form
  const [siEmail, setSiEmail] = useState("");
  const [siPassword, setSiPassword] = useState("");

  // Sign-up form
  const [suName, setSuName] = useState("");
  const [suEmail, setSuEmail] = useState("");
  const [suPassword, setSuPassword] = useState("");
  const [suRole, setSuRole] = useState<"admin" | "accountant" | "teacher" | "student" | "parent">("student");

  // Forgot
  const [fpEmail, setFpEmail] = useState("");

  // If already signed in, bounce to dashboard
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/dashboard" });
    });
  }, [navigate]);

  async function handleSignIn(e: React.FormEvent) {
    e.preventDefault();
    const parsed = z.object({ email: emailSchema, password: passwordSchema }).safeParse({ email: siEmail, password: siPassword });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: parsed.data.email, password: parsed.data.password });
    setBusy(false);
    if (error) {
      toast.error(error.message.includes("Invalid") ? "Wrong email or password" : error.message);
      return;
    }
    toast.success("Signed in");
    navigate({ to: "/dashboard" });
  }

  async function handleSignUp(e: React.FormEvent) {
    e.preventDefault();
    const parsed = signupSchema.safeParse({ fullName: suName, email: suEmail, password: suPassword, role: suRole });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setBusy(true);
    const redirectUrl = `${window.location.origin}/dashboard`;
    const { error } = await supabase.auth.signUp({
      email: parsed.data.email,
      password: parsed.data.password,
      options: {
        emailRedirectTo: redirectUrl,
        data: {
          full_name: parsed.data.fullName,
          role: parsed.data.role,
          school_id: DEMO_SCHOOL_ID,
        },
      },
    });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    if (parsed.data.role === "accountant" || parsed.data.role === "teacher") {
      toast.success("Account created — awaiting admin approval before full access.");
    } else {
      toast.success("Account created — you're signed in.");
    }
    navigate({ to: "/dashboard" });
  }

  async function handleForgot(e: React.FormEvent) {
    e.preventDefault();
    const parsed = emailSchema.safeParse(fpEmail);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.resetPasswordForEmail(parsed.data, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Password reset email sent (check your inbox).");
    setTab("signin");
  }

  return (
    <div className="min-h-screen grid place-items-center bg-background p-4">
      <Card className="w-full max-w-md p-6 sm:p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-10 w-10 rounded-xl bg-primary text-primary-foreground grid place-items-center">
            <School className="h-5 w-5" />
          </div>
          <div>
            <div className="font-display font-bold leading-tight">Levis Developers</div>
            <div className="text-xs text-muted-foreground">School Management Suite</div>
          </div>
        </div>

        <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="signin">Sign in</TabsTrigger>
            <TabsTrigger value="signup">Sign up</TabsTrigger>
            <TabsTrigger value="forgot">Forgot</TabsTrigger>
          </TabsList>

          <TabsContent value="signin">
            <form onSubmit={handleSignIn} className="space-y-3 mt-4">
              <div className="space-y-1">
                <Label htmlFor="si-email">Email</Label>
                <Input id="si-email" type="email" autoComplete="email" value={siEmail} onChange={(e) => setSiEmail(e.target.value)} required />
              </div>
              <div className="space-y-1">
                <Label htmlFor="si-pw">Password</Label>
                <Input id="si-pw" type="password" autoComplete="current-password" value={siPassword} onChange={(e) => setSiPassword(e.target.value)} required />
              </div>
              <Button type="submit" className="w-full" disabled={busy}>
                {busy && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Sign in
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="signup">
            <form onSubmit={handleSignUp} className="space-y-3 mt-4">
              <div className="space-y-1">
                <Label htmlFor="su-name">Full name</Label>
                <Input id="su-name" value={suName} onChange={(e) => setSuName(e.target.value)} required maxLength={100} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="su-email">Email</Label>
                <Input id="su-email" type="email" autoComplete="email" value={suEmail} onChange={(e) => setSuEmail(e.target.value)} required />
              </div>
              <div className="space-y-1">
                <Label htmlFor="su-pw">Password (8+ chars)</Label>
                <Input id="su-pw" type="password" autoComplete="new-password" value={suPassword} onChange={(e) => setSuPassword(e.target.value)} required minLength={8} />
              </div>
              <div className="space-y-1">
                <Label>Role</Label>
                <Select value={suRole} onValueChange={(v) => setSuRole(v as typeof suRole)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="accountant">Accountant (needs admin approval)</SelectItem>
                    <SelectItem value="teacher">Teacher (needs admin approval)</SelectItem>
                    <SelectItem value="student">Student</SelectItem>
                    <SelectItem value="parent">Parent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" className="w-full" disabled={busy}>
                {busy && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create account
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="forgot">
            <form onSubmit={handleForgot} className="space-y-3 mt-4">
              <p className="text-sm text-muted-foreground">Enter your email and we'll send a reset link.</p>
              <div className="space-y-1">
                <Label htmlFor="fp-email">Email</Label>
                <Input id="fp-email" type="email" value={fpEmail} onChange={(e) => setFpEmail(e.target.value)} required />
              </div>
              <Button type="submit" className="w-full" disabled={busy}>
                {busy && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Send reset link
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}
