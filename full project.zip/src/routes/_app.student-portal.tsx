import { createFileRoute, Link } from "@tanstack/react-router";
import { useStore, grade } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CalendarCheck, BookOpenCheck, FileText } from "lucide-react";

export const Route = createFileRoute("/_app/student-portal")({
  component: StudentPortal,
});

const TIMETABLE = [
  { day: "Mon", periods: ["Maths", "English", "Science", "Kiswahili", "Social"] },
  { day: "Tue", periods: ["English", "Maths", "Kiswahili", "Science", "PE"] },
  { day: "Wed", periods: ["Science", "Maths", "English", "Social", "Art"] },
  { day: "Thu", periods: ["Kiswahili", "Science", "Maths", "English", "Music"] },
  { day: "Fri", periods: ["Social", "Kiswahili", "Maths", "English", "Games"] },
];

function StudentPortal() {
  const user = useStore((s) => s.currentUser);
  const students = useStore((s) => s.students);
  const marks = useStore((s) => s.marks);
  const attendance = useStore((s) => s.attendance);

  const me = students.find((s) => s.id === user?.studentId) ?? students[0];
  if (!me) return null;

  const myMarks = marks.filter((m) => m.studentId === me.id);
  const recent = attendance.filter((a) => a.studentId === me.id).slice(0, 10);

  return (
    <div>
      <PageHeader title={`Hi ${me.name.split(" ")[0]} 👋`} description={`${me.grade} ${me.stream} · Adm ${me.admissionNo}`} />

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2">
          <h3 className="font-display font-semibold mb-3 flex items-center gap-2"><BookOpenCheck className="h-4 w-4" /> Latest scores</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {myMarks.map((m) => {
              const g = grade(m.score);
              return (
                <div key={m.id} className="rounded-lg border border-border p-3">
                  <div className="text-xs text-muted-foreground">{m.subject}</div>
                  <div className="flex items-end gap-2 mt-1">
                    <div className="text-2xl font-bold">{m.score}</div>
                    <Badge variant="outline" className="mb-1">{g.letter}</Badge>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-semibold mb-3 flex items-center gap-2"><CalendarCheck className="h-4 w-4" /> Attendance</h3>
          <div className="flex flex-wrap gap-1.5">
            {recent.map((a) => (
              <div key={a.id} className={`h-7 w-7 rounded-md text-[10px] grid place-items-center font-semibold ${
                a.status === "present" ? "bg-success/15 text-success"
                : a.status === "absent" ? "bg-destructive/15 text-destructive"
                : "bg-warning/15 text-warning"
              }`}>{a.date.slice(-2)}</div>
            ))}
          </div>
          <Button asChild variant="outline" className="w-full mt-4"><Link to="/reports"><FileText className="h-4 w-4 mr-1" /> Download report</Link></Button>
        </Card>

        <Card className="p-5 lg:col-span-3 overflow-hidden">
          <h3 className="font-display font-semibold mb-3">Timetable</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[600px]">
              <thead className="bg-muted/30 text-xs uppercase text-muted-foreground">
                <tr><th className="px-3 py-2 text-left">Day</th>{["8:00", "9:00", "10:30", "11:30", "1:30"].map((t) => <th key={t} className="px-3 py-2">{t}</th>)}</tr>
              </thead>
              <tbody>
                {TIMETABLE.map((row) => (
                  <tr key={row.day} className="border-t border-border">
                    <td className="px-3 py-2 font-semibold">{row.day}</td>
                    {row.periods.map((p, i) => <td key={i} className="px-3 py-2 text-center"><Badge variant="secondary" className="font-normal">{p}</Badge></td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}
