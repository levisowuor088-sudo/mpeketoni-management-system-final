import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { actions, useStore, type Student, kes } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/students")({
  component: StudentsPage,
});

function StudentsPage() {
  const students = useStore((s) => s.students);
  const classes = useStore((s) => s.classes);
  const [q, setQ] = useState("");
  const [gradeFilter, setGradeFilter] = useState<string>("all");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Omit<Student, "id" | "admissionNo" | "feeBalance">>({
    name: "",
    gender: "M",
    grade: "Grade 4",
    stream: "Blue",
    dob: "2015-01-01",
    parentName: "",
    parentPhone: "",
    parentEmail: "",
  });

  const grades = Array.from(new Set(classes.map((c) => c.grade)));
  const filtered = students.filter((s) => {
    if (gradeFilter !== "all" && s.grade !== gradeFilter) return false;
    if (q && !`${s.name} ${s.admissionNo}`.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });

  const submit = () => {
    if (!form.name || !form.parentPhone) {
      toast.error("Name and parent phone are required");
      return;
    }
    actions.addStudent(form);
    toast.success(`${form.name} admitted`);
    setOpen(false);
    setForm({ ...form, name: "", parentName: "", parentPhone: "", parentEmail: "" });
  };

  return (
    <div>
      <PageHeader
        title="Students"
        description={`${students.length} learners enrolled across ${grades.length} grade levels`}
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="h-4 w-4 mr-1" /> New Admission</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Admit new student</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><Label>Full name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div><Label>Gender</Label>
                  <Select value={form.gender} onValueChange={(v) => setForm({ ...form, gender: v as "M" | "F" })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="M">Male</SelectItem><SelectItem value="F">Female</SelectItem></SelectContent>
                  </Select>
                </div>
                <div><Label>Date of birth</Label><Input type="date" value={form.dob} onChange={(e) => setForm({ ...form, dob: e.target.value })} /></div>
                <div><Label>Grade</Label>
                  <Select value={form.grade} onValueChange={(v) => setForm({ ...form, grade: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{grades.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Stream</Label>
                  <Select value={form.stream} onValueChange={(v) => setForm({ ...form, stream: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{["Blue", "Green", "Gold"].map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="col-span-2"><Label>Parent / Guardian</Label><Input value={form.parentName} onChange={(e) => setForm({ ...form, parentName: e.target.value })} /></div>
                <div><Label>Parent phone</Label><Input value={form.parentPhone} onChange={(e) => setForm({ ...form, parentPhone: e.target.value })} /></div>
                <div><Label>Parent email</Label><Input value={form.parentEmail} onChange={(e) => setForm({ ...form, parentEmail: e.target.value })} /></div>
              </div>
              <DialogFooter><Button onClick={submit}>Admit Student</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <Card className="p-4 mb-4 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Search by name or admission number" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <Select value={gradeFilter} onValueChange={setGradeFilter}>
          <SelectTrigger className="w-full sm:w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All grades</SelectItem>
            {grades.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}
          </SelectContent>
        </Select>
      </Card>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3 text-left">Adm No</th>
                <th className="px-4 py-3 text-left">Name</th>
                <th className="px-4 py-3 text-left">Class</th>
                <th className="px-4 py-3 text-left">Guardian</th>
                <th className="px-4 py-3 text-right">Fee balance</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((s) => (
                <tr key={s.id} className="border-t border-border hover:bg-muted/30">
                  <td className="px-4 py-3 font-mono text-xs">{s.admissionNo}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-primary/10 text-primary grid place-items-center text-xs font-semibold">{s.name.split(" ").map((n) => n[0]).slice(0, 2).join("")}</div>
                      <div>
                        <div className="font-medium">{s.name}</div>
                        <div className="text-[11px] text-muted-foreground">{s.gender === "M" ? "Male" : "Female"} · {s.dob}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">{s.grade} <span className="text-muted-foreground">{s.stream}</span></td>
                  <td className="px-4 py-3"><div>{s.parentName}</div><div className="text-[11px] text-muted-foreground">{s.parentPhone}</div></td>
                  <td className="px-4 py-3 text-right">
                    {s.feeBalance > 0
                      ? <Badge variant="destructive">{kes(s.feeBalance)}</Badge>
                      : <Badge variant="secondary" className="bg-success/15 text-success border-0">Cleared</Badge>}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Button variant="ghost" size="icon" onClick={() => { actions.deleteStudent(s.id); toast.success("Student removed"); }}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && <div className="p-12 text-center text-muted-foreground text-sm">No students match your filters</div>}
      </Card>
    </div>
  );
}
