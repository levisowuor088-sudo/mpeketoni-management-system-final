import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { actions, useStore } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Trash2, BookOpenCheck } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/subjects")({ component: SubjectsPage });

function SubjectsPage() {
  const subjects = useStore((s) => s.subjects);
  const teachers = useStore((s) => s.teachers);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ code: "", name: "", grades: "Grade 4, Grade 5, Grade 6, Grade 7, Grade 8", teacherIds: [] as string[] });

  const submit = () => {
    if (!form.code || !form.name) { toast.error("Code and name required"); return; }
    actions.addSubject({
      code: form.code.toUpperCase(),
      name: form.name,
      grades: form.grades.split(",").map((g) => g.trim()).filter(Boolean),
      teacherIds: form.teacherIds,
    });
    actions.logAudit("subject.create", `${form.code} — ${form.name}`);
    toast.success("Subject added");
    setOpen(false);
    setForm({ code: "", name: "", grades: form.grades, teacherIds: [] });
  };

  return (
    <div>
      <PageHeader
        title="Subjects"
        description={`${subjects.length} subjects offered across grades`}
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> New subject</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Create subject</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Code</Label><Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="MAT" /></div>
                <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Mathematics" /></div>
                <div className="col-span-2"><Label>Offered to grades (comma separated)</Label><Input value={form.grades} onChange={(e) => setForm({ ...form, grades: e.target.value })} /></div>
                <div className="col-span-2">
                  <Label>Assign teachers</Label>
                  <div className="grid grid-cols-2 gap-1 max-h-40 overflow-auto mt-1">
                    {teachers.map((t) => (
                      <label key={t.id} className="flex items-center gap-2 text-sm rounded border border-border px-2 py-1 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={form.teacherIds.includes(t.id)}
                          onChange={(e) => setForm({ ...form, teacherIds: e.target.checked ? [...form.teacherIds, t.id] : form.teacherIds.filter((x) => x !== t.id) })}
                        />
                        {t.name}
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              <DialogFooter><Button onClick={submit}>Save subject</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {subjects.map((s) => (
          <Card key={s.id} className="p-5">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 text-primary grid place-items-center"><BookOpenCheck className="h-5 w-5" /></div>
                <div>
                  <div className="font-display font-semibold">{s.name}</div>
                  <div className="text-xs text-muted-foreground font-mono">{s.code}</div>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={() => { actions.deleteSubject(s.id); toast.success("Removed"); }}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
            <div className="mt-3">
              <div className="text-[10px] uppercase text-muted-foreground mb-1">Grades</div>
              <div className="flex flex-wrap gap-1">{s.grades.map((g) => <Badge key={g} variant="secondary" className="text-[10px]">{g}</Badge>)}</div>
            </div>
            <div className="mt-3">
              <div className="text-[10px] uppercase text-muted-foreground mb-1">Teachers</div>
              <div className="text-xs">
                {s.teacherIds.length === 0 ? <span className="text-muted-foreground italic">Unassigned</span> : s.teacherIds.map((tid) => teachers.find((t) => t.id === tid)?.name).filter(Boolean).join(", ")}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
