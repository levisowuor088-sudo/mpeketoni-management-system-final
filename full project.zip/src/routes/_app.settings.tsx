import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { actions, useStore } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useTheme } from "@/components/theme";
import { toast } from "sonner";
import { Upload, Trash2 } from "lucide-react";

export const Route = createFileRoute("/_app/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const school = useStore((s) => s.school);
  const { theme, toggle } = useTheme();
  const [form, setForm] = useState(school);
  const fileRef = useRef<HTMLInputElement>(null);

  const onFile = (file: File | null) => {
    if (!file) return;
    if (file.size > 1.5 * 1024 * 1024) {
      toast.error("Logo must be smaller than 1.5MB");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setForm((f) => ({ ...f, logo: dataUrl }));
    };
    reader.readAsDataURL(file);
  };

  const save = () => {
    actions.updateSchool(form);
    toast.success("School profile updated");
  };

  const field = (k: keyof typeof form, label: string, type = "text") => (
    <div>
      <Label className="text-xs">{label}</Label>
      <Input type={type} value={(form[k] as string) ?? ""} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
    </div>
  );

  return (
    <div>
      <PageHeader title="School Settings" description="Manage your school identity, branding and preferences" />

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2">
          <h3 className="font-display font-semibold mb-4">School profile</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            {field("name", "School name")}
            {field("motto", "Motto / tagline")}
            {field("address", "Physical address")}
            {field("poBox", "Postal address")}
            {field("phone", "Telephone", "tel")}
            {field("email", "Email", "email")}
            {field("website", "Website")}
            {field("kraPin", "KRA PIN")}
          </div>
          <div className="mt-4 pt-4 border-t border-border">
            <h4 className="text-sm font-semibold mb-2">Payment details (printed on invoices & receipts)</h4>
            <div className="grid sm:grid-cols-3 gap-3">
              {field("paybill", "M-Pesa Paybill")}
              {field("bankName", "Bank name")}
              {field("bankAccount", "Bank account")}
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <Button onClick={save}>Save changes</Button>
            <Button variant="outline" onClick={() => setForm(school)}>Reset</Button>
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-semibold mb-4">School logo</h3>
          <div className="flex flex-col items-center gap-3">
            {form.logo ? (
              <img src={form.logo} alt="Logo preview" className="h-32 w-32 rounded-2xl object-cover border-2 border-border shadow-[var(--shadow-soft)]" />
            ) : (
              <div className="h-32 w-32 rounded-2xl bg-primary/10 text-primary border-2 border-dashed border-primary/30 grid place-items-center font-display font-bold text-4xl">
                {(form.name || "S").charAt(0).toUpperCase()}
              </div>
            )}
            <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/svg+xml" className="hidden" onChange={(e) => onFile(e.target.files?.[0] ?? null)} />
            <div className="flex gap-2 w-full">
              <Button variant="outline" className="flex-1" onClick={() => fileRef.current?.click()}>
                <Upload className="h-4 w-4 mr-1" /> Upload
              </Button>
              {form.logo && (
                <Button variant="ghost" size="icon" onClick={() => setForm({ ...form, logo: undefined })} aria-label="Remove logo">
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
            <p className="text-[11px] text-muted-foreground text-center">PNG, JPG or SVG · up to 1.5MB. Appears on the dashboard, receipts, invoices and report cards.</p>
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-semibold mb-4">Appearance</h3>
          <div className="flex items-center justify-between py-2">
            <div>
              <div className="font-medium">Dark mode</div>
              <div className="text-xs text-muted-foreground">Easier on the eyes after sunset</div>
            </div>
            <Switch checked={theme === "dark"} onCheckedChange={toggle} />
          </div>
        </Card>

        <Card className="p-5 lg:col-span-2">
          <h3 className="font-display font-semibold mb-2">Backup & data</h3>
          <p className="text-sm text-muted-foreground mb-4">This prototype stores data in your browser. In production this would back up to encrypted cloud storage daily.</p>
          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" onClick={() => toast.success("Backup snapshot created (mocked)")}>Create backup</Button>
            <Button variant="outline" onClick={() => { localStorage.removeItem("sms_state_v1"); location.reload(); }}>Reset demo data</Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
