import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { actions, useStore, kes } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Printer, Smartphone } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/payments")({
  component: PaymentsPage,
});

function PaymentsPage() {
  const payments = useStore((s) => s.payments);
  const students = useStore((s) => s.students);
  const school = useStore((s) => s.school);
  const [open, setOpen] = useState(false);
  const [selectedReceipt, setSelectedReceipt] = useState<string | null>(null);
  const [form, setForm] = useState({ studentId: students[0]?.id ?? "", amount: 5000, method: "M-Pesa" as "M-Pesa" | "Bank" | "Cash", txnCode: "" });

  const submit = () => {
    if (!form.studentId || form.amount <= 0) { toast.error("Pick a student and enter amount"); return; }
    actions.recordPayment({
      studentId: form.studentId,
      amount: form.amount,
      method: form.method,
      txnCode: form.txnCode || `${form.method.replace(/[^A-Z]/g, "")}${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
    });
    toast.success("Payment recorded — receipt generated · SMS sent to parent (mocked)");
    setOpen(false);
  };

  const mpesa = () => {
    toast.info("STK push sent to parent's phone (mocked). Awaiting confirmation...");
    setTimeout(() => {
      actions.recordPayment({
        studentId: form.studentId,
        amount: form.amount,
        method: "M-Pesa",
        txnCode: `STK${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
      });
      toast.success("M-Pesa payment confirmed automatically");
      setOpen(false);
    }, 1200);
  };

  const receipt = selectedReceipt ? payments.find((p) => p.id === selectedReceipt) : null;
  const receiptStudent = receipt ? students.find((s) => s.id === receipt.studentId) : null;

  return (
    <div>
      <PageHeader
        title="Payments & Receipts"
        description={`${payments.length} transactions recorded`}
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> Record Payment</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Record fee payment</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Student</Label>
                  <Select value={form.studentId} onValueChange={(v) => setForm({ ...form, studentId: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{students.map((s) => <SelectItem key={s.id} value={s.id}>{s.admissionNo} — {s.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Amount (KES)</Label><Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: +e.target.value })} /></div>
                  <div><Label>Method</Label>
                    <Select value={form.method} onValueChange={(v) => setForm({ ...form, method: v as "M-Pesa" | "Bank" | "Cash" })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{["M-Pesa", "Bank", "Cash"].map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                </div>
                <div><Label>Transaction code (optional)</Label><Input value={form.txnCode} onChange={(e) => setForm({ ...form, txnCode: e.target.value })} /></div>
              </div>
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={mpesa}><Smartphone className="h-4 w-4 mr-1" /> Send STK Push</Button>
                <Button onClick={submit}>Save Receipt</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr><th className="px-4 py-3 text-left">Receipt</th><th className="px-4 py-3 text-left">Student</th><th className="px-4 py-3 text-left">Method</th><th className="px-4 py-3 text-left">Txn</th><th className="px-4 py-3 text-right">Amount</th><th className="px-4 py-3 text-left">Date</th><th></th></tr>
          </thead>
          <tbody>
            {payments.map((p) => {
              const st = students.find((s) => s.id === p.studentId);
              return (
                <tr key={p.id} className="border-t border-border hover:bg-muted/30">
                  <td className="px-4 py-2 font-mono text-xs">{p.receiptNo}</td>
                  <td className="px-4 py-2">{st?.name}</td>
                  <td className="px-4 py-2">{p.method}</td>
                  <td className="px-4 py-2 font-mono text-xs">{p.txnCode}</td>
                  <td className="px-4 py-2 text-right font-semibold">{kes(p.amount)}</td>
                  <td className="px-4 py-2">{p.date}</td>
                  <td className="px-4 py-2"><Button variant="ghost" size="sm" onClick={() => setSelectedReceipt(p.id)}>View</Button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>

      <Dialog open={!!receipt} onOpenChange={(o) => !o && setSelectedReceipt(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle className="no-print">Receipt</DialogTitle></DialogHeader>
          {receipt && receiptStudent && (
            <div className="print-area p-2">
              <div className="text-center border-b-2 border-primary pb-3 mb-3">
                {school.logo ? (
                  <img src={school.logo} alt="Logo" className="h-14 w-14 mx-auto mb-2 rounded-xl object-cover" />
                ) : (
                  <div className="h-12 w-12 rounded-xl bg-primary text-primary-foreground grid place-items-center font-bold mx-auto mb-2">{school.name.charAt(0)}</div>
                )}
                <div className="font-display font-bold">{school.name}</div>
                <div className="text-[10px] text-muted-foreground">{school.poBox} · Tel {school.phone}</div>
                <div className="text-[10px] text-muted-foreground">{school.email} · Paybill {school.paybill}</div>
                <div className="mt-2 font-semibold text-sm">OFFICIAL RECEIPT</div>
              </div>
              <div className="text-sm space-y-1.5">
                <div className="flex justify-between"><span className="text-muted-foreground">Receipt No</span><span className="font-mono">{receipt.receiptNo}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Date</span><span>{receipt.date}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Student</span><span>{receiptStudent.name}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Adm No</span><span className="font-mono">{receiptStudent.admissionNo}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Class</span><span>{receiptStudent.grade} {receiptStudent.stream}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Method</span><span>{receipt.method}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Txn Code</span><span className="font-mono">{receipt.txnCode}</span></div>
              </div>
              <div className="mt-4 py-3 border-y-2 border-border flex justify-between font-bold text-lg">
                <span>AMOUNT PAID</span><span>{kes(receipt.amount)}</span>
              </div>
              <div className="text-xs text-muted-foreground mt-2">Outstanding balance: <strong className="text-foreground">{kes(receiptStudent.feeBalance)}</strong></div>
              <div className="mt-4 text-[10px] text-center text-muted-foreground">Received by: {receipt.receivedBy} · Thank you for your payment</div>
            </div>
          )}
          <DialogFooter className="no-print">
            <Button onClick={() => window.print()}><Printer className="h-4 w-4 mr-1" /> Print</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
