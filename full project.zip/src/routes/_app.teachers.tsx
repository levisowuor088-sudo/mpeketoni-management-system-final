import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { actions, useStore, kes, type Teacher } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Mail, Phone, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/teachers")({
  component: TeachersPage,
});

function TeachersPage() {
  const teachers = useStore((s) => s.teachers);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Omit<Teacher, "id" | "staffNo">>({
    tscNo: "", name: "", email: "", phone: "", department: "", subjects: [], qualification: "", salary: 55000,
  });

  const submit = () => {
    if (!form.name || !form.email) { toast.error("Name and email required"); return; }
    actions.addTeacher({ ...form, subjects: form.subjects.length ? form.subjects : ["General"] });
    toast.success(`${form.name} added to staff`);
    setOpen(false);
  };

  return (
    <div>
      <PageHeader
        title="Teachers & Staff"
        description={`${teachers.length} staff members on payroll`}
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> Add Staff</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Register new staff</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><Label>Full name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div><Label>TSC number</Label><Input value={form.tscNo} onChange={(e) => setForm({ ...form, tscNo: e.target.value })} /></div>
                <div><Label>Department</Label><Input value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} /></div>
                <div><Label>Email</Label><Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                <div><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
                <div className="col-span-2"><Label>Subjects (comma-separated)</Label><Input onChange={(e) => setForm({ ...form, subjects: e.target.value.split(",").map((x) => x.trim()).filter(Boolean) })} /></div>
                <div><Label>Qualification</Label><Input value={form.qualification} onChange={(e) => setForm({ ...form, qualification: e.target.value })} /></div>
                <div><Label>Monthly salary</Label><Input type="number" value={form.salary} onChange={(e) => setForm({ ...form, salary: +e.target.value })} /></div>
              </div>
              <DialogFooter><Button onClick={submit}>Add Staff</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {teachers.map((t) => (
          <Card key={t.id} className="p-5">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground grid place-items-center font-semibold">{t.name.split(" ").map((n) => n[0]).slice(0, 2).join("")}</div>
                <div>
                  <div className="font-display font-semibold">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.department}</div>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={() => { actions.deleteTeacher(t.id); toast.success("Removed"); }}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
            <div className="mt-4 space-y-1.5 text-xs text-muted-foreground">
              <div className="flex items-center gap-2"><Mail className="h-3 w-3" /> {t.email}</div>
              <div className="flex items-center gap-2"><Phone className="h-3 w-3" /> {t.phone}</div>
            </div>
            <div className="mt-3 flex flex-wrap gap-1">
              {t.subjects.map((s) => <Badge key={s} variant="secondary" className="text-[10px]">{s}</Badge>)}
            </div>
            <div className="mt-4 pt-3 border-t border-border flex items-center justify-between">
              <div>
                <div className="text-[10px] text-muted-foreground uppercase">Staff No</div>
                <div className="font-mono text-xs">{t.staffNo}</div>
              </div>
              <div className="text-right">
                <div className="text-[10px] text-muted-foreground uppercase">Salary</div>
                <div className="font-semibold text-sm">{kes(t.salary)}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
