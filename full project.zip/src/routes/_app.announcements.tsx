import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { actions, useStore } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Mail, MessageSquare } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/announcements")({
  component: AnnouncementsPage,
});

function AnnouncementsPage() {
  const items = useStore((s) => s.announcements);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: "", body: "", audience: "all" as "all" | "parents" | "students" | "staff" });

  const send = () => {
    if (!form.title || !form.body) { toast.error("Title and message required"); return; }
    actions.addAnnouncement(form);
    toast.success("Announcement posted · SMS & email queued (mocked)");
    setOpen(false);
    setForm({ title: "", body: "", audience: "all" });
  };

  return (
    <div>
      <PageHeader
        title="Announcements"
        description="Broadcast to parents, students and staff via SMS and email"
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> New Announcement</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Compose announcement</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
                <div><Label>Audience</Label>
                  <Select value={form.audience} onValueChange={(v) => setForm({ ...form, audience: v as typeof form.audience })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{["all", "parents", "students", "staff"].map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Message</Label><Textarea rows={5} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} /></div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <Badge variant="outline" className="gap-1"><MessageSquare className="h-3 w-3" /> SMS</Badge>
                  <Badge variant="outline" className="gap-1"><Mail className="h-3 w-3" /> Email</Badge>
                </div>
              </div>
              <DialogFooter><Button onClick={send}>Send broadcast</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />
      <div className="grid lg:grid-cols-2 gap-4">
        {items.map((a) => (
          <Card key={a.id} className="p-5">
            <div className="flex items-start justify-between mb-2">
              <h3 className="font-display font-semibold">{a.title}</h3>
              <Badge variant="outline">{a.audience}</Badge>
            </div>
            <p className="text-sm text-muted-foreground">{a.body}</p>
            <div className="mt-3 text-xs text-muted-foreground">{a.date}</div>
          </Card>
        ))}
      </div>
    </div>
  );
}
