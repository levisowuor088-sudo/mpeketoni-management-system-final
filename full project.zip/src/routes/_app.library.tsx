import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { actions, useStore } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, BookOpen } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/library")({
  component: LibraryPage,
});

function LibraryPage() {
  const books = useStore((s) => s.books);
  const loans = useStore((s) => s.loans);
  const students = useStore((s) => s.students);
  const [open, setOpen] = useState(false);
  const [borrow, setBorrow] = useState<string | null>(null);
  const [borrower, setBorrower] = useState(students[0]?.id ?? "");
  const [form, setForm] = useState({ title: "", author: "", isbn: "", copies: 5 });
  const activeLoans = loans.filter((l) => !l.returnedOn);

  return (
    <div>
      <PageHeader
        title="Library"
        description={`${books.length} titles · ${activeLoans.length} active loans`}
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> Add Book</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Add book</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
                <div><Label>Author</Label><Input value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>ISBN</Label><Input value={form.isbn} onChange={(e) => setForm({ ...form, isbn: e.target.value })} /></div>
                  <div><Label>Copies</Label><Input type="number" value={form.copies} onChange={(e) => setForm({ ...form, copies: +e.target.value })} /></div>
                </div>
              </div>
              <DialogFooter><Button onClick={() => { actions.addBook(form); toast.success("Book added"); setOpen(false); }}>Add</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="overflow-hidden">
          <div className="px-4 py-3 border-b border-border font-display font-semibold flex items-center gap-2"><BookOpen className="h-4 w-4" /> Catalog</div>
          <table className="w-full text-sm">
            <thead className="bg-muted/30 text-xs uppercase text-muted-foreground">
              <tr><th className="px-4 py-2 text-left">Title</th><th className="px-4 py-2 text-left">Author</th><th className="px-4 py-2 text-center">Available</th><th></th></tr>
            </thead>
            <tbody>
              {books.map((b) => (
                <tr key={b.id} className="border-t border-border">
                  <td className="px-4 py-2"><div className="font-medium">{b.title}</div><div className="text-[10px] font-mono text-muted-foreground">{b.isbn}</div></td>
                  <td className="px-4 py-2 text-muted-foreground">{b.author}</td>
                  <td className="px-4 py-2 text-center"><Badge variant={b.available > 0 ? "secondary" : "destructive"}>{b.available} / {b.copies}</Badge></td>
                  <td className="px-4 py-2"><Button size="sm" variant="outline" disabled={b.available <= 0} onClick={() => setBorrow(b.id)}>Lend</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <Card className="overflow-hidden">
          <div className="px-4 py-3 border-b border-border font-display font-semibold">Active loans</div>
          <table className="w-full text-sm">
            <thead className="bg-muted/30 text-xs uppercase text-muted-foreground">
              <tr><th className="px-4 py-2 text-left">Book</th><th className="px-4 py-2 text-left">Borrower</th><th className="px-4 py-2 text-left">Due</th><th></th></tr>
            </thead>
            <tbody>
              {activeLoans.map((l) => {
                const b = books.find((x) => x.id === l.bookId);
                const s = students.find((x) => x.id === l.studentId);
                const overdue = new Date(l.dueOn) < new Date();
                return (
                  <tr key={l.id} className="border-t border-border">
                    <td className="px-4 py-2">{b?.title}</td>
                    <td className="px-4 py-2">{s?.name}</td>
                    <td className="px-4 py-2"><Badge variant={overdue ? "destructive" : "outline"}>{l.dueOn}</Badge></td>
                    <td className="px-4 py-2"><Button size="sm" variant="ghost" onClick={() => { actions.returnBook(l.id); toast.success("Book returned"); }}>Return</Button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {activeLoans.length === 0 && <div className="p-8 text-center text-muted-foreground text-sm">No active loans</div>}
        </Card>
      </div>

      <Dialog open={!!borrow} onOpenChange={(o) => !o && setBorrow(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Lend book</DialogTitle></DialogHeader>
          <div><Label>Borrower</Label>
            <Select value={borrower} onValueChange={setBorrower}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{students.map((s) => <SelectItem key={s.id} value={s.id}>{s.name} ({s.admissionNo})</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <DialogFooter><Button onClick={() => { if (borrow) actions.borrowBook(borrow, borrower); toast.success("Book lent · due in 14 days"); setBorrow(null); }}>Confirm</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
