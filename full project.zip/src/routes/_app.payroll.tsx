import { createFileRoute } from "@tanstack/react-router";
import { useStore, kes } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/payroll")({
  component: PayrollPage,
});

function PayrollPage() {
  const payroll = useStore((s) => s.payroll);
  const teachers = useStore((s) => s.teachers);
  const gross = payroll.reduce((a, p) => a + p.gross, 0);
  const net = payroll.reduce((a, p) => a + p.net, 0);
  const tax = payroll.reduce((a, p) => a + p.paye, 0);

  return (
    <div>
      <PageHeader title="Payroll" description="Monthly staff salaries with PAYE, NSSF and SHIF" />
      <div className="grid sm:grid-cols-3 gap-3 mb-6">
        <Card className="p-4"><div className="text-xs text-muted-foreground">Total gross</div><div className="text-2xl font-bold">{kes(gross)}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Net payable</div><div className="text-2xl font-bold text-success">{kes(net)}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">PAYE remitted</div><div className="text-2xl font-bold">{kes(tax)}</div></Card>
      </div>
      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr><th className="px-4 py-3 text-left">Staff</th><th className="px-4 py-3 text-right">Gross</th><th className="px-4 py-3 text-right">PAYE</th><th className="px-4 py-3 text-right">NSSF</th><th className="px-4 py-3 text-right">SHIF</th><th className="px-4 py-3 text-right">Net</th><th></th></tr>
          </thead>
          <tbody>
            {payroll.map((p) => {
              const t = teachers.find((x) => x.id === p.teacherId);
              return (
                <tr key={p.id} className="border-t border-border">
                  <td className="px-4 py-2"><div className="font-medium">{t?.name}</div><div className="text-[11px] text-muted-foreground">{t?.staffNo}</div></td>
                  <td className="px-4 py-2 text-right">{kes(p.gross)}</td>
                  <td className="px-4 py-2 text-right text-muted-foreground">{kes(p.paye)}</td>
                  <td className="px-4 py-2 text-right text-muted-foreground">{kes(p.nssf)}</td>
                  <td className="px-4 py-2 text-right text-muted-foreground">{kes(p.shif)}</td>
                  <td className="px-4 py-2 text-right font-semibold">{kes(p.net)}</td>
                  <td className="px-4 py-2"><Button size="sm" variant="ghost" onClick={() => toast.success(`Payslip emailed to ${t?.email}`)}><Download className="h-3 w-3 mr-1" /> Payslip</Button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
