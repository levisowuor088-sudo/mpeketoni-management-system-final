import { createFileRoute } from "@tanstack/react-router";
import { useState, useRef } from "react";
import * as XLSX from "xlsx";
import { actions, useStore } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Upload, FileSpreadsheet, Download, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/_app/import")({
  component: ImportPage,
});

type Kind = "students" | "teachers" | "marks" | "payments";

const TEMPLATES: Record<Kind, { headers: string[]; sample: any[] }> = {
  students: {
    headers: ["admissionNo", "name", "gender", "grade", "stream", "dob", "parentName", "parentPhone", "parentEmail", "feeBalance"],
    sample: [
      { admissionNo: "ADM2024100", name: "Jane Doe", gender: "F", grade: "Grade 5", stream: "Blue", dob: "2014-03-12", parentName: "Mary Doe", parentPhone: "+254700111222", parentEmail: "mary@example.com", feeBalance: 0 },
    ],
  },
  teachers: {
    headers: ["staffNo", "tscNo", "name", "email", "phone", "department", "subjects", "qualification", "salary"],
    sample: [
      { staffNo: "ST200", tscNo: "TSC500999", name: "Peter Mwangi", email: "peter@school.ac.ke", phone: "+254712345678", department: "Sciences", subjects: "Science,Mathematics", qualification: "B.Ed", salary: 60000 },
    ],
  },
  marks: {
    headers: ["admissionNo", "subject", "score"],
    sample: [
      { admissionNo: "ADM2024001", subject: "Mathematics", score: 78 },
      { admissionNo: "ADM2024001", subject: "English", score: 82 },
    ],
  },
  payments: {
    headers: ["admissionNo", "amount", "method", "txnCode"],
    sample: [
      { admissionNo: "ADM2024001", amount: 5000, method: "M-Pesa", txnCode: "QFK12AB34" },
    ],
  },
};

function ImportPage() {
  const exams = useStore((s) => s.exams);
  const [kind, setKind] = useState<Kind>("students");
  const [examId, setExamId] = useState(exams[0]?.id ?? "");
  const [rows, setRows] = useState<any[]>([]);
  const [fileName, setFileName] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = new Uint8Array(ev.target!.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json(sheet, { defval: "" });
        setRows(json);
        toast.success(`Loaded ${json.length} rows from ${file.name}`);
      } catch (err) {
        toast.error("Could not parse file. Make sure it's a valid .xlsx or .csv");
      }
    };
    reader.readAsArrayBuffer(file);
  }

  function downloadTemplate() {
    const tpl = TEMPLATES[kind];
    const ws = XLSX.utils.json_to_sheet(tpl.sample, { header: tpl.headers });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, kind);
    XLSX.writeFile(wb, `template-${kind}.xlsx`);
  }

  function commit() {
    if (!rows.length) { toast.error("Upload a file first"); return; }
    let n = 0;
    if (kind === "students") n = actions.bulkImportStudents(rows);
    else if (kind === "teachers") n = actions.bulkImportTeachers(rows);
    else if (kind === "marks") {
      if (!examId) { toast.error("Choose an exam first"); return; }
      n = actions.bulkImportMarks(examId, rows as any);
    }
    else if (kind === "payments") n = actions.bulkImportPayments(rows as any);
    toast.success(`Imported ${n} ${kind} record${n === 1 ? "" : "s"}`);
    setRows([]); setFileName("");
    if (inputRef.current) inputRef.current.value = "";
  }

  const headers = rows.length ? Object.keys(rows[0]) : TEMPLATES[kind].headers;
  const preview = rows.slice(0, 10);

  return (
    <div>
      <PageHeader
        title="Import from Excel"
        description="Bulk-load students, teachers, marks or payments from .xlsx / .csv spreadsheets"
      />

      <Tabs value={kind} onValueChange={(v) => { setKind(v as Kind); setRows([]); setFileName(""); }}>
        <TabsList className="mb-4">
          <TabsTrigger value="students">Students</TabsTrigger>
          <TabsTrigger value="teachers">Teachers</TabsTrigger>
          <TabsTrigger value="marks">Exam Marks</TabsTrigger>
          <TabsTrigger value="payments">Fee Payments</TabsTrigger>
        </TabsList>

        <TabsContent value={kind} className="space-y-4">
          <Card className="p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div>
                <div className="font-display font-semibold flex items-center gap-2"><FileSpreadsheet className="h-4 w-4 text-primary" /> {kind.charAt(0).toUpperCase() + kind.slice(1)} import</div>
                <div className="text-xs text-muted-foreground mt-1">Required columns: <span className="font-mono">{TEMPLATES[kind].headers.join(", ")}</span></div>
              </div>
              <Button variant="outline" onClick={downloadTemplate}><Download className="h-4 w-4 mr-1" /> Download template</Button>
            </div>

            {kind === "marks" && (
              <div className="mb-4 max-w-sm">
                <label className="text-xs uppercase text-muted-foreground">Target exam</label>
                <Select value={examId} onValueChange={setExamId}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{exams.map((e) => <SelectItem key={e.id} value={e.id}>{e.name} — {e.term} {e.year}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}

            <label className="block border-2 border-dashed border-border rounded-xl p-8 text-center cursor-pointer hover:bg-muted/30 transition-colors">
              <input ref={inputRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={onFile} />
              <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
              <div className="font-medium">{fileName || "Click to choose a spreadsheet"}</div>
              <div className="text-xs text-muted-foreground mt-1">.xlsx, .xls or .csv · up to 10,000 rows</div>
            </label>
          </Card>

          {rows.length > 0 && (
            <Card className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-success" />
                  <span className="font-semibold">{rows.length} rows ready</span>
                  <Badge variant="secondary">Preview first 10</Badge>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => { setRows([]); setFileName(""); if (inputRef.current) inputRef.current.value = ""; }}>Discard</Button>
                  <Button onClick={commit}>Import {rows.length} records</Button>
                </div>
              </div>
              <div className="overflow-x-auto border border-border rounded-lg">
                <table className="w-full text-xs">
                  <thead className="bg-muted/40 uppercase">
                    <tr>{headers.map((h) => <th key={h} className="px-2 py-1.5 text-left whitespace-nowrap">{h}</th>)}</tr>
                  </thead>
                  <tbody>
                    {preview.map((r, i) => (
                      <tr key={i} className="border-t border-border">
                        {headers.map((h) => <td key={h} className="px-2 py-1.5 whitespace-nowrap">{String(r[h] ?? "")}</td>)}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
