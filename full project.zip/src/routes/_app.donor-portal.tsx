import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { actions, useStore, kes, type Sponsorship } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Search, Heart, Download } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/donor-portal")({ component: DonorPortal });

const CATS: Sponsorship["category"][] = ["Full Fees", "Tuition", "Boarding", "Transport", "Meals", "Exams", "Other"];

function DonorPortal() {
  const user = useStore((s) => s.currentUser);
  const donors = useStore((s) => s.donors);
  const students = useStore((s) => s.students);
  const sponsorships = useStore((s) => s.sponsorships);
  const school = useStore((s) => s.school);

  const me = donors.find((d) => d.email === user?.email) ?? donors[0];
  const mySupport = useMemo(() => sponsorships.filter((s) => s.donorId === me?.id), [sponsorships, me]);
  const mySponsored = useMemo(() => Array.from(new Set(mySupport.map((s) => s.studentId))).map((id) => students.find((st) => st.id === id)!).filter(Boolean), [mySupport, students]);
  const totalGiven = mySupport.reduce((a, s) => a + s.amount, 0);

  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ studentId: "", category: "Tuition" as Sponsorship["category"], amount: 5000 });
  const [receipt, setReceipt] = useState<{ student: string; amount: number; ref: string } | null>(null);

  const searchResults = useMemo(() => {
    if (!q.trim()) return [];
    const ql = q.toLowerCase();
    return students.filter((s) => s.name.toLowerCase().includes(ql) || s.admissionNo.toLowerCase().includes(ql)).slice(0, 8);
  }, [q, students]);

  if (!me) return <div className="p-6">No donor record linked to this account.</div>;

  return (
    <div>
      <PageHeader title={`Welcome, ${me.name}`} description="Your sponsorship dashboard — supporting tomorrow's leaders" />

      <div className="grid sm:grid-cols-3 gap-4 mb-6">
        <Card className="p-4"><div className="text-xs text-muted-foreground">Total contributed</div><div className="text-2xl font-bold text-primary">{kes(totalGiven)}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Students sponsored</div><div className="text-2xl font-bold">{mySponsored.length}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Total transactions</div><div className="text-2xl font-bold">{mySupport.length}</div></Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-5">
          <h3 className="font-display font-semibold mb-3 flex items-center gap-2"><Heart className="h-4 w-4 text-primary" /> Your sponsored students</h3>
          <div className="space-y-2">
            {mySponsored.map((s) => (
              <div key={s.id} className="border border-border rounded-lg p-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold">{s.name}</div>
                    <div className="text-xs text-muted-foreground">{s.admissionNo} · {s.grade} {s.stream}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-muted-foreground uppercase">Balance</div>
                    <div className={`font-semibold ${s.feeBalance > 0 ? "text-destructive" : "text-primary"}`}>{kes(s.feeBalance)}</div>
                  </div>
                </div>
              </div>
            ))}
            {mySponsored.length === 0 && <div className="text-sm text-muted-foreground text-center py-6">You haven't sponsored any students yet.</div>}
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-semibold mb-3">Sponsor a new student</h3>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name or admission no..." className="pl-9" />
          </div>
          <div className="mt-2 space-y-1 max-h-64 overflow-y-auto">
            {searchResults.map((s) => (
              <div key={s.id} className="flex items-center justify-between border border-border rounded-md p-2 text-sm">
                <div>
                  <div className="font-medium">{s.name}</div>
                  <div className="text-xs text-muted-foreground">{s.admissionNo} · Balance {kes(s.feeBalance)}</div>
                </div>
                <Dialog open={open && form.studentId === s.id} onOpenChange={(o) => { setOpen(o); if (o) setForm({ ...form, studentId: s.id }); }}>
                  <DialogTrigger asChild><Button size="sm">Sponsor</Button></DialogTrigger>
                  <DialogContent>
                    <DialogHeader><DialogTitle>Sponsor {s.name}</DialogTitle></DialogHeader>
                    <div className="space-y-3">
                      <div><Label>Category</Label>
                        <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v as Sponsorship["category"] })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>{CATS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                        </Select>
                      </div>
                      <div><Label>Amount (KES)</Label><Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: +e.target.value })} /></div>
                      <div className="text-xs text-muted-foreground bg-muted/40 rounded-md p-2">
                        Payment will be processed via {school.bankName} A/C {school.bankAccount} or M-Pesa Paybill {school.paybill}.
                      </div>
                    </div>
                    <DialogFooter>
                      <Button onClick={() => {
                        if (form.amount <= 0) { toast.error("Enter valid amount"); return; }
                        actions.addSponsorship({ donorId: me.id, studentId: form.studentId, category: form.category, amount: form.amount });
                        const ref = `DON${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
                        toast.success("Payment received — thank you!");
                        setReceipt({ student: s.name, amount: form.amount, ref });
                        setOpen(false);
                      }}>Pay & sponsor</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            ))}
            {q && searchResults.length === 0 && <div className="text-xs text-muted-foreground py-3 text-center">No students found</div>}
          </div>
        </Card>
      </div>

      {receipt && (
        <Card className="mt-6 p-6 max-w-md mx-auto print-area">
          <div className="text-center border-b border-border pb-3 mb-3">
            <div className="font-display font-bold text-lg">{school.name}</div>
            <div className="text-xs text-muted-foreground">{school.address}</div>
            <div className="text-xs font-mono mt-2">DONATION RECEIPT</div>
          </div>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between"><span>Donor:</span><span className="font-semibold">{me.name}</span></div>
            <div className="flex justify-between"><span>Beneficiary:</span><span>{receipt.student}</span></div>
            <div className="flex justify-between"><span>Reference:</span><span className="font-mono">{receipt.ref}</span></div>
            <div className="flex justify-between border-t border-border pt-2 mt-2 text-lg"><span>Amount:</span><span className="font-bold text-primary">{kes(receipt.amount)}</span></div>
          </div>
          <Button variant="outline" className="w-full mt-4 no-print" onClick={() => window.print()}><Download className="h-4 w-4 mr-1" /> Download / Print receipt</Button>
        </Card>
      )}
    </div>
  );
}
