import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { actions, useStore, grade } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/exams")({
  component: ExamsPage,
});

const SUBJECTS = ["Mathematics", "English", "Kiswahili", "Science", "Social Studies"];

function ExamsPage() {
  const exams = useStore((s) => s.exams);
  const classes = useStore((s) => s.classes);
  const students = useStore((s) => s.students);
  const marks = useStore((s) => s.marks);
  const [examId, setExamId] = useState(exams[0]?.id ?? "");
  const [cls, setCls] = useState(classes[0]?.id ?? "");
  const [subject, setSubject] = useState(SUBJECTS[0]);
  const [draft, setDraft] = useState<Record<string, number>>({});

  const selected = classes.find((c) => c.id === cls);
  const classStudents = useMemo(
    () => students.filter((s) => selected && s.grade === selected.grade && s.stream === selected.stream),
    [students, selected],
  );

  const score = (studentId: string) => {
    if (draft[studentId] !== undefined) return draft[studentId];
    return marks.find((m) => m.examId === examId && m.studentId === studentId && m.subject === subject)?.score ?? 0;
  };

  const save = () => {
    const payload = classStudents.map((s) => ({ studentId: s.id, subject, score: score(s.id) }));
    actions.saveMarks(examId, payload);
    toast.success("Marks saved");
    setDraft({});
  };

  // Ranking table
  const ranking = useMemo(() => {
    return classStudents
      .map((s) => {
        const subjectScores = SUBJECTS.map((sub) => marks.find((m) => m.examId === examId && m.studentId === s.id && m.subject === sub)?.score ?? 0);
        const total = subjectScores.reduce((a, b) => a + b, 0);
        const mean = Math.round(total / SUBJECTS.length);
        return { student: s, total, mean, subjects: subjectScores };
      })
      .sort((a, b) => b.total - a.total);
  }, [classStudents, marks, examId]);

  return (
    <div>
      <PageHeader title="Exams & Marks" description="Enter scores and generate rankings" action={<Button onClick={save}>Save Marks</Button>} />

      <Card className="p-4 mb-4 grid sm:grid-cols-3 gap-3">
        <Select value={examId} onValueChange={setExamId}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>{exams.map((e) => <SelectItem key={e.id} value={e.id}>{e.name} — {e.term} {e.year}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={cls} onValueChange={setCls}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>{classes.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={subject} onValueChange={setSubject}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>{SUBJECTS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
        </Select>
      </Card>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="overflow-hidden">
          <div className="px-4 py-3 border-b border-border font-display font-semibold">Enter marks — {subject}</div>
          <table className="w-full text-sm">
            <thead className="bg-muted/30 text-xs uppercase text-muted-foreground">
              <tr><th className="px-4 py-2 text-left">Student</th><th className="px-4 py-2 text-right">Score / 100</th></tr>
            </thead>
            <tbody>
              {classStudents.map((s) => {
                const sc = score(s.id);
                const g = grade(sc);
                return (
                  <tr key={s.id} className="border-t border-border">
                    <td className="px-4 py-2">{s.name}</td>
                    <td className="px-4 py-2 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Input type="number" min={0} max={100} value={sc} onChange={(e) => setDraft({ ...draft, [s.id]: Math.max(0, Math.min(100, +e.target.value)) })} className="w-20 h-8 text-right" />
                        <Badge variant="outline" className="w-9 justify-center">{g.letter}</Badge>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>

        <Card className="overflow-hidden">
          <div className="px-4 py-3 border-b border-border font-display font-semibold">Class ranking</div>
          <table className="w-full text-sm">
            <thead className="bg-muted/30 text-xs uppercase text-muted-foreground">
              <tr><th className="px-4 py-2 text-left">#</th><th className="px-4 py-2 text-left">Student</th><th className="px-4 py-2 text-right">Total</th><th className="px-4 py-2 text-right">Mean</th></tr>
            </thead>
            <tbody>
              {ranking.map((r, i) => (
                <tr key={r.student.id} className="border-t border-border">
                  <td className="px-4 py-2 font-semibold">{i + 1}</td>
                  <td className="px-4 py-2">{r.student.name}</td>
                  <td className="px-4 py-2 text-right">{r.total}</td>
                  <td className="px-4 py-2 text-right"><Badge>{r.mean}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
    </div>
  );
}
