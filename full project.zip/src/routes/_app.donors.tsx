import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { actions, useStore, kes, type Donor, type Sponsorship } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Heart, Trash2, HandHeart } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/donors")({ component: DonorsPage });

const CATS: Sponsorship["category"][] = ["Full Fees", "Tuition", "Boarding", "Transport", "Meals", "Exams", "Other"];
const TYPES: Donor["type"][] = ["Individual", "NGO", "Church", "Alumni", "Company"];

function DonorsPage() {
  const donors = useStore((s) => s.donors);
  const sponsorships = useStore((s) => s.sponsorships);
  const students = useStore((s) => s.students);

  const [donorOpen, setDonorOpen] = useState(false);
  const [spOpen, setSpOpen] = useState(false);
  const [df, setDf] = useState<Omit<Donor, "id">>({ name: "", type: "Individual", phone: "", email: "" });
  const [sf, setSf] = useState({ donorId: donors[0]?.id ?? "", studentId: students[0]?.id ?? "", category: "Tuition" as Sponsorship["category"], amount: 5000, notes: "" });

  const totals = useMemo(() => ({
    raised: sponsorships.reduce((a, s) => a + s.amount, 0),
    students: new Set(sponsorships.map((s) => s.studentId)).size,
    donors: donors.length,
  }), [sponsorships, donors]);

  return (
    <div>
      <PageHeader
        title="Donors & Sponsorship"
        description={`${totals.donors} donors supporting ${totals.students} students`}
        action={
          <div className="flex gap-2">
            <Dialog open={spOpen} onOpenChange={setSpOpen}>
              <DialogTrigger asChild><Button variant="outline"><HandHeart className="h-4 w-4 mr-1" /> Record sponsorship</Button></DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Record sponsorship payment</DialogTitle></DialogHeader>
                <div className="space-y-3">
                  <div><Label>Donor</Label>
                    <Select value={sf.donorId} onValueChange={(v) => setSf({ ...sf, donorId: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{donors.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div><Label>Student</Label>
                    <Select value={sf.studentId} onValueChange={(v) => setSf({ ...sf, studentId: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{students.map((s) => <SelectItem key={s.id} value={s.id}>{s.admissionNo} — {s.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div><Label>Category</Label>
                      <Select value={sf.category} onValueChange={(v) => setSf({ ...sf, category: v as Sponsorship["category"] })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>{CATS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div><Label>Amount (KES)</Label><Input type="number" value={sf.amount} onChange={(e) => setSf({ ...sf, amount: +e.target.value })} /></div>
                  </div>
                  <div><Label>Notes</Label><Input value={sf.notes} onChange={(e) => setSf({ ...sf, notes: e.target.value })} /></div>
                </div>
                <DialogFooter><Button onClick={() => {
                  if (!sf.donorId || !sf.studentId || sf.amount <= 0) { toast.error("Fill all fields"); return; }
                  actions.addSponsorship(sf);
                  actions.logAudit("sponsorship.record", `${kes(sf.amount)} for student`);
                  toast.success("Sponsorship recorded · fee balance updated · receipt issued");
                  setSpOpen(false);
                }}>Save & issue receipt</Button></DialogFooter>
              </DialogContent>
            </Dialog>
            <Dialog open={donorOpen} onOpenChange={setDonorOpen}>
              <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> Add donor</Button></DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Register donor / sponsor</DialogTitle></DialogHeader>
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2"><Label>Name</Label><Input value={df.name} onChange={(e) => setDf({ ...df, name: e.target.value })} /></div>
                  <div><Label>Type</Label>
                    <Select value={df.type} onValueChange={(v) => setDf({ ...df, type: v as Donor["type"] })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div><Label>Organization</Label><Input value={df.organization ?? ""} onChange={(e) => setDf({ ...df, organization: e.target.value })} /></div>
                  <div><Label>Contact person</Label><Input value={df.contactPerson ?? ""} onChange={(e) => setDf({ ...df, contactPerson: e.target.value })} /></div>
                  <div><Label>Phone</Label><Input value={df.phone} onChange={(e) => setDf({ ...df, phone: e.target.value })} /></div>
                  <div className="col-span-2"><Label>Email</Label><Input value={df.email} onChange={(e) => setDf({ ...df, email: e.target.value })} /></div>
                  <div className="col-span-2"><Label>Address</Label><Input value={df.address ?? ""} onChange={(e) => setDf({ ...df, address: e.target.value })} /></div>
                </div>
                <DialogFooter><Button onClick={() => {
                  if (!df.name || !df.email) { toast.error("Name and email required"); return; }
                  actions.addDonor(df);
                  toast.success("Donor registered");
                  setDonorOpen(false);
                  setDf({ name: "", type: "Individual", phone: "", email: "" });
                }}>Save donor</Button></DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        }
      />

      <div className="grid sm:grid-cols-3 gap-4 mb-6">
        <Card className="p-4"><div className="text-xs text-muted-foreground">Total raised</div><div className="text-2xl font-bold text-primary">{kes(totals.raised)}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Active donors</div><div className="text-2xl font-bold">{totals.donors}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Sponsored students</div><div className="text-2xl font-bold">{totals.students}</div></Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-4">
          <h3 className="font-display font-semibold mb-3">Donors</h3>
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {donors.map((d) => {
              const supports = sponsorships.filter((s) => s.donorId === d.id);
              const total = supports.reduce((a, s) => a + s.amount, 0);
              return (
                <div key={d.id} className="border border-border rounded-lg p-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-semibold flex items-center gap-2">{d.name} <Badge variant="secondary" className="text-[10px]">{d.type}</Badge></div>
                      <div className="text-xs text-muted-foreground">{d.email} · {d.phone}</div>
                      {d.organization && <div className="text-xs text-muted-foreground">{d.organization}</div>}
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => { if (confirm(`Delete ${d.name}?`)) actions.deleteDonor(d.id); }}>
                      <Trash2 className="h-3 w-3 text-destructive" />
                    </Button>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Supports {supports.length} student{supports.length === 1 ? "" : "s"}</span>
                    <span className="font-semibold text-primary">{kes(total)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="p-4">
          <h3 className="font-display font-semibold mb-3">Recent sponsorships</h3>
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {sponsorships.map((sp) => {
              const d = donors.find((x) => x.id === sp.donorId);
              const st = students.find((x) => x.id === sp.studentId);
              return (
                <div key={sp.id} className="border border-border rounded-lg p-3 flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 text-primary grid place-items-center"><Heart className="h-5 w-5" /></div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{d?.name} → {st?.name}</div>
                    <div className="text-xs text-muted-foreground">{sp.category} · {sp.date}</div>
                  </div>
                  <div className="font-semibold text-primary">{kes(sp.amount)}</div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
}
