import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { actions, useStore, kes } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, AlertTriangle, CheckCircle2, Ban } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/charges")({ component: ChargesPage });

const CATEGORIES = [
  "Broken Laboratory Equipment", "Lost Library Book", "Damaged Desk", "Lost ID Card",
  "Hostel Damages", "Sports Equipment Damage", "Uniform Damage", "Late Fine", "Discipline Fine", "Other",
];

function ChargesPage() {
  const charges = useStore((s) => s.charges);
  const students = useStore((s) => s.students);
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState<"all" | "unpaid" | "paid" | "waived">("all");
  const [form, setForm] = useState({ studentId: students[0]?.id ?? "", category: CATEGORIES[0], description: "", amount: 500 });

  const filtered = useMemo(() => charges.filter((c) => {
    if (filter === "unpaid") return !c.paid && !c.waived;
    if (filter === "paid") return c.paid;
    if (filter === "waived") return c.waived;
    return true;
  }), [charges, filter]);

  const totals = useMemo(() => ({
    total: charges.reduce((a, c) => a + c.amount, 0),
    outstanding: charges.filter((c) => !c.paid && !c.waived).reduce((a, c) => a + c.amount, 0),
    paid: charges.filter((c) => c.paid).reduce((a, c) => a + c.amount, 0),
  }), [charges]);

  const submit = () => {
    if (!form.description || form.amount <= 0) { toast.error("Description and amount required"); return; }
    actions.addCharge(form);
    actions.logAudit("charge.create", `${form.category} · ${kes(form.amount)}`);
    toast.success("Charge posted to fee statement");
    setOpen(false);
    setForm({ ...form, description: "", amount: 500 });
  };

  return (
    <div>
      <PageHeader
        title="Student Charges"
        description="Damages, fines and disciplinary costs — auto-posted to fee statements"
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> New charge</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Post charge to student account</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Student</Label>
                  <Select value={form.studentId} onValueChange={(v) => setForm({ ...form, studentId: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{students.map((s) => <SelectItem key={s.id} value={s.id}>{s.admissionNo} — {s.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Category</Label>
                  <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Description</Label><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="What was damaged/lost?" /></div>
                <div><Label>Amount (KES)</Label><Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: +e.target.value })} /></div>
              </div>
              <DialogFooter><Button onClick={submit}>Post charge</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid sm:grid-cols-3 gap-4 mb-4">
        <Card className="p-4"><div className="text-xs text-muted-foreground">Total billed</div><div className="text-2xl font-bold">{kes(totals.total)}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Outstanding</div><div className="text-2xl font-bold text-destructive">{kes(totals.outstanding)}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Collected</div><div className="text-2xl font-bold text-primary">{kes(totals.paid)}</div></Card>
      </div>

      <Card className="p-4 mb-4 flex flex-wrap gap-2">
        {(["all", "unpaid", "paid", "waived"] as const).map((f) => (
          <Button key={f} variant={filter === f ? "default" : "outline"} size="sm" onClick={() => setFilter(f)}>{f}</Button>
        ))}
      </Card>

      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted">
            <tr>
              <th className="text-left px-3 py-2">Charge #</th>
              <th className="text-left px-3 py-2">Student</th>
              <th className="text-left px-3 py-2">Category</th>
              <th className="text-left px-3 py-2">Description</th>
              <th className="text-right px-3 py-2">Amount</th>
              <th className="text-left px-3 py-2">Status</th>
              <th className="text-right px-3 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((c) => {
              const st = students.find((s) => s.id === c.studentId);
              return (
                <tr key={c.id} className="border-b border-border">
                  <td className="px-3 py-2 font-mono text-xs">{c.chargeNo}</td>
                  <td className="px-3 py-2">{st?.name}<div className="text-[10px] text-muted-foreground">{st?.admissionNo} · {st?.grade}</div></td>
                  <td className="px-3 py-2">{c.category}</td>
                  <td className="px-3 py-2 text-xs">{c.description}</td>
                  <td className="px-3 py-2 text-right font-semibold">{kes(c.amount)}</td>
                  <td className="px-3 py-2">
                    {c.paid ? <Badge className="bg-primary/10 text-primary"><CheckCircle2 className="h-3 w-3 mr-1" />Paid</Badge>
                     : c.waived ? <Badge variant="secondary"><Ban className="h-3 w-3 mr-1" />Waived</Badge>
                     : <Badge variant="destructive"><AlertTriangle className="h-3 w-3 mr-1" />Unpaid</Badge>}
                  </td>
                  <td className="px-3 py-2 text-right">
                    {!c.paid && !c.waived && (
                      <Button size="sm" variant="outline" onClick={() => { actions.payCharge(c.id, "Cash"); toast.success("Marked paid"); }}>Mark paid</Button>
                    )}
                  </td>
                </tr>
              );
            })}
            {filtered.length === 0 && <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">No charges match this filter</td></tr>}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
