import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/useAuth";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Ban, ShieldCheck, BadgeDollarSign, Plus } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/fee-charging")({
  head: () => ({ meta: [{ title: "Fee Charging — Levis Developers" }] }),
  component: FeeChargingPage,
});

const KES = (n: number) => `KES ${Number(n).toLocaleString()}`;

interface StudentRow { id: string; admission_no: string; full_name: string; grade: string | null; school_id: string }
interface InvoiceRow { id: string; amount: number; balance: number; status: string; student_id: string; fee_items?: { name: string } | null }
interface FeeItemRow { id: string; name: string; amount: number }

function FeeChargingPage() {
  const navigate = useNavigate();
  const auth = useAuth();
  const qc = useQueryClient();
  const [selectedStudent, setSelectedStudent] = useState<StudentRow | null>(null);

  // Permission guard: this whole page (and waiver UI) is admin or accountant only.
  // Waive specifically is gated to admin further down.
  useEffect(() => {
    if (!auth.loading && auth.role && auth.role !== "admin" && auth.role !== "accountant") {
      toast.error("Fee charging is restricted to admins and accountants.");
      navigate({ to: "/dashboard" });
    }
  }, [auth.loading, auth.role, navigate]);

  const studentsQ = useQuery({
    queryKey: ["students-db"],
    queryFn: async () => {
      const { data, error } = await supabase.from("students").select("id, admission_no, full_name, grade, school_id").order("admission_no");
      if (error) throw error;
      return (data ?? []) as StudentRow[];
    },
  });

  const invoicesQ = useQuery({
    queryKey: ["invoices-db", selectedStudent?.id],
    enabled: !!selectedStudent,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("invoices")
        .select("id, amount, balance, status, student_id, fee_items(name)")
        .eq("student_id", selectedStudent!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as InvoiceRow[];
    },
  });

  if (auth.loading) {
    return <div className="grid place-items-center h-64"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div>
      <PageHeader title="Fee Charging Workflow" description="Post charges, record payments and (admins only) waive fees with audit trail." />

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-4 lg:col-span-1">
          <h3 className="font-semibold mb-3 text-sm">1. Select student</h3>
          {studentsQ.isLoading && <div className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading…</div>}
          {studentsQ.error && <p className="text-sm text-destructive">Failed to load students.</p>}
          {studentsQ.data?.length === 0 && (
            <div className="text-sm text-muted-foreground border border-dashed rounded-md p-4 text-center">
              No students yet. Add students from the Students module.
            </div>
          )}
          <div className="max-h-[500px] overflow-y-auto divide-y">
            {studentsQ.data?.map((s) => (
              <button
                key={s.id}
                onClick={() => setSelectedStudent(s)}
                className={`w-full text-left px-3 py-2 hover:bg-muted text-sm ${selectedStudent?.id === s.id ? "bg-primary/10" : ""}`}
              >
                <div className="font-medium">{s.full_name}</div>
                <div className="text-xs text-muted-foreground">{s.admission_no} · {s.grade ?? "—"}</div>
              </button>
            ))}
          </div>
        </Card>

        <Card className="p-4 lg:col-span-2">
          {!selectedStudent ? (
            <div className="text-sm text-muted-foreground text-center py-12">Pick a student to view their fee statement.</div>
          ) : (
            <FeeStatement student={selectedStudent} invoices={invoicesQ.data ?? []} loading={invoicesQ.isLoading} role={auth.role} onChange={() => qc.invalidateQueries({ queryKey: ["invoices-db", selectedStudent.id] })} />
          )}
        </Card>
      </div>
    </div>
  );
}

function FeeStatement({ student, invoices, loading, role, onChange }: { student: StudentRow; invoices: InvoiceRow[]; loading: boolean; role: string | null; onChange: () => void }) {
  const totalOutstanding = invoices.reduce((a, i) => a + Number(i.balance), 0);
  return (
    <div>
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="font-display text-lg font-bold">{student.full_name}</h3>
          <div className="text-xs text-muted-foreground">{student.admission_no} · {student.grade ?? "—"}</div>
        </div>
        <div className="flex items-center gap-2">
          <NewChargeDialog studentId={student.id} schoolId={student.school_id} onChange={onChange} />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="rounded-lg border p-3"><div className="text-xs text-muted-foreground">Charges</div><div className="font-bold">{invoices.length}</div></div>
        <div className="rounded-lg border p-3"><div className="text-xs text-muted-foreground">Outstanding</div><div className="font-bold text-destructive">{KES(totalOutstanding)}</div></div>
      </div>

      {loading ? (
        <div className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading statement…</div>
      ) : invoices.length === 0 ? (
        <div className="text-sm text-muted-foreground border border-dashed rounded-md p-6 text-center">No charges yet for this student.</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="text-left px-3 py-2">Item</th>
                <th className="text-right px-3 py-2">Amount</th>
                <th className="text-right px-3 py-2">Balance</th>
                <th className="text-left px-3 py-2">Status</th>
                <th className="text-right px-3 py-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((inv) => (
                <tr key={inv.id} className="border-b">
                  <td className="px-3 py-2">{inv.fee_items?.name ?? "Fee"}</td>
                  <td className="px-3 py-2 text-right">{KES(Number(inv.amount))}</td>
                  <td className="px-3 py-2 text-right font-semibold">{KES(Number(inv.balance))}</td>
                  <td className="px-3 py-2">
                    <Badge variant={inv.status === "paid" ? "default" : inv.status === "waived" ? "secondary" : "destructive"}>
                      {inv.status}
                    </Badge>
                  </td>
                  <td className="px-3 py-2 text-right">
                    <div className="flex gap-1 justify-end">
                      {Number(inv.balance) > 0 && (
                        <RecordPaymentDialog invoice={inv} schoolId={student.school_id} onChange={onChange} />
                      )}
                      {/* WAIVE FEE — ADMIN ONLY, only available inside the Fee Charging workflow */}
                      {Number(inv.balance) > 0 && role === "admin" && (
                        <WaiveFeeDialog invoice={inv} student={student} onChange={onChange} />
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ---------- New charge ---------- */
const chargeSchema = z.object({
  feeItemId: z.string().uuid("Pick a fee item"),
  amount: z.number().positive("Amount must be greater than 0"),
});

function NewChargeDialog({ studentId, schoolId, onChange }: { studentId: string; schoolId: string; onChange: () => void }) {
  const [open, setOpen] = useState(false);
  const [feeItemId, setFeeItemId] = useState<string>("");
  const [amount, setAmount] = useState<string>("");
  const [busy, setBusy] = useState(false);

  const feeItemsQ = useQuery({
    queryKey: ["fee-items"],
    queryFn: async () => {
      const { data, error } = await supabase.from("fee_items").select("id, name, amount").order("name");
      if (error) throw error;
      return (data ?? []) as FeeItemRow[];
    },
  });

  async function submit() {
    const parsed = chargeSchema.safeParse({ feeItemId, amount: Number(amount) });
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setBusy(true);
    const { error } = await supabase.from("invoices").insert({
      school_id: schoolId,
      student_id: studentId,
      fee_item_id: parsed.data.feeItemId,
      amount: parsed.data.amount,
      balance: parsed.data.amount,
      status: "unpaid",
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Charge posted");
    setOpen(false);
    setAmount(""); setFeeItemId("");
    onChange();
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button size="sm" variant="outline"><Plus className="h-4 w-4 mr-1" />Post charge</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Post fee charge</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Label>Fee item</Label>
            <Select value={feeItemId} onValueChange={(v) => { setFeeItemId(v); const fi = feeItemsQ.data?.find((f) => f.id === v); if (fi) setAmount(String(fi.amount)); }}>
              <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
              <SelectContent>
                {feeItemsQ.data?.map((f) => <SelectItem key={f.id} value={f.id}>{f.name} — {KES(Number(f.amount))}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Amount (KES)</Label>
            <Input type="number" min={1} value={amount} onChange={(e) => setAmount(e.target.value)} />
          </div>
        </div>
        <DialogFooter><Button onClick={submit} disabled={busy}>{busy && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Post charge</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---------- Payment ---------- */
const paymentSchema = z.object({
  amount: z.number().positive("Amount must be greater than 0"),
  method: z.enum(["cash", "mpesa", "bank"]),
  reference: z.string().max(64).optional(),
});

function RecordPaymentDialog({ invoice, schoolId, onChange }: { invoice: InvoiceRow; schoolId: string; onChange: () => void }) {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState(String(invoice.balance));
  const [method, setMethod] = useState<"cash" | "mpesa" | "bank">("cash");
  const [reference, setReference] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    const parsed = paymentSchema.safeParse({ amount: Number(amount), method, reference });
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    if (parsed.data.amount > Number(invoice.balance)) { toast.error("Amount exceeds outstanding balance"); return; }
    setBusy(true);
    const { data: { user } } = await supabase.auth.getUser();
    const { error: payErr } = await supabase.from("payments").insert({
      school_id: schoolId, invoice_id: invoice.id, amount: parsed.data.amount, method: parsed.data.method, reference: parsed.data.reference || null, recorded_by: user?.id ?? null,
    });
    if (payErr) { setBusy(false); toast.error(payErr.message); return; }
    const newBalance = Number(invoice.balance) - parsed.data.amount;
    const { error: invErr } = await supabase.from("invoices").update({ balance: newBalance, status: newBalance === 0 ? "paid" : "partial" }).eq("id", invoice.id);
    setBusy(false);
    if (invErr) { toast.error(invErr.message); return; }
    toast.success("Payment recorded");
    setOpen(false);
    onChange();
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button size="sm" variant="default"><BadgeDollarSign className="h-3 w-3 mr-1" />Pay</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Record payment</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Amount (KES)</Label><Input type="number" min={1} max={Number(invoice.balance)} value={amount} onChange={(e) => setAmount(e.target.value)} /></div>
          <div><Label>Method</Label>
            <Select value={method} onValueChange={(v) => setMethod(v as typeof method)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="cash">Cash</SelectItem><SelectItem value="mpesa">M-Pesa</SelectItem><SelectItem value="bank">Bank</SelectItem></SelectContent>
            </Select>
          </div>
          <div><Label>Reference (optional)</Label><Input value={reference} onChange={(e) => setReference(e.target.value)} maxLength={64} /></div>
        </div>
        <DialogFooter><Button onClick={submit} disabled={busy}>{busy && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Record</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---------- WAIVE FEE (ADMIN ONLY) ---------- */
const waiveSchema = z.object({
  amount: z.number().positive("Amount must be greater than 0"),
  reason: z.string().trim().min(5, "Reason is required (min 5 chars)").max(500),
});

function WaiveFeeDialog({ invoice, student, onChange }: { invoice: InvoiceRow; student: StudentRow; onChange: () => void }) {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState(String(invoice.balance));
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    const parsed = waiveSchema.safeParse({ amount: Number(amount), reason });
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    if (parsed.data.amount > Number(invoice.balance)) { toast.error("Waiver amount exceeds outstanding balance"); return; }
    setBusy(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setBusy(false); toast.error("Not signed in"); return; }

    // 1. Insert audit log first — RLS enforces admin role + admin_id = auth.uid()
    const { error: logErr } = await supabase.from("waivers_log").insert({
      school_id: student.school_id,
      invoice_id: invoice.id,
      student_id: student.id,
      admin_id: user.id,
      amount: parsed.data.amount,
      reason: parsed.data.reason.trim(),
    });
    if (logErr) {
      setBusy(false);
      toast.error(logErr.message.includes("policy") ? "Only admins can waive fees." : logErr.message);
      return;
    }
    // 2. Update invoice balance
    const newBalance = Number(invoice.balance) - parsed.data.amount;
    const { error: invErr } = await supabase.from("invoices").update({ balance: newBalance, status: newBalance === 0 ? "waived" : "partial" }).eq("id", invoice.id);
    setBusy(false);
    if (invErr) { toast.error(invErr.message); return; }
    toast.success("Fee waived and audit log recorded");
    setOpen(false);
    onChange();
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="ghost" className="text-amber-600 hover:text-amber-700">
          <ShieldCheck className="h-3 w-3 mr-1" />Waive
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Ban className="h-4 w-4 text-amber-600" />Waive fee — admin only</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="rounded-md bg-amber-500/10 text-amber-900 dark:text-amber-200 text-xs p-3">
            This action will be recorded in the immutable waivers audit log with your admin ID, the student, the amount and your reason.
          </div>
          <div><Label>Student</Label><div className="text-sm font-medium">{student.full_name} ({student.admission_no})</div></div>
          <div><Label>Amount to waive (KES)</Label><Input type="number" min={1} max={Number(invoice.balance)} value={amount} onChange={(e) => setAmount(e.target.value)} /></div>
          <div><Label>Reason (required)</Label><Textarea value={reason} onChange={(e) => setReason(e.target.value)} maxLength={500} placeholder="e.g. Bursary approved by board on…" /></div>
        </div>
        <DialogFooter>
          <Button onClick={submit} disabled={busy} variant="destructive">
            {busy && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Confirm waiver
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
