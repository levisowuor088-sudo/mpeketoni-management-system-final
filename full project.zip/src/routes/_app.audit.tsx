import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { useStore } from "@/lib/school-store";
import { PageHeader } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollText } from "lucide-react";

export const Route = createFileRoute("/_app/audit")({ component: AuditPage });

function AuditPage() {
  const log = useStore((s) => s.auditLog);
  const [q, setQ] = useState("");
  const filtered = useMemo(() => {
    const ql = q.toLowerCase();
    return log.filter((e) => !ql || e.action.toLowerCase().includes(ql) || e.detail.toLowerCase().includes(ql) || e.userName.toLowerCase().includes(ql));
  }, [log, q]);

  return (
    <div>
      <PageHeader title="Audit Log" description={`${log.length} system events tracked`} />
      <Card className="p-3 mb-4">
        <Input placeholder="Search action, user, or detail..." value={q} onChange={(e) => setQ(e.target.value)} />
      </Card>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted">
            <tr>
              <th className="text-left px-3 py-2">Timestamp</th>
              <th className="text-left px-3 py-2">User</th>
              <th className="text-left px-3 py-2">Action</th>
              <th className="text-left px-3 py-2">Detail</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((e) => (
              <tr key={e.id} className="border-b border-border">
                <td className="px-3 py-2 text-xs text-muted-foreground whitespace-nowrap">{new Date(e.timestamp).toLocaleString()}</td>
                <td className="px-3 py-2">{e.userName}</td>
                <td className="px-3 py-2"><Badge variant="secondary" className="font-mono text-[10px]"><ScrollText className="h-3 w-3 mr-1" />{e.action}</Badge></td>
                <td className="px-3 py-2 text-xs">{e.detail}</td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={4} className="text-center py-8 text-muted-foreground">No entries match</td></tr>}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
