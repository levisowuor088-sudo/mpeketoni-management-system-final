import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { type ReactNode, useState } from "react";
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  ClipboardCheck,
  BookOpenCheck,
  FileText,
  Banknote,
  Receipt,
  Wallet,
  Library,
  Bus,
  Boxes,
  Megaphone,
  Settings,
  School,
  LogOut,
  Moon,
  Sun,
  Menu,
  Bell,
  Search,
  UserCircle,
  ScrollText,
  FileBarChart,
  Upload,
  ShieldCheck,
} from "lucide-react";
import { actions, useStore, type Role } from "@/lib/school-store";
import { useTheme } from "@/components/theme";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface NavItem {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
  roles?: Role[];
}

const NAV: NavItem[] = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/students", label: "Students", icon: Users, roles: ["super_admin", "principal", "deputy_principal", "teacher", "registrar", "receptionist"] },
  { to: "/teachers", label: "Teachers", icon: GraduationCap, roles: ["super_admin", "principal", "registrar"] },
  { to: "/classes", label: "Classes", icon: School, roles: ["super_admin", "principal", "deputy_principal", "teacher", "registrar"] },
  { to: "/subjects", label: "Subjects", icon: BookOpenCheck, roles: ["super_admin", "principal", "deputy_principal", "registrar"] },
  { to: "/timetable", label: "Timetable", icon: ScrollText, roles: ["super_admin", "principal", "deputy_principal", "teacher", "registrar"] },
  { to: "/attendance", label: "Attendance", icon: ClipboardCheck, roles: ["super_admin", "principal", "deputy_principal", "teacher"] },
  { to: "/exams", label: "Exams & Marks", icon: BookOpenCheck, roles: ["super_admin", "principal", "teacher"] },
  { to: "/reports", label: "Report Cards", icon: FileText, roles: ["super_admin", "principal", "teacher", "parent", "student"] },
  { to: "/finance", label: "Finance Hub", icon: Wallet, roles: ["super_admin", "principal", "accountant", "bursar"] },
  { to: "/overview", label: "Department Report", icon: FileBarChart, roles: ["super_admin", "principal", "deputy_principal"] },
  { to: "/import", label: "Import (Excel)", icon: Upload, roles: ["super_admin", "principal", "accountant", "registrar"] },
  { to: "/fees", label: "Fees", icon: Banknote, roles: ["super_admin", "principal", "accountant", "bursar"] },
  { to: "/fee-charging", label: "Fee Charging", icon: ShieldCheck, roles: ["super_admin", "accountant"] },
  { to: "/waivers", label: "Waivers Audit", icon: ShieldCheck, roles: ["super_admin", "accountant"] },
  { to: "/charges", label: "Student Charges", icon: Receipt, roles: ["super_admin", "principal", "accountant", "bursar", "librarian", "storekeeper", "lab_tech", "teacher"] },
  { to: "/payments", label: "Payments", icon: Receipt, roles: ["super_admin", "principal", "accountant", "bursar"] },
  { to: "/payroll", label: "Payroll", icon: Wallet, roles: ["super_admin", "principal", "accountant"] },
  { to: "/donors", label: "Donors & Sponsorship", icon: Users, roles: ["super_admin", "principal", "accountant", "bursar"] },
  { to: "/donor-portal", label: "Donor Portal", icon: UserCircle, roles: ["donor"] },
  { to: "/library", label: "Library", icon: Library, roles: ["super_admin", "principal", "librarian", "teacher", "student"] },
  { to: "/transport", label: "Transport", icon: Bus, roles: ["super_admin", "principal", "transport"] },
  { to: "/inventory", label: "Inventory", icon: Boxes, roles: ["super_admin", "principal", "storekeeper", "lab_tech"] },
  { to: "/announcements", label: "Announcements", icon: Megaphone },
  { to: "/parent", label: "Parent Portal", icon: UserCircle, roles: ["parent"] },
  { to: "/student-portal", label: "Student Portal", icon: ScrollText, roles: ["student"] },
  { to: "/academic-year", label: "Academic Years", icon: FileBarChart, roles: ["super_admin", "principal", "registrar"] },
  { to: "/promotions", label: "Promotions", icon: GraduationCap, roles: ["super_admin", "principal", "registrar"] },
  { to: "/audit", label: "Audit Log", icon: ScrollText, roles: ["super_admin", "principal"] },
  { to: "/settings", label: "Settings", icon: Settings, roles: ["super_admin", "principal"] },
];

const ROLE_LABEL: Record<Role, string> = {
  super_admin: "Super Admin",
  principal: "Principal",
  deputy_principal: "Deputy Principal",
  teacher: "Teacher",
  accountant: "Accountant",
  bursar: "Bursar",
  registrar: "Registrar",
  storekeeper: "Storekeeper",
  receptionist: "Receptionist",
  lab_tech: "Lab Technician",
  librarian: "Librarian",
  transport: "Transport Manager",
  donor: "Donor / Sponsor",
  parent: "Parent",
  student: "Student",
};


export function AppShell({ children }: { children: ReactNode }) {
  const user = useStore((s) => s.currentUser);
  const school = useStore((s) => s.school);
  const announcements = useStore((s) => s.announcements);
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  const navigate = useNavigate();
  const { theme, toggle } = useTheme();
  const [open, setOpen] = useState(false);

  if (!user) {
    if (typeof window !== "undefined" && pathname !== "/") {
      navigate({ to: "/" });
    }
    return <>{children}</>;
  }

  const allowed = NAV.filter((n) => !n.roles || n.roles.includes(user.role));
  const initial = school.name.trim().charAt(0).toUpperCase() || "L";

  return (
    <div className="min-h-screen flex w-full bg-background">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed lg:sticky top-0 z-40 h-screen w-64 shrink-0 bg-sidebar text-sidebar-foreground border-r border-sidebar-border flex flex-col transition-transform",
          open ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
        )}
      >
        <div className="h-16 flex items-center gap-2 px-5 border-b border-sidebar-border">
          {school.logo ? (
            <img src={school.logo} alt="School logo" className="h-9 w-9 rounded-lg object-cover bg-sidebar-primary/20" />
          ) : (
            <div className="h-9 w-9 rounded-lg bg-sidebar-primary text-sidebar-primary-foreground grid place-items-center font-bold font-display">{initial}</div>
          )}
          <div className="leading-tight min-w-0">
            <div className="font-display font-bold text-sm truncate">{school.name.split(" ").slice(0, 3).join(" ")}</div>
            <div className="text-[10px] opacity-70">Levis Developers</div>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
          {allowed.map((item) => {
            const Active = pathname === item.to || pathname.startsWith(item.to + "/");
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  Active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-[var(--shadow-soft)]"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                )}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-sidebar-border">
          <div className="rounded-lg bg-sidebar-accent/60 p-3">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-8 w-8 rounded-full bg-sidebar-primary text-sidebar-primary-foreground grid place-items-center text-xs font-semibold">
                {user.name.split(" ").map((n) => n[0]).slice(0, 2).join("")}
              </div>
              <div className="min-w-0 leading-tight">
                <div className="text-xs font-semibold truncate">{user.name}</div>
                <div className="text-[10px] opacity-70">{ROLE_LABEL[user.role]}</div>
              </div>
            </div>
            <button
              onClick={async () => {
                const { supabase } = await import("@/integrations/supabase/client");
                await supabase.auth.signOut();
                actions.logout();
                navigate({ to: "/auth" });
              }}
              className="w-full flex items-center justify-center gap-2 text-xs rounded-md py-1.5 bg-sidebar text-sidebar-foreground/90 hover:bg-sidebar-foreground/10 transition-colors"
            >
              <LogOut className="h-3 w-3" /> Sign out
            </button>
          </div>
        </div>
      </aside>

      {open && (
        <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={() => setOpen(false)} />
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="no-print sticky top-0 z-20 h-16 bg-background/80 backdrop-blur border-b border-border flex items-center gap-3 px-4 lg:px-6">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setOpen(true)}>
            <Menu className="h-5 w-5" />
          </Button>
          <div className="hidden md:flex items-center gap-2 max-w-sm flex-1">
            <div className="relative w-full">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search students, teachers, receipts..." className="pl-9 bg-muted/50 border-transparent" />
            </div>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={toggle} aria-label="Toggle theme">
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-4 w-4" />
              {announcements.length > 0 && (
                <Badge className="absolute -top-1 -right-1 h-4 min-w-4 px-1 text-[10px]">{announcements.length}</Badge>
              )}
            </Button>
          </div>
        </header>
        <main className="flex-1 p-4 lg:p-6">{children}</main>
      </div>
    </div>
  );
}

export function PageHeader({ title, description, action }: { title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold tracking-tight">{title}</h1>
        {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
      </div>
      {action}
    </div>
  );
}
