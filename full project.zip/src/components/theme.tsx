import { useEffect } from "react";
import { actions, useStore } from "@/lib/school-store";

export function ThemeManager() {
  const theme = useStore((s) => s.theme);
  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);
  return null;
}

export function useTheme() {
  const theme = useStore((s) => s.theme);
  return {
    theme,
    toggle: () => actions.setTheme(theme === "dark" ? "light" : "dark"),
  };
}
