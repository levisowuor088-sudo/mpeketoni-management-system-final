// In-memory + localStorage mock store for the School Management System.
// Frontend-only prototype — replace with API calls when wiring a backend.
import { useSyncExternalStore } from "react";

export type Role =
  | "super_admin"
  | "principal"
  | "deputy_principal"
  | "teacher"
  | "accountant"
  | "bursar"
  | "registrar"
  | "storekeeper"
  | "receptionist"
  | "lab_tech"
  | "librarian"
  | "transport"
  | "donor"
  | "parent"
  | "student";


export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  avatar?: string;
  // Link to student record when role is parent/student
  studentId?: string;
}

export interface Student {
  id: string;
  admissionNo: string;
  name: string;
  gender: "M" | "F";
  grade: string; // e.g. "Grade 5"
  stream: string; // e.g. "Blue"
  dob: string;
  parentName: string;
  parentPhone: string;
  parentEmail: string;
  feeBalance: number;
  photo?: string;
}

export interface Teacher {
  id: string;
  staffNo: string;
  tscNo: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  subjects: string[];
  qualification: string;
  salary: number;
}

export interface SchoolClass {
  id: string;
  name: string; // "Grade 5 Blue"
  grade: string;
  stream: string;
  classTeacherId: string;
  capacity: number;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  date: string; // YYYY-MM-DD
  status: "present" | "absent" | "late";
}

export interface Exam {
  id: string;
  name: string;
  term: string;
  year: number;
  type: "CAT" | "Midterm" | "EndTerm";
  date: string;
}

export interface Mark {
  id: string;
  examId: string;
  studentId: string;
  subject: string;
  score: number;
}

export interface FeeStructure {
  id: string;
  grade: string;
  term: string;
  year: number;
  tuition: number;
  transport: number;
  meals: number;
  activities: number;
}

export interface Payment {
  id: string;
  receiptNo: string;
  studentId: string;
  amount: number;
  method: "M-Pesa" | "Bank" | "Cash";
  txnCode: string;
  date: string;
  receivedBy: string;
}

export interface Announcement {
  id: string;
  title: string;
  body: string;
  audience: "all" | "parents" | "students" | "staff";
  date: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  copies: number;
  available: number;
}

export interface Loan {
  id: string;
  bookId: string;
  studentId: string;
  borrowedOn: string;
  dueOn: string;
  returnedOn?: string;
  fine: number;
}

export interface TransportRoute {
  id: string;
  name: string;
  vehicleReg: string;
  driver: string;
  capacity: number;
  fee: number;
}

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  qty: number;
  reorderLevel: number;
  unitCost: number;
}

export interface PayrollEntry {
  id: string;
  teacherId: string;
  month: string;
  gross: number;
  paye: number;
  nssf: number;
  shif: number;
  net: number;
}

export interface Expense {
  id: string;
  category: string;
  amount: number;
  description: string;
  date: string;
}

export interface Invoice {
  id: string;
  invoiceNo: string;
  studentId: string;
  term: string;
  year: number;
  items: { label: string; amount: number }[];
  discount: number;
  total: number;
  issuedOn: string;
  dueOn: string;
  status: "draft" | "issued" | "paid" | "partial" | "overdue";
}

export interface Subject {
  id: string;
  code: string;
  name: string;
  grades: string[];
  teacherIds: string[];
}

export interface TimetableSlot {
  id: string;
  day: "Mon" | "Tue" | "Wed" | "Thu" | "Fri";
  period: number; // 1..8
  classId: string;
  subject: string;
  teacherId: string;
}

export interface StudentCharge {
  id: string;
  chargeNo: string;
  studentId: string;
  category: string;
  description: string;
  amount: number;
  date: string;
  createdBy: string;
  paid: boolean;
  waived?: boolean;
}

export interface Donor {
  id: string;
  name: string;
  organization?: string;
  contactPerson?: string;
  phone: string;
  email: string;
  address?: string;
  type: "Individual" | "NGO" | "Church" | "Alumni" | "Company";
  notes?: string;
}

export interface Sponsorship {
  id: string;
  donorId: string;
  studentId: string;
  category: "Tuition" | "Boarding" | "Transport" | "Meals" | "Exams" | "Full Fees" | "Other";
  amount: number;
  date: string;
  notes?: string;
}

export interface AcademicYear {
  id: string;
  year: number;
  status: "active" | "closed" | "archived";
  startDate: string;
  endDate: string;
}

export interface AuditEntry {
  id: string;
  userId: string;
  userName: string;
  action: string;
  detail: string;
  timestamp: string;
}

export interface SchoolProfile {
  name: string;
  motto: string;
  logo?: string; // data URL or remote URL
  address: string;
  poBox: string;
  phone: string;
  email: string;
  website: string;
  kraPin: string;
  paybill: string;
  bankName: string;
  bankAccount: string;
}


export interface State {
  currentUser: User | null;
  users: User[];
  students: Student[];
  teachers: Teacher[];
  classes: SchoolClass[];
  attendance: AttendanceRecord[];
  exams: Exam[];
  marks: Mark[];
  feeStructures: FeeStructure[];
  payments: Payment[];
  invoices: Invoice[];
  announcements: Announcement[];
  books: Book[];
  loans: Loan[];
  routes: TransportRoute[];
  inventory: InventoryItem[];
  payroll: PayrollEntry[];
  expenses: Expense[];
  subjects: Subject[];
  timetable: TimetableSlot[];
  charges: StudentCharge[];
  donors: Donor[];
  sponsorships: Sponsorship[];
  academicYears: AcademicYear[];
  auditLog: AuditEntry[];
  /** @deprecated use school.name */
  schoolName: string;
  /** @deprecated use school.motto */
  schoolMotto: string;
  school: SchoolProfile;
  theme: "light" | "dark";

}

const STORAGE_KEY = "sms_state_v1";

function uid(prefix = "id") {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`;
}

function seed(): State {
  const grades = ["Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8"];
  const streams = ["Blue", "Green", "Gold"];
  const subjects = ["Mathematics", "English", "Kiswahili", "Science", "Social Studies"];

  const teachers: Teacher[] = [
    { id: "t1", staffNo: "ST001", tscNo: "TSC100201", name: "Grace Wanjiku", email: "grace@school.ac.ke", phone: "+254712000001", department: "Mathematics", subjects: ["Mathematics", "Science"], qualification: "B.Ed Mathematics", salary: 65000 },
    { id: "t2", staffNo: "ST002", tscNo: "TSC100202", name: "David Otieno", email: "david@school.ac.ke", phone: "+254712000002", department: "Languages", subjects: ["English", "Kiswahili"], qualification: "B.Ed Arts", salary: 62000 },
    { id: "t3", staffNo: "ST003", tscNo: "TSC100203", name: "Mercy Achieng", email: "mercy@school.ac.ke", phone: "+254712000003", department: "Sciences", subjects: ["Science"], qualification: "B.Sc Biology", salary: 58000 },
    { id: "t4", staffNo: "ST004", tscNo: "TSC100204", name: "John Kamau", email: "john@school.ac.ke", phone: "+254712000004", department: "Humanities", subjects: ["Social Studies"], qualification: "B.A Education", salary: 56000 },
  ];

  const classes: SchoolClass[] = grades.flatMap((g, gi) =>
    streams.map((s, si) => ({
      id: `c_${gi}_${si}`,
      name: `${g} ${s}`,
      grade: g,
      stream: s,
      classTeacherId: teachers[(gi + si) % teachers.length].id,
      capacity: 35,
    })),
  );

  const firstNames = ["Aisha", "Brian", "Cynthia", "Daniel", "Esther", "Faith", "George", "Hannah", "Ian", "Joy", "Kevin", "Lilian", "Mike", "Nina", "Oscar", "Paula", "Quincy", "Ruth", "Sam", "Tina"];
  const lastNames = ["Mwangi", "Otieno", "Kariuki", "Achieng", "Kiprop", "Njoroge", "Wambui", "Omondi", "Chebet", "Mutua"];

  const students: Student[] = Array.from({ length: 60 }).map((_, i) => {
    const grade = grades[i % grades.length];
    const stream = streams[i % streams.length];
    return {
      id: `s${i + 1}`,
      admissionNo: `ADM${(2024000 + i + 1)}`,
      name: `${firstNames[i % firstNames.length]} ${lastNames[i % lastNames.length]}`,
      gender: i % 2 === 0 ? "M" : "F",
      grade,
      stream,
      dob: `201${3 + (i % 5)}-0${1 + (i % 9)}-1${(i % 9)}`,
      parentName: `Parent of ${firstNames[i % firstNames.length]}`,
      parentPhone: `+25471200${(1000 + i)}`,
      parentEmail: `parent${i + 1}@example.com`,
      feeBalance: [0, 0, 5000, 12000, 0, 8500, 0, 0][i % 8],
    };
  });

  const today = new Date();
  const attendance: AttendanceRecord[] = [];
  for (let d = 0; d < 14; d++) {
    const date = new Date(today);
    date.setDate(date.getDate() - d);
    const ds = date.toISOString().slice(0, 10);
    students.forEach((s, i) => {
      const r = (i + d) % 20;
      attendance.push({
        id: uid("a"),
        studentId: s.id,
        date: ds,
        status: r === 0 ? "absent" : r === 1 ? "late" : "present",
      });
    });
  }

  const exam: Exam = { id: "e1", name: "Midterm Exam", term: "Term 2", year: 2026, type: "Midterm", date: "2026-06-10" };
  const marks: Mark[] = students.flatMap((s, i) =>
    subjects.map((sub, j) => ({
      id: uid("m"),
      examId: exam.id,
      studentId: s.id,
      subject: sub,
      score: 40 + ((i * 7 + j * 13) % 55),
    })),
  );

  const feeStructures: FeeStructure[] = grades.map((g, i) => ({
    id: `f${i}`,
    grade: g,
    term: "Term 2",
    year: 2026,
    tuition: 18000 + i * 1500,
    transport: 4000,
    meals: 3500,
    activities: 1500,
  }));

  const payments: Payment[] = students.slice(0, 20).map((s, i) => ({
    id: uid("p"),
    receiptNo: `RCP${10000 + i}`,
    studentId: s.id,
    amount: 5000 + (i % 5) * 1500,
    method: i % 3 === 0 ? "M-Pesa" : i % 3 === 1 ? "Bank" : "Cash",
    txnCode: `QFK${(Math.random().toString(36).slice(2, 8)).toUpperCase()}`,
    date: new Date(Date.now() - i * 86400000).toISOString().slice(0, 10),
    receivedBy: "Accountant",
  }));

  const announcements: Announcement[] = [
    { id: uid("an"), title: "Midterm Break", body: "School will break for midterm on Friday and resume on Monday.", audience: "all", date: new Date().toISOString().slice(0, 10) },
    { id: uid("an"), title: "Parents AGM", body: "Annual general meeting scheduled for next Saturday at 10am in the school hall.", audience: "parents", date: new Date().toISOString().slice(0, 10) },
    { id: uid("an"), title: "Sports Day", body: "Inter-house sports day on Wednesday. All students in PE kit.", audience: "students", date: new Date().toISOString().slice(0, 10) },
  ];

  const books: Book[] = [
    { id: "b1", title: "Primary Mathematics Grade 5", author: "KIE", isbn: "978-9966-25-001-1", copies: 40, available: 32 },
    { id: "b2", title: "English Activities Grade 6", author: "Longhorn", isbn: "978-9966-25-002-2", copies: 35, available: 28 },
    { id: "b3", title: "Hekaya za Kiswahili", author: "Oxford", isbn: "978-9966-25-003-3", copies: 25, available: 20 },
    { id: "b4", title: "Discovering Science Grade 7", author: "Mountain Top", isbn: "978-9966-25-004-4", copies: 30, available: 27 },
  ];

  const loans: Loan[] = students.slice(0, 6).map((s, i) => ({
    id: uid("ln"),
    bookId: books[i % books.length].id,
    studentId: s.id,
    borrowedOn: new Date(Date.now() - (i + 3) * 86400000).toISOString().slice(0, 10),
    dueOn: new Date(Date.now() + (7 - i) * 86400000).toISOString().slice(0, 10),
    fine: i === 5 ? 50 : 0,
  }));

  const routes: TransportRoute[] = [
    { id: "r1", name: "Westlands Route", vehicleReg: "KDB 451X", driver: "Peter Njoroge", capacity: 32, fee: 4500 },
    { id: "r2", name: "Eastlands Route", vehicleReg: "KCY 902Y", driver: "Samuel Kibet", capacity: 28, fee: 4200 },
    { id: "r3", name: "Kasarani Route", vehicleReg: "KDA 110Z", driver: "Joseph Mwangi", capacity: 30, fee: 4800 },
  ];

  const inventory: InventoryItem[] = [
    { id: "i1", name: "School Uniform (Set)", category: "Uniforms", qty: 120, reorderLevel: 30, unitCost: 1500 },
    { id: "i2", name: "Exercise Books", category: "Stationery", qty: 800, reorderLevel: 200, unitCost: 45 },
    { id: "i3", name: "Chalk Boxes", category: "Stationery", qty: 25, reorderLevel: 20, unitCost: 250 },
    { id: "i4", name: "Desktop Computers", category: "ICT", qty: 18, reorderLevel: 5, unitCost: 35000 },
  ];

  const payroll: PayrollEntry[] = teachers.map((t) => {
    const gross = t.salary;
    const paye = Math.round(gross * 0.12);
    const nssf = 1080;
    const shif = Math.round(gross * 0.0275);
    return {
      id: uid("pr"),
      teacherId: t.id,
      month: "2026-06",
      gross,
      paye,
      nssf,
      shif,
      net: gross - paye - nssf - shif,
    };
  });

  const expenses: Expense[] = [
    { id: uid("ex"), category: "Utilities", amount: 28000, description: "Electricity bill", date: "2026-06-01" },
    { id: uid("ex"), category: "Maintenance", amount: 15500, description: "Roof repair", date: "2026-06-05" },
    { id: uid("ex"), category: "Supplies", amount: 9800, description: "Office stationery", date: "2026-06-09" },
  ];

  const users: User[] = [
    { id: "u_admin", name: "System Admin", email: "admin@school.ac.ke", role: "super_admin" },
    { id: "u_prin", name: "Mrs. Ann Wairimu", email: "principal@school.ac.ke", role: "principal" },
    { id: "u_dep", name: "Mr. Patrick Owino", email: "deputy@school.ac.ke", role: "deputy_principal" },
    { id: "u_tea", name: "Grace Wanjiku", email: "grace@school.ac.ke", role: "teacher" },
    { id: "u_acc", name: "Faith Cherono", email: "accounts@school.ac.ke", role: "accountant" },
    { id: "u_lib", name: "Tom Maina", email: "library@school.ac.ke", role: "librarian" },
    { id: "u_tra", name: "Eric Kiplagat", email: "transport@school.ac.ke", role: "transport" },
    { id: "u_par", name: students[0].parentName, email: students[0].parentEmail, role: "parent", studentId: students[0].id },
    { id: "u_stu", name: students[0].name, email: `student@school.ac.ke`, role: "student", studentId: students[0].id },
  ];

  const invoices: Invoice[] = students.slice(0, 30).map((s, i) => {
    const f = feeStructures.find((x) => x.grade === s.grade)!;
    const items = [
      { label: "Tuition", amount: f.tuition },
      { label: "Transport", amount: f.transport },
      { label: "Meals", amount: f.meals },
      { label: "Activities", amount: f.activities },
    ];
    const total = items.reduce((a, x) => a + x.amount, 0);
    return {
      id: uid("inv"),
      invoiceNo: `INV${20260000 + i + 1}`,
      studentId: s.id,
      term: "Term 2",
      year: 2026,
      items,
      discount: 0,
      total,
      issuedOn: "2026-05-01",
      dueOn: "2026-05-30",
      status: s.feeBalance === 0 ? "paid" : s.feeBalance < total ? "partial" : "overdue",
    } as Invoice;
  });

  const subjectsList: Subject[] = [
    { id: uid("sub"), code: "MAT", name: "Mathematics", grades, teacherIds: [teachers[0].id] },
    { id: uid("sub"), code: "ENG", name: "English", grades, teacherIds: [teachers[1].id] },
    { id: uid("sub"), code: "KIS", name: "Kiswahili", grades, teacherIds: [teachers[1].id] },
    { id: uid("sub"), code: "SCI", name: "Science", grades, teacherIds: [teachers[2].id] },
    { id: uid("sub"), code: "SST", name: "Social Studies", grades, teacherIds: [teachers[3].id] },
  ];

  const timetable: TimetableSlot[] = [];
  const days: TimetableSlot["day"][] = ["Mon", "Tue", "Wed", "Thu", "Fri"];
  classes.slice(0, 6).forEach((c, ci) => {
    days.forEach((d, di) => {
      for (let p = 1; p <= 4; p++) {
        const sub = subjects[(ci + di + p) % subjects.length];
        const sb = subjectsList.find((x) => x.name === sub)!;
        timetable.push({ id: uid("tt"), day: d, period: p, classId: c.id, subject: sub, teacherId: sb.teacherIds[0] });
      }
    });
  });

  const charges: StudentCharge[] = [
    { id: uid("ch"), chargeNo: "CHG1001", studentId: students[2].id, category: "Lost Library Book", description: "Hekaya za Kiswahili (978-9966-25-003-3)", amount: 850, date: new Date().toISOString().slice(0, 10), createdBy: "Librarian", paid: false },
    { id: uid("ch"), chargeNo: "CHG1002", studentId: students[5].id, category: "Damaged Desk", description: "Cracked desktop in Grade 5 Blue", amount: 1500, date: new Date().toISOString().slice(0, 10), createdBy: "Class Teacher", paid: false },
    { id: uid("ch"), chargeNo: "CHG1003", studentId: students[8].id, category: "Lost ID Card", description: "Replacement ID card", amount: 300, date: new Date().toISOString().slice(0, 10), createdBy: "Registrar", paid: true },
  ];

  const donors: Donor[] = [
    { id: "d1", name: "James Karanja", type: "Alumni", phone: "+254722111222", email: "jkaranja@example.com", organization: "Karanja & Co.", address: "Nairobi" },
    { id: "d2", name: "Bright Future NGO", type: "NGO", phone: "+254733000111", email: "give@brightfuture.org", contactPerson: "Sarah Mwende", address: "Mombasa" },
    { id: "d3", name: "St. Andrews Parish", type: "Church", phone: "+254700555888", email: "office@standrews.ac.ke" },
  ];

  const sponsorships: Sponsorship[] = [
    { id: uid("sp"), donorId: "d1", studentId: students[0].id, category: "Full Fees", amount: 27000, date: new Date().toISOString().slice(0, 10) },
    { id: uid("sp"), donorId: "d2", studentId: students[3].id, category: "Tuition", amount: 18000, date: new Date().toISOString().slice(0, 10) },
    { id: uid("sp"), donorId: "d2", studentId: students[7].id, category: "Meals", amount: 3500, date: new Date().toISOString().slice(0, 10) },
    { id: uid("sp"), donorId: "d3", studentId: students[1].id, category: "Exams", amount: 2500, date: new Date().toISOString().slice(0, 10) },
  ];

  const academicYears: AcademicYear[] = [
    { id: uid("ay"), year: 2024, status: "archived", startDate: "2024-01-08", endDate: "2024-11-30" },
    { id: uid("ay"), year: 2025, status: "closed", startDate: "2025-01-06", endDate: "2025-11-28" },
    { id: uid("ay"), year: 2026, status: "active", startDate: "2026-01-05", endDate: "2026-11-27" },
  ];

  const auditLog: AuditEntry[] = [
    { id: uid("au"), userId: "u_admin", userName: "System Admin", action: "system.boot", detail: "Seed data initialised", timestamp: new Date().toISOString() },
  ];

  // Extra demo users for expanded roles
  users.push(
    { id: "u_bur", name: "Lucy Atieno", email: "bursar@school.ac.ke", role: "bursar" },
    { id: "u_reg", name: "Henry Macharia", email: "registrar@school.ac.ke", role: "registrar" },
    { id: "u_str", name: "Paul Kibe", email: "store@school.ac.ke", role: "storekeeper" },
    { id: "u_rec", name: "Diana Nasimiyu", email: "reception@school.ac.ke", role: "receptionist" },
    { id: "u_lab", name: "Brian Onyango", email: "lab@school.ac.ke", role: "lab_tech" },
    { id: "u_don", name: "James Karanja", email: "jkaranja@example.com", role: "donor" },
  );

  return {
    currentUser: null,
    users,
    students,
    teachers,
    classes,
    attendance,
    exams: [exam],
    marks,
    feeStructures,
    payments,
    invoices,
    announcements,
    books,
    loans,
    routes,
    inventory,
    payroll,
    expenses,
    subjects: subjectsList,
    timetable,
    charges,
    donors,
    sponsorships,
    academicYears,
    auditLog,
    schoolName: "Levis Academy",
    schoolMotto: "Knowledge · Discipline · Service",
    school: {
      name: "Levis Academy",
      motto: "Knowledge · Discipline · Service",
      address: "Kenyatta Avenue, Nairobi",
      poBox: "P.O. Box 1234-00100, Nairobi",
      phone: "+254 700 000 000",
      email: "info@levisacademy.ac.ke",
      website: "www.levisacademy.ac.ke",
      kraPin: "P051234567A",
      paybill: "247247",
      bankName: "Equity Bank",
      bankAccount: "0123456789",
    },
    theme: "light",
  };
}


let state: State = (() => {
  const fresh = seed();
  if (typeof window === "undefined") return fresh;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const saved = JSON.parse(raw);
      return {
        ...fresh,
        ...saved,
        // Ensure new collections exist even on older saved snapshots
        subjects: saved.subjects ?? fresh.subjects,
        timetable: saved.timetable ?? fresh.timetable,
        charges: saved.charges ?? fresh.charges,
        donors: saved.donors ?? fresh.donors,
        sponsorships: saved.sponsorships ?? fresh.sponsorships,
        academicYears: saved.academicYears ?? fresh.academicYears,
        auditLog: saved.auditLog ?? fresh.auditLog,
        users: saved.users && saved.users.length >= fresh.users.length ? saved.users : fresh.users,
        school: { ...fresh.school, ...(saved.school ?? {}) },
        currentUser: saved.currentUser ?? null,
      };

    }
  } catch {}
  return fresh;
})();

const listeners = new Set<() => void>();

function persist() {
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {}
  }
}

function emit() {
  persist();
  listeners.forEach((l) => l());
}

export function getState(): State {
  return state;
}

export function setState(updater: (s: State) => State) {
  state = updater(state);
  emit();
}

export function useStore<T>(selector: (s: State) => T): T {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => selector(state),
    () => selector(state),
  );
}

// ---------- Actions ----------
export const actions = {
  login(role: Role) {
    const user = state.users.find((u) => u.role === role);
    if (user) setState((s) => ({ ...s, currentUser: user }));
  },
  /** Sign in using a Supabase-authenticated user record. Creates the in-memory user if not present. */
  loginFromSupabase(input: { id: string; name: string; email: string; role: Role }) {
    setState((s) => {
      const existing = s.users.find((u) => u.id === input.id || u.email === input.email);
      const user: User = existing ?? { id: input.id, name: input.name, email: input.email, role: input.role };
      const users = existing ? s.users.map((u) => (u.id === existing.id ? { ...u, role: input.role, name: input.name } : u)) : [...s.users, user];
      return { ...s, users, currentUser: { ...user, role: input.role, name: input.name } };
    });
  },
  logout() {
    setState((s) => ({ ...s, currentUser: null }));
  },
  setTheme(theme: "light" | "dark") {
    setState((s) => ({ ...s, theme }));
  },

  addStudent(input: Omit<Student, "id" | "admissionNo" | "feeBalance">) {
    setState((s) => {
      const next = s.students.length + 1;
      const student: Student = {
        ...input,
        id: uid("s"),
        admissionNo: `ADM${2024000 + next}`,
        feeBalance: 0,
      };
      return { ...s, students: [student, ...s.students] };
    });
  },
  updateStudent(id: string, patch: Partial<Student>) {
    setState((s) => ({ ...s, students: s.students.map((x) => (x.id === id ? { ...x, ...patch } : x)) }));
  },
  deleteStudent(id: string) {
    setState((s) => ({ ...s, students: s.students.filter((x) => x.id !== id) }));
  },

  addTeacher(input: Omit<Teacher, "id" | "staffNo">) {
    setState((s) => {
      const teacher: Teacher = { ...input, id: uid("t"), staffNo: `ST${100 + s.teachers.length + 1}` };
      return { ...s, teachers: [teacher, ...s.teachers] };
    });
  },
  deleteTeacher(id: string) {
    setState((s) => ({ ...s, teachers: s.teachers.filter((x) => x.id !== id) }));
  },

  markAttendance(date: string, statusByStudent: Record<string, AttendanceRecord["status"]>) {
    setState((s) => {
      const filtered = s.attendance.filter((a) => !(a.date === date && statusByStudent[a.studentId]));
      const added: AttendanceRecord[] = Object.entries(statusByStudent).map(([studentId, status]) => ({
        id: uid("a"),
        studentId,
        date,
        status,
      }));
      return { ...s, attendance: [...filtered, ...added] };
    });
  },

  saveMarks(examId: string, marks: { studentId: string; subject: string; score: number }[]) {
    setState((s) => {
      const filtered = s.marks.filter((m) => m.examId !== examId || !marks.find((x) => x.studentId === m.studentId && x.subject === m.subject));
      const added: Mark[] = marks.map((m) => ({ id: uid("m"), examId, ...m }));
      return { ...s, marks: [...filtered, ...added] };
    });
  },

  recordPayment(input: Omit<Payment, "id" | "receiptNo" | "date" | "receivedBy">) {
    setState((s) => {
      const payment: Payment = {
        ...input,
        id: uid("p"),
        receiptNo: `RCP${10000 + s.payments.length + 1}`,
        date: new Date().toISOString().slice(0, 10),
        receivedBy: s.currentUser?.name ?? "Accountant",
      };
      const students = s.students.map((st) => (st.id === input.studentId ? { ...st, feeBalance: Math.max(0, st.feeBalance - input.amount) } : st));
      return { ...s, payments: [payment, ...s.payments], students };
    });
  },

  addAnnouncement(input: Omit<Announcement, "id" | "date">) {
    setState((s) => ({
      ...s,
      announcements: [{ ...input, id: uid("an"), date: new Date().toISOString().slice(0, 10) }, ...s.announcements],
    }));
  },

  addBook(input: Omit<Book, "id" | "available">) {
    setState((s) => ({ ...s, books: [{ ...input, id: uid("b"), available: input.copies }, ...s.books] }));
  },
  borrowBook(bookId: string, studentId: string) {
    setState((s) => {
      const book = s.books.find((b) => b.id === bookId);
      if (!book || book.available <= 0) return s;
      const loan: Loan = {
        id: uid("ln"),
        bookId,
        studentId,
        borrowedOn: new Date().toISOString().slice(0, 10),
        dueOn: new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10),
        fine: 0,
      };
      return {
        ...s,
        loans: [loan, ...s.loans],
        books: s.books.map((b) => (b.id === bookId ? { ...b, available: b.available - 1 } : b)),
      };
    });
  },
  returnBook(loanId: string) {
    setState((s) => {
      const loan = s.loans.find((l) => l.id === loanId);
      if (!loan || loan.returnedOn) return s;
      return {
        ...s,
        loans: s.loans.map((l) => (l.id === loanId ? { ...l, returnedOn: new Date().toISOString().slice(0, 10) } : l)),
        books: s.books.map((b) => (b.id === loan.bookId ? { ...b, available: b.available + 1 } : b)),
      };
    });
  },

  addRoute(input: Omit<TransportRoute, "id">) {
    setState((s) => ({ ...s, routes: [{ ...input, id: uid("r") }, ...s.routes] }));
  },

  addInventory(input: Omit<InventoryItem, "id">) {
    setState((s) => ({ ...s, inventory: [{ ...input, id: uid("i") }, ...s.inventory] }));
  },

  addExpense(input: Omit<Expense, "id" | "date">) {
    setState((s) => ({ ...s, expenses: [{ ...input, id: uid("ex"), date: new Date().toISOString().slice(0, 10) }, ...s.expenses] }));
  },
  deleteExpense(id: string) {
    setState((s) => ({ ...s, expenses: s.expenses.filter((x) => x.id !== id) }));
  },

  updateSchool(patch: Partial<SchoolProfile>) {
    setState((s) => {
      const school = { ...s.school, ...patch };
      return { ...s, school, schoolName: school.name, schoolMotto: school.motto };
    });
  },

  applyDiscount(studentId: string, amount: number, reason: string) {
    setState((s) => {
      const students = s.students.map((st) =>
        st.id === studentId ? { ...st, feeBalance: Math.max(0, st.feeBalance - amount) } : st,
      );
      const expenses = [
        { id: uid("ex"), category: "Bursary / Discount", amount, description: `Discount for student ${studentId}: ${reason}`, date: new Date().toISOString().slice(0, 10) },
        ...s.expenses,
      ];
      return { ...s, students, expenses };
    });
  },

  issueInvoice(studentId: string, term: string, year: number) {
    setState((s) => {
      const student = s.students.find((x) => x.id === studentId);
      if (!student) return s;
      const f = s.feeStructures.find((x) => x.grade === student.grade);
      if (!f) return s;
      const items = [
        { label: "Tuition", amount: f.tuition },
        { label: "Transport", amount: f.transport },
        { label: "Meals", amount: f.meals },
        { label: "Activities", amount: f.activities },
      ];
      const total = items.reduce((a, x) => a + x.amount, 0);
      const today = new Date();
      const due = new Date(today); due.setDate(due.getDate() + 30);
      const invoice: Invoice = {
        id: uid("inv"),
        invoiceNo: `INV${20260000 + s.invoices.length + 1}`,
        studentId,
        term,
        year,
        items,
        discount: 0,
        total,
        issuedOn: today.toISOString().slice(0, 10),
        dueOn: due.toISOString().slice(0, 10),
        status: "issued",
      };
      const students = s.students.map((st) =>
        st.id === studentId ? { ...st, feeBalance: st.feeBalance + total } : st,
      );
      return { ...s, invoices: [invoice, ...s.invoices], students };
    });
  },

  bulkImportStudents(rows: Partial<Student>[]) {
    let count = 0;
    setState((s) => {
      let n = s.students.length;
      const added: Student[] = rows
        .filter((r) => r.name)
        .map((r) => {
          n += 1;
          count++;
          return {
            id: uid("s"),
            admissionNo: r.admissionNo || `ADM${2024000 + n}`,
            name: r.name!,
            gender: (r.gender as "M" | "F") || "M",
            grade: r.grade || "Grade 4",
            stream: r.stream || "Blue",
            dob: r.dob || "2015-01-01",
            parentName: r.parentName || "",
            parentPhone: r.parentPhone || "",
            parentEmail: r.parentEmail || "",
            feeBalance: Number(r.feeBalance) || 0,
          };
        });
      return { ...s, students: [...added, ...s.students] };
    });
    return count;
  },
  bulkImportTeachers(rows: Partial<Teacher>[]) {
    let count = 0;
    setState((s) => {
      let n = s.teachers.length;
      const added: Teacher[] = rows
        .filter((r) => r.name)
        .map((r) => {
          n += 1;
          count++;
          return {
            id: uid("t"),
            staffNo: r.staffNo || `ST${100 + n}`,
            tscNo: r.tscNo || "",
            name: r.name!,
            email: r.email || "",
            phone: r.phone || "",
            department: r.department || "General",
            subjects: typeof r.subjects === "string" ? (r.subjects as unknown as string).split(/[,;]/).map((x) => x.trim()) : r.subjects || [],
            qualification: r.qualification || "",
            salary: Number(r.salary) || 0,
          };
        });
      return { ...s, teachers: [...added, ...s.teachers] };
    });
    return count;
  },
  bulkImportMarks(examId: string, rows: { admissionNo: string; subject: string; score: number }[]) {
    let count = 0;
    setState((s) => {
      const added: Mark[] = [];
      rows.forEach((r) => {
        const stu = s.students.find((x) => x.admissionNo === String(r.admissionNo));
        if (!stu || !r.subject) return;
        added.push({ id: uid("m"), examId, studentId: stu.id, subject: r.subject, score: Number(r.score) || 0 });
        count++;
      });
      const filtered = s.marks.filter((m) => m.examId !== examId || !added.find((x) => x.studentId === m.studentId && x.subject === m.subject));
      return { ...s, marks: [...filtered, ...added] };
    });
    return count;
  },
  bulkImportPayments(rows: { admissionNo: string; amount: number; method?: string; txnCode?: string }[]) {
    let count = 0;
    setState((s) => {
      const payments = [...s.payments];
      const students = [...s.students];
      rows.forEach((r, i) => {
        const idx = students.findIndex((x) => x.admissionNo === String(r.admissionNo));
        if (idx < 0 || !r.amount) return;
        const amount = Number(r.amount);
        payments.unshift({
          id: uid("p"),
          receiptNo: `RCP${10000 + s.payments.length + i + 1}`,
          studentId: students[idx].id,
          amount,
          method: (r.method as Payment["method"]) || "Bank",
          txnCode: r.txnCode || `IMP${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
          date: new Date().toISOString().slice(0, 10),
          receivedBy: s.currentUser?.name ?? "Import",
        });
        students[idx] = { ...students[idx], feeBalance: Math.max(0, students[idx].feeBalance - amount) };
        count++;
      });
      return { ...s, payments, students };
    });
    return count;
  },

  // ---------- Audit ----------
  logAudit(action: string, detail: string) {
    setState((s) => ({
      ...s,
      auditLog: [
        { id: uid("au"), userId: s.currentUser?.id ?? "system", userName: s.currentUser?.name ?? "System", action, detail, timestamp: new Date().toISOString() },
        ...s.auditLog,
      ].slice(0, 500),
    }));
  },

  // ---------- Subjects ----------
  addSubject(input: Omit<Subject, "id">) {
    setState((s) => ({ ...s, subjects: [{ ...input, id: uid("sub") }, ...s.subjects] }));
  },
  updateSubject(id: string, patch: Partial<Subject>) {
    setState((s) => ({ ...s, subjects: s.subjects.map((x) => (x.id === id ? { ...x, ...patch } : x)) }));
  },
  deleteSubject(id: string) {
    setState((s) => ({ ...s, subjects: s.subjects.filter((x) => x.id !== id) }));
  },

  // ---------- Timetable ----------
  addTimetableSlot(input: Omit<TimetableSlot, "id">): { ok: boolean; reason?: string } {
    const s = state;
    const clash = s.timetable.find(
      (t) => t.day === input.day && t.period === input.period && (t.classId === input.classId || t.teacherId === input.teacherId),
    );
    if (clash) {
      return { ok: false, reason: clash.classId === input.classId ? "Class already has a lesson in that slot" : "Teacher already booked in that slot" };
    }
    setState((s2) => ({ ...s2, timetable: [{ ...input, id: uid("tt") }, ...s2.timetable] }));
    return { ok: true };
  },
  deleteTimetableSlot(id: string) {
    setState((s) => ({ ...s, timetable: s.timetable.filter((x) => x.id !== id) }));
  },

  // ---------- Charges (damages/fines) ----------
  addCharge(input: Omit<StudentCharge, "id" | "chargeNo" | "date" | "createdBy" | "paid">) {
    setState((s) => {
      const charge: StudentCharge = {
        ...input,
        id: uid("ch"),
        chargeNo: `CHG${1000 + s.charges.length + 1}`,
        date: new Date().toISOString().slice(0, 10),
        createdBy: s.currentUser?.name ?? "Admin",
        paid: false,
      };
      const students = s.students.map((st) =>
        st.id === input.studentId ? { ...st, feeBalance: st.feeBalance + input.amount } : st,
      );
      return { ...s, charges: [charge, ...s.charges], students };
    });
  },
  payCharge(chargeId: string, method: Payment["method"], txnCode = "") {
    setState((s) => {
      const c = s.charges.find((x) => x.id === chargeId);
      if (!c || c.paid || c.waived) return s;
      const payment: Payment = {
        id: uid("p"),
        receiptNo: `RCP${10000 + s.payments.length + 1}`,
        studentId: c.studentId,
        amount: c.amount,
        method,
        txnCode: txnCode || `CHG${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
        date: new Date().toISOString().slice(0, 10),
        receivedBy: s.currentUser?.name ?? "Accountant",
      };
      const students = s.students.map((st) =>
        st.id === c.studentId ? { ...st, feeBalance: Math.max(0, st.feeBalance - c.amount) } : st,
      );
      return {
        ...s,
        payments: [payment, ...s.payments],
        students,
        charges: s.charges.map((x) => (x.id === chargeId ? { ...x, paid: true } : x)),
      };
    });
  },
  waiveCharge(chargeId: string, reason: string) {
    setState((s) => {
      const c = s.charges.find((x) => x.id === chargeId);
      if (!c || c.paid || c.waived) return s;
      const students = s.students.map((st) =>
        st.id === c.studentId ? { ...st, feeBalance: Math.max(0, st.feeBalance - c.amount) } : st,
      );
      return {
        ...s,
        students,
        charges: s.charges.map((x) => (x.id === chargeId ? { ...x, waived: true, description: `${x.description} (Waived: ${reason})` } : x)),
      };
    });
  },

  // ---------- Donors & Sponsorship ----------
  addDonor(input: Omit<Donor, "id">) {
    setState((s) => ({ ...s, donors: [{ ...input, id: uid("d") }, ...s.donors] }));
  },
  updateDonor(id: string, patch: Partial<Donor>) {
    setState((s) => ({ ...s, donors: s.donors.map((x) => (x.id === id ? { ...x, ...patch } : x)) }));
  },
  deleteDonor(id: string) {
    setState((s) => ({ ...s, donors: s.donors.filter((x) => x.id !== id), sponsorships: s.sponsorships.filter((sp) => sp.donorId !== id) }));
  },
  addSponsorship(input: Omit<Sponsorship, "id" | "date">) {
    setState((s) => {
      const sp: Sponsorship = { ...input, id: uid("sp"), date: new Date().toISOString().slice(0, 10) };
      const payment: Payment = {
        id: uid("p"),
        receiptNo: `RCP${10000 + s.payments.length + 1}`,
        studentId: input.studentId,
        amount: input.amount,
        method: "Bank",
        txnCode: `DON${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
        date: sp.date,
        receivedBy: `Donor: ${s.donors.find((d) => d.id === input.donorId)?.name ?? "Sponsor"}`,
      };
      const students = s.students.map((st) =>
        st.id === input.studentId ? { ...st, feeBalance: Math.max(0, st.feeBalance - input.amount) } : st,
      );
      return { ...s, sponsorships: [sp, ...s.sponsorships], payments: [payment, ...s.payments], students };
    });
  },

  // ---------- Academic Year ----------
  addAcademicYear(year: number, startDate: string, endDate: string) {
    setState((s) => ({ ...s, academicYears: [{ id: uid("ay"), year, startDate, endDate, status: "active" }, ...s.academicYears.map((y) => ({ ...y, status: y.status === "active" ? ("closed" as const) : y.status }))] }));
  },
  setYearStatus(id: string, status: AcademicYear["status"]) {
    setState((s) => ({ ...s, academicYears: s.academicYears.map((y) => (y.id === id ? { ...y, status } : y)) }));
  },

  // ---------- Promotion ----------
  promoteClass(fromGrade: string, toGrade: string | "graduate", studentIds?: string[]) {
    setState((s) => {
      const candidates = s.students.filter((st) => st.grade === fromGrade && (!studentIds || studentIds.includes(st.id)));
      const ids = new Set(candidates.map((c) => c.id));
      const students = s.students.map((st) => {
        if (!ids.has(st.id)) return st;
        if (toGrade === "graduate") return { ...st, grade: "Alumni", stream: "—" };
        return { ...st, grade: toGrade };
      });
      const detail = `${toGrade === "graduate" ? "Graduated" : `Promoted ${fromGrade} → ${toGrade}`}: ${candidates.length} students`;
      return {
        ...s,
        students,
        auditLog: [
          { id: uid("au"), userId: s.currentUser?.id ?? "system", userName: s.currentUser?.name ?? "System", action: "promotion", detail, timestamp: new Date().toISOString() },
          ...s.auditLog,
        ],
      };
    });
  },
};


// ---------- Selectors / helpers ----------
export function grade(score: number): { letter: string; remark: string } {
  if (score >= 80) return { letter: "EE", remark: "Exceeds Expectation" };
  if (score >= 65) return { letter: "ME", remark: "Meets Expectation" };
  if (score >= 50) return { letter: "AE", remark: "Approaches Expectation" };
  return { letter: "BE", remark: "Below Expectation" };
}

export function kes(n: number) {
  return new Intl.NumberFormat("en-KE", { style: "currency", currency: "KES", maximumFractionDigits: 0 }).format(n);
}

export function feeForStudent(s: State, student: Student) {
  const f = s.feeStructures.find((x) => x.grade === student.grade);
  if (!f) return 0;
  return f.tuition + f.transport + f.meals + f.activities;
}
