import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Session, User } from "@supabase/supabase-js";
import { actions, type Role as LocalRole } from "@/lib/school-store";

export type DbRole = "admin" | "accountant" | "teacher" | "student" | "parent";

export interface AuthState {
  session: Session | null;
  user: User | null;
  role: DbRole | null;
  approved: boolean;
  schoolId: string | null;
  fullName: string;
  loading: boolean;
}

const DB_TO_LOCAL: Record<DbRole, LocalRole> = {
  admin: "super_admin", // admin maps to highest-privilege existing nav scope
  accountant: "accountant",
  teacher: "teacher",
  student: "student",
  parent: "parent",
};

/** Subscribe to Supabase auth + sync the local in-memory store user. */
export function useAuth(): AuthState {
  const [state, setState] = useState<AuthState>({
    session: null,
    user: null,
    role: null,
    approved: false,
    schoolId: null,
    fullName: "",
    loading: true,
  });

  useEffect(() => {
    let mounted = true;

    async function hydrate(session: Session | null) {
      if (!session?.user) {
        actions.logout();
        if (mounted) setState({ session: null, user: null, role: null, approved: false, schoolId: null, fullName: "", loading: false });
        return;
      }
      // Fetch role + profile in parallel
      const [{ data: roleRow }, { data: profile }] = await Promise.all([
        supabase.from("user_roles").select("role").eq("user_id", session.user.id).limit(1).maybeSingle(),
        supabase.from("profiles").select("full_name, approved, school_id").eq("id", session.user.id).maybeSingle(),
      ]);
      const role = (roleRow?.role ?? "student") as DbRole;
      const fullName = profile?.full_name ?? session.user.email?.split("@")[0] ?? "User";
      actions.loginFromSupabase({ id: session.user.id, name: fullName, email: session.user.email ?? "", role: DB_TO_LOCAL[role] });
      if (mounted)
        setState({
          session,
          user: session.user,
          role,
          approved: profile?.approved ?? false,
          schoolId: profile?.school_id ?? null,
          fullName,
          loading: false,
        });
    }

    supabase.auth.getSession().then(({ data }) => hydrate(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" || event === "SIGNED_OUT" || event === "USER_UPDATED" || event === "TOKEN_REFRESHED") {
        hydrate(session);
      }
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  return state;
}

export function isAdmin(role: DbRole | null) {
  return role === "admin";
}
