# Levis Developers — School Management Suite

A full-stack school management platform built on **TanStack Start (React 19 + Vite)**, **TypeScript**, **Tailwind CSS v4**, and **Lovable Cloud (managed Supabase)** for database, authentication and storage.

---

## What's in this release

This iteration adds the **Auth + Database + Admin-only Waiver** foundation on top of the existing modules (students, teachers, classes, attendance, exams, library, transport, inventory, timetable, donors, payroll, audit, etc.).

### Hardened in this turn
- **Real authentication** — Supabase Auth (email + password), signup with role selection, sign-in, forgot password, `/reset-password` page.
- **Database schema** — `schools`, `profiles`, `user_roles` (enum: `admin`, `accountant`, `teacher`, `student`, `parent`), `terms`, `fee_items`, `students`, `invoices`, `payments`, `waivers_log`.
- **Row Level Security** on every table. Students/parents see only their own records; admins/accountants manage school-wide data; **only admins can insert into `waivers_log`** (enforced at the DB layer).
- **Waive Fee is admin-only AND workflow-gated.** The Waive button only renders inside the dedicated **`/fee-charging`** workflow and only when the signed-in role is `admin`. It is removed from the Student Charges list, parent portal, student portal, and teacher views.
- **Immutable audit log** — every waive writes `admin_id`, `student_id`, `invoice_id`, `amount`, `reason`, `created_at` to `waivers_log`. View it at **`/waivers`** (admin / accountant read-only).
- **Validation** — Zod schemas on all auth and finance inputs. Negative fees rejected at the DB (`CHECK amount >= 0`) and the client.
- **Approval flow** — accountant and teacher signups land with `profiles.approved = false`; admin reviews and flips the flag.
- **Password hashing** — handled by Supabase Auth (bcrypt-strength). **Have-I-Been-Pwned** leaked-password protection is enabled.

### Already in the codebase (kept working)
Dashboard, students, teachers, classes, subjects, timetable, attendance, exams, report cards, finance hub, fees, payroll, donors + donor portal, library, transport, inventory, announcements, parent portal, student portal, academic years, promotions, audit log, Excel/CSV import, department overview.

---

## Getting started locally

### Prerequisites
- [Bun](https://bun.sh) (recommended) or Node 20+
- A Lovable Cloud project (created automatically — no manual Supabase signup needed)

### 1. Install
```bash
bun install
```

### 2. Environment
`.env` is auto-managed by Lovable Cloud. **Do not commit your own keys** — they are injected for you. The variables present:

```
VITE_SUPABASE_URL=...
VITE_SUPABASE_PUBLISHABLE_KEY=...
VITE_SUPABASE_PROJECT_ID=...
SUPABASE_URL=...
SUPABASE_PUBLISHABLE_KEY=...
SUPABASE_PROJECT_ID=...
```

These are **publishable** keys (safe in the browser). The **service-role key** is never exposed and is only available inside Lovable Cloud's managed server runtime.

### 3. Run
```bash
bun run dev
```
Open the URL printed in the console.

### 4. Build for production
```bash
bun run build
```

---

## First-time setup (no demo password — sign up live)

Supabase Auth doesn't allow pre-seeded passwords via SQL. Instead, **create the demo admin via the live signup form**:

1. Go to **`/auth`** and pick **Sign up**.
2. Use:
   - **Full name:** `Demo Admin`
   - **Email:** `admin@levis.demo`
   - **Password:** `LevisAdmin2026!`
   - **Role:** `admin`
3. You are signed in immediately (email auto-confirm is on for the demo).
4. Repeat for an accountant / teacher / student / parent if you want to test each role.

The database is **pre-seeded** with:
- 1 school (`Levis Demo Academy`)
- 1 active term (`Term 1 — 2026`)
- 3 fee items (Tuition KES 15,000 · Lunch KES 4,500 · Activity KES 1,200)

Once you sign in as admin, add students from the **Students** module, then open **Fee Charging** to post charges, record payments, and (admin only) waive fees with a reason.

---

## Where the rules live

| Concern | Where |
|---|---|
| RLS policies | `supabase/migrations/*.sql` |
| Role enum + `has_role()` helper | Same migrations |
| Sign-in / sign-up / forgot | `src/routes/auth.tsx` |
| Password reset landing | `src/routes/reset-password.tsx` |
| Auth state hook | `src/lib/useAuth.ts` |
| Protected layout | `src/routes/_app.tsx` |
| **Waive Fee (admin-only)** | `src/routes/_app.fee-charging.tsx` → `WaiveFeeDialog` |
| Waivers audit | `src/routes/_app.waivers.tsx` |

---

## Deploying

Lovable handles deployment. Click **Publish** in the editor; the published URL is shown in your project settings. Production URL pattern: `https://<project-slug>.lovable.app`.

For custom domains, open project Settings → Domains.

---

## Security posture

- **Passwords:** Supabase-managed (bcrypt-equivalent); leaked-password protection on.
- **RLS:** enforced on every table; `service_role` bypasses RLS for trusted server-side jobs only.
- **Waivers:** dual-checked — UI hides for non-admins, DB rejects (`policy "waivers admin only insert"`).
- **Validation:** Zod client-side, `CHECK` constraints DB-side, RLS server-side.
- **Audit:** `waivers_log` is insert-only for admins; nobody can update or delete entries (no UPDATE/DELETE policies exist).

---

Built with care by **Levis Developers**.
